APK BANANE KA TAREEKA (phone se hi ho jayega)
1. github.com pe free account banao, "New repository" banao (name: PhoneAgent).
2. Repo me "Add file > Upload files" se is zip ke andar ki files/folders daalo
   (app folder, settings.gradle.kts, build.gradle.kts, gradle.properties).
3. ".github/workflows/build.yml" file: "Add file > Create new file", naam me
   .github/workflows/build.yml likho aur build.yml ka content paste karo.
4. "Actions" tab me "Build APK" chalega (~5 min). Khatam hone par
   "PhoneAgent-apk" artifact download karo, zip kholo, app-debug.apk install karo.

PHONE PE SETUP
- Samsung: Settings > Apps > Phone Agent > 3 dots > "Allow restricted settings",
  phir Accessibility me "Phone Agent" ON karo.
- Model: Hugging Face (litert-community) se Gemma ka ".task" file (e.g. Gemma 3 1B / 3n E2B)
  ek baar download karo. App me "Model file chuno" se select karo. Uske baad sab offline.
- Battery: App ko "Unrestricted" karo.

VOICE: app me "Bolkar batao" dabao, bolo (Hindi/English), wo seedha START kar deta hai.
Offline voice ke liye: Settings > Google > Speech/Voice me Hindi (aur English) offline language pack download karo.

HEY BABY MODE: App me "'Hey Baby' sunna ON karo" dabao (mic permission do).
Phir kabhi bhi bolo: "hey baby, open Instagram and scroll reels" (ya "har 10 second").
Rokne ke liye: "hey baby stop" ya notification me "Agent roko".
Samsung: App ko Battery > Unrestricted rakho warna sunna band ho jayega.

NAYA (v3): DOST MODE + WHATSAPP MANANA + YAADASHT
- "hey baby, main udas hoon" -> dost ki tarah baat karta hai. Uske baad 15 sec tak "hey baby" bole bina bhi baat chalti rahti hai.
- "hey baby, WhatsApp pe Riya ko manao" -> contact kholta hai, message likhta hai, (default: pehle poochta hai "bhej doon?" -> bolo "haan"/"nahi"),
  bhejta hai, jawab aane par bolta hai "usne ye bola", phir agla message (max 4 round).
- "hey baby, yaad rakho meri girlfriend ka naam Riya hai" -> yaad rakhta hai.
- "maja aaya"/"achha tha" ya "galat tha" bolo -> seekhta hai (notes me, model retrain nahi hota).
- Payment/bank apps nahi chalata.
