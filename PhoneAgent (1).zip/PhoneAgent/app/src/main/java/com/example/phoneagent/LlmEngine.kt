package com.example.phoneagent

import android.content.Context
import com.google.mediapipe.tasks.genai.llminference.LlmInference

class LlmEngine(private val ctx: Context) {
    private var llm: LlmInference? = null
    val ready get() = llm != null

    fun load(path: String) {
        val opts = LlmInference.LlmInferenceOptions.builder()
            .setModelPath(path)
            .setMaxTokens(2048)
            .build()
        llm = LlmInference.createFromOptions(ctx, opts)
    }

    fun ask(prompt: String): String = llm!!.generateResponse(prompt)
}
