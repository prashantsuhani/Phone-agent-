package com.example.phoneagent

import android.content.Context
import java.io.File

// Yaadasht + seekh. Model retrain nahi hota; ye notes har prompt me jaate hain.
object Memory {
    private var f: File? = null
    private val lines = mutableListOf<String>()
    private val history = mutableListOf<String>()

    @Synchronized fun init(ctx: Context) {
        if (f != null) return
        f = File(ctx.filesDir, "memory.txt")
        if (f!!.exists()) lines.addAll(f!!.readLines())
    }

    @Synchronized fun add(kind: String, text: String) {
        lines.add("$kind|" + text.replace("\n", " ").take(200))
        while (lines.size > 60) {
            val i = lines.indexOfFirst { it.startsWith("L|") }
            lines.removeAt(if (i >= 0) i else 0)
        }
        f?.writeText(lines.joinToString("\n"))
    }

    @Synchronized fun notes() = lines.filter { it.startsWith("N|") }.map { it.drop(2) }
    @Synchronized fun lessons() = lines.filter { it.startsWith("L|") }.map { it.drop(2) }.takeLast(8)
    fun notesText() = (notes().joinToString("; ") + " | Seekh: " + lessons().joinToString("; ")).take(900)

    @Synchronized fun clear() { lines.clear(); history.clear(); f?.writeText("") }

    @Synchronized fun addTurn(s: String) { history.add(s.take(220)); while (history.size > 8) history.removeAt(0) }
    @Synchronized fun historyText() = history.takeLast(6).joinToString("\n")
}
