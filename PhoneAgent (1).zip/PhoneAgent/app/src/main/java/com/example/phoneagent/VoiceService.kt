package com.example.phoneagent

import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.*
import android.speech.*
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

class VoiceService : Service(), TextToSpeech.OnInitListener {
    private var rec: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private val h = Handler(Looper.getMainLooper())
    private var armedUntil = 0L
    private var ignoreUntil = 0L
    private var armAfter = false
    private var alive = true

    private val wake = Regex("(hey|hay|hi|he|हे|हाय)\\s*(baby|bebi|beby|बेबी)")
    private val stopSet = setOf("stop", "ruko", "रुको", "बंद", "रोको", "roko")
    private val yesSet = setOf("haan", "han", "ha", "yes", "bhej do", "bhejo", "send", "haan bhej do", "हाँ", "हां", "भेज दो")
    private val noSet = setOf("nahi", "no", "mat bhejo", "ruk jao", "नहीं", "मत भेजो")

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        Agent.init(this)
        Agent.armCallback = { h.post { armAfter = true } }
        startFg()
        tts = TextToSpeech(this, this)
        Thread { Agent.ensureModel(this) }.start()
        h.post { startListening() }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            "STOP_AGENT" -> Agent.stop()
            "STOP_LISTEN" -> { Agent.stop(); stopSelf() }
        }
        return START_STICKY
    }

    override fun onInit(status: Int) {
        tts?.language = Locale("en", "IN")
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onError(id: String?) { ignoreUntil = 0 }
            override fun onDone(id: String?) {
                h.post {
                    val now = System.currentTimeMillis()
                    ignoreUntil = now + 1200
                    if (armAfter) { armedUntil = now + 15000; armAfter = false }
                }
            }
        })
    }

    private fun speak(t: String) {
        ignoreUntil = System.currentTimeMillis() + 60000   // apni hi awaaz na sunne ke liye
        tts?.speak(t, TextToSpeech.QUEUE_FLUSH, null, "u")
    }

    private fun startFg() {
        val ch = "voice"
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(ch, "Hey Baby", NotificationManager.IMPORTANCE_LOW))
        fun pi(a: String) = PendingIntent.getService(this, a.hashCode(),
            Intent(this, VoiceService::class.java).setAction(a), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, ch)
            .setContentTitle("Hey Baby sun raha hai")
            .setContentText("Bolo: hey baby, ...")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .addAction(Notification.Action.Builder(android.R.drawable.ic_media_pause, "Agent roko", pi("STOP_AGENT")).build())
            .addAction(Notification.Action.Builder(android.R.drawable.ic_delete, "Sunna band", pi("STOP_LISTEN")).build())
            .build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        else startForeground(1, n)
    }

    private fun startListening() {
        if (!alive) return
        try {
            if (rec == null) {
                rec = if (Build.VERSION.SDK_INT >= 33 && SpeechRecognizer.isOnDeviceRecognitionAvailable(this))
                    SpeechRecognizer.createOnDeviceSpeechRecognizer(this)
                else SpeechRecognizer.createSpeechRecognizer(this)
                rec!!.setRecognitionListener(listener)
            }
            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
                putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
            }
            rec!!.startListening(i)
        } catch (e: Exception) { h.postDelayed({ startListening() }, 2000) }
    }

    private val listener = object : RecognitionListener {
        override fun onResults(r: Bundle?) {
            r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let { onHeard(it) }
            h.postDelayed({ startListening() }, 300)
        }
        override fun onError(e: Int) { h.postDelayed({ startListening() }, 700) }
        override fun onReadyForSpeech(p: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(v: Float) {}
        override fun onBufferReceived(b: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onPartialResults(p: Bundle?) {}
        override fun onEvent(t: Int, p: Bundle?) {}
    }

    private fun onHeard(text: String) {
        val now = System.currentTimeMillis()
        if (now < ignoreUntil || tts?.isSpeaking == true) return
        val low = text.lowercase().trim()
        Agent.log("Suna: $text")

        // "bhej doon?" ka jawab: sirf chhota, seedha haan/nahi
        if (Agent.pending != null) {
            if (low in yesSet) { Agent.pendingAnswer = 1; return }
            if (low in noSet || low.startsWith("nahi")) { Agent.pendingAnswer = 2; return }
        }

        val m = wake.find(low)
        val cmd: String
        if (m != null) {
            cmd = low.substring(m.range.last + 1).trim(' ', ',', '.')
            if (cmd.isEmpty()) { armedUntil = now + 8000; speak("Haan boliye"); return }
        } else if (now < armedUntil) { cmd = low; armedUntil = now + 15000 }
        else return

        val tokens = cmd.split(Regex("\\s+"))
        if (tokens.size <= 3 && tokens.any { it in stopSet }) { Agent.stop(); speak("Ruk gaya"); return }
        Agent.handle(cmd) { speak(it) }
    }

    override fun onDestroy() {
        alive = false
        rec?.destroy(); tts?.shutdown(); Agent.stop()
        super.onDestroy()
    }
}
