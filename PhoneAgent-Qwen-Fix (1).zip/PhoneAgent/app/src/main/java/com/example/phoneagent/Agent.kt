package com.example.phoneagent

import android.content.Context
import java.io.File

object Agent {
    @Volatile var running = false
    @Volatile var pending: String? = null
    @Volatile var pendingAnswer = 0          // 0 = nahi aaya, 1 = haan, 2 = nahi
    @Volatile var approveFirst = true
    var armCallback: (() -> Unit)? = null
    var logger: ((String) -> Unit)? = null
    private var engine: LlmEngine? = null
    private var lastDraft = ""
    val llmReady get() = engine?.ready == true

    fun log(s: String) { logger?.invoke(s) }

    fun init(ctx: Context) {
        if (engine == null) engine = LlmEngine(ctx.applicationContext)
        Memory.init(ctx)
        approveFirst = ctx.getSharedPreferences("cfg", 0).getBoolean("approve", true)
    }

    fun loadModel(ctx: Context, f: File) { init(ctx); engine!!.load(f.absolutePath) }
    fun unloadModel() { engine?.unload() }

    fun ensureModel(ctx: Context) {
        init(ctx)
        val f = File(ctx.filesDir, "model.task")
        if (!llmReady && f.exists()) try { loadModel(ctx, f) } catch (e: Throwable) { log("Model error: ${e.message}") }
    }

    fun stop() { running = false; pendingAnswer = 2 }

    private fun waitMs(ms: Long) { var t = 0L; while (running && t < ms) { Thread.sleep(250); t += 250 } }
    private fun ask(p: String): String = try { engine!!.ask(p) } catch (e: Throwable) { log("LLM error: ${e.message}"); "" }
    private fun clean(r: String) = r.trim().removePrefix("Baby:").substringBefore("\nUser").trim().trim('"').take(400)

    private val crisis = listOf("suicide", "sucide", "marna chahta", "mar jaun", "mar jana", "jaan de", "khatam kar lu",
        "khud ko hurt", "khud ko nuksan", "सुसाइड", "मर जाऊं", "जान दे")
    private val actionWords = listOf("open", "kholo", "khol do", "scroll", "bhej", "send", "message", "msg", "whatsapp",
        "call", "search", "play", "alarm", "chalao", "lagao", "install")

    fun handle(cmd: String, speak: (String) -> Unit) {
        val low = cmd.lowercase().trim()
        if (low.isEmpty()) return
        if (running) { speak("Pehle wala kaam chal raha hai. Pehle stop bolo."); return }

        // sehat/safety pehle
        if (crisis.any { low.contains(it) }) {
            speak("Mujhe tumhari bahut fikar ho rahi hai. Tum akele nahi ho. Abhi kisi apne ko phone karo ya paas bulao. " +
                "India me Tele-MANAS ka free number 14416 hai, 24 ghante. Main yahin hoon, baat karna chaho to karo.")
            armCallback?.invoke(); return
        }
        if (low.startsWith("yaad rakho") || low.startsWith("remember")) {
            Memory.add("N", cmd.substringAfter(" ").substringAfter(" ").ifBlank { cmd })
            speak("Theek hai, yaad rakh liya"); return
        }
        if (listOf("maja aaya", "mazaa aaya", "achha tha", "accha tha", "badhiya tha", "sahi tha").any { low.contains(it) }) {
            Memory.add("L", "User ko ye pasand aaya: '$lastDraft'"); speak("Badhiya, aise hi karunga"); return
        }
        if (listOf("galat tha", "bura tha", "mat bola karo", "aisa mat").any { low.contains(it) }) {
            Memory.add("L", "User ko ye pasand nahi aaya: '$lastDraft'. User ne bola: $cmd"); speak("Samajh gaya, aage dhyan rakhunga"); return
        }

        val svc = AgentService.instance
        running = true
        Thread {
            try {
                val reel = (low.contains("reel") || low.contains("रील")) && (low.contains("insta") || low.contains("इंस्टा"))
                val wa = low.contains("manao") || low.contains("मनाओ") ||
                    ((low.contains("whatsapp") || low.contains("message") || low.contains("msg")) &&
                        listOf("bol", "bhej", "send", "baat", "text", "puch", "pucho").any { low.contains(it) })
                val action = actionWords.any { low.contains(it) }
                when {
                    !llmReady -> speak("Model load nahi hua.")
                    reel && svc != null -> {
                        val sec = Regex("(\\d+)\\s*(sec|second|सेकंड)").find(low)?.groupValues?.get(1)?.toIntOrNull() ?: 15
                        runReels(svc, sec.coerceIn(3, 120), speak)
                    }
                    wa && svc != null -> whatsappFlow(svc, cmd, speak)
                    action && svc != null -> runLlm(svc, cmd, speak)
                    action -> speak("Accessibility chalu nahi hai.")
                    else -> chat(cmd, speak)
                }
            } catch (e: Throwable) { log("Error: ${e.message}") }
            finally { running = false; log("Agent ruk gaya.") }
        }.start()
    }

    // ---------- Dost jaisi baat ----------
    private fun chat(text: String, speak: (String) -> Unit) {
        val prompt = """<start_of_turn>user
Tum 'Baby' ho, user ke sabse achhe dost jaisa AI jo uske phone me rehta hai. Hinglish (roman) me, insaan ki tarah garm aur chhota (1-3 line) jawab do. Pehle dhyan se suno aur dukh ko samjho, lecture mat do. Kabhi kabhi ek chhota sawal poochho. Robot jaisa mat bolo. Agar user bahut dukhi ya hopeless lage to dheere se kisi apne insaan se baat karne ko kaho.
User ke baare me: ${Memory.notesText()}
Pichli baat:
${Memory.historyText()}
User: $text
<end_of_turn>
<start_of_turn>model
"""
        val reply = clean(ask(prompt))
        if (reply.isEmpty()) return
        Memory.addTurn("User: $text"); Memory.addTurn("Baby: $reply")
        log("Baby: $reply")
        speak(reply)
        armCallback?.invoke()
    }

    // ---------- WhatsApp pe manana / baat karna ----------
    private fun approved(msg: String, speak: (String) -> Unit): Boolean {
        if (!approveFirst) return true
        pendingAnswer = 0; pending = msg
        speak("Main ye bhejna chahta hoon: $msg. Bhej doon? Haan ya nahi bolo.")
        var t = 0
        while (running && pendingAnswer == 0 && t < 45000) { Thread.sleep(250); t += 250 }
        val a = pendingAnswer; pending = null; pendingAnswer = 0
        return when (a) {
            1 -> { Memory.add("L", "User ne ye message approve kiya (style achha): $msg"); true }
            2 -> { Memory.add("L", "User ne ye message reject kiya: $msg"); speak("Theek hai, nahi bheja."); false }
            else -> { speak("Jawab nahi mila, isliye nahi bheja."); false }
        }
    }

    private val timeRx = Regex("^\\d{1,2}[:.]\\d{2}(\\s?[APap][Mm])?$")
    private fun isWa(svc: AgentService) = svc.currentPackage()?.startsWith("com.whatsapp") == true

    private fun whatsappFlow(svc: AgentService, cmd: String, speak: (String) -> Unit) {
        val ext = ask("""<start_of_turn>user
Known facts about user: ${Memory.notesText()}
Command: $cmd
Extract JSON only: {"contact":"<contact name as saved in phone>","goal":"<what user wants to achieve in the chat>"}
<end_of_turn>
<start_of_turn>model
""")
        val contact = Regex("\"contact\"\\s*:\\s*\"([^\"]*)\"").find(ext)?.groupValues?.get(1)?.trim().orEmpty()
        val goal = Regex("\"goal\"\\s*:\\s*\"([^\"]*)\"").find(ext)?.groupValues?.get(1)?.trim().orEmpty().ifEmpty { cmd }
        if (contact.isEmpty() || contact.length > 40) {
            speak("Kis contact ko message karna hai? Naam batao. Aur 'yaad rakho meri girlfriend ka naam Riya hai' bolke save bhi kara do.")
            return
        }
        speak("Theek hai, $contact ko WhatsApp par message karta hoon")
        svc.openApp("WhatsApp"); waitMs(3500)
        if (!svc.clickByLabel("Search")) log("Search icon nahi mila")
        waitMs(1200)
        svc.typeInEditable(contact); waitMs(1800)
        if (!svc.clickByLabel(contact, skipEditable = true)) { speak("$contact naam ka chat nahi mila"); return }
        waitMs(2500)
        if (!isWa(svc)) { speak("WhatsApp nahi khula, ruk raha hoon"); return }

        var before = svc.readAllText()
        for (round in 1..4) {
            if (!running) return
            val chatLines = before.filter { !timeRx.matches(it) }.takeLast(12).joinToString(" | ").take(700)
            val draft = clean(ask("""<start_of_turn>user
Tum user ki taraf se WhatsApp message likh rahe ho. User ka goal: $goal
User ke baare me: ${Memory.notesText()}
Chat ki pichli lines (screen se): $chatLines
Ek chhota, sachcha, pyaar bhara natural Hinglish message likho (max 2 line). Sirf message likho, aur kuch nahi.
<end_of_turn>
<start_of_turn>model
""")).replace("\n", " ")
            if (draft.isEmpty()) { speak("Message nahi likh paya"); return }
            if (!approved(draft, speak)) return
            if (!isWa(svc)) { speak("WhatsApp se bahar chala gaya, ruk raha hoon"); return }
            svc.typeInEditable(draft); waitMs(700)
            if (!svc.clickByLabel("Send")) { speak("Send button nahi mila"); return }
            lastDraft = draft
            speak("Bhej diya: $draft")
            waitMs(1500)
            val sent = draft
            val seen = svc.readAllText().toSet()

            var reply: String? = null
            var t = 0
            while (running && t < 60000) {
                waitMs(4000); t += 4000
                if (!isWa(svc)) { speak("WhatsApp se bahar chala gaya, ruk raha hoon"); return }
                val newL = svc.readAllText().filter { it !in seen && it != sent && !timeRx.matches(it) }
                if (newL.isNotEmpty()) { reply = newL.joinToString(" ").take(300); break }
            }
            if (reply == null) { speak("Abhi tak $contact ka jawab nahi aaya. Aaye to bol dena, dobara dekhunga."); return }
            speak("$contact ne bola: $reply")
            Memory.addTurn("$contact: $reply")
            before = svc.readAllText()
        }
        speak("Maine kaafi baar baat kar li. Ab aage tum dekh lo.")
    }

    // ---------- Instagram reels ----------
    private fun runReels(svc: AgentService, sec: Int, speak: (String) -> Unit) {
        speak("Instagram khol raha hoon")
        log("Instagram reels mode, har $sec sec me scroll")
        svc.openApp("Instagram"); waitMs(3500)
        if (!svc.clickByLabel("Reels")) log("Reels tab nahi mila, jo screen hai usi par scroll karunga")
        waitMs(2500)
        while (running) {
            waitMs(sec * 1000L)
            if (!running) break
            if (svc.currentPackage() != "com.instagram.android") { speak("Instagram band ho gaya, ruk raha hoon"); break }
            log("scroll → ${svc.scroll()}")
        }
    }

    // ---------- Kuch bhi phone kaam (generic) ----------
    private val payPk = listOf("paytm", "phonepe", "paisa", "bhim", "upi", "bank", "wallet", "pay")

    private fun runLlm(svc: AgentService, goal: String, speak: (String) -> Unit) {
        val history = mutableListOf<String>()
        speak("Theek hai")
        svc.home(); waitMs(1200)
        for (step in 1..15) {
            if (!running) break
            val pk = svc.currentPackage() ?: ""
            if (payPk.any { pk.contains(it, true) }) { speak("Ye payment ya bank app hai, main ise nahi chalaunga"); svc.home(); break }
            val screen = svc.readScreen()
            val prompt = """<start_of_turn>user
You control an Android phone. Goal: $goal
Things learned about the user: ${Memory.notesText()}
Recent actions: ${history.takeLast(5)}
Current screen:
$screen
Reply with ONE JSON line only. Options:
{"action":"open_app","app":"name"}
{"action":"click","id":N}
{"action":"type","text":"..."}
{"action":"scroll"}
{"action":"back"}
{"action":"home"}
{"action":"done"}
<end_of_turn>
<start_of_turn>model
"""
            val reply = ask(prompt)
            if (reply.isEmpty()) break
            log("Step $step: ${reply.trim().take(120)}")
            val action = Regex("\"action\"\\s*:\\s*\"(\\w+)\"").find(reply)?.groupValues?.get(1)
            val result = when (action) {
                "open_app" -> svc.openApp(Regex("\"app\"\\s*:\\s*\"([^\"]*)\"").find(reply)?.groupValues?.get(1) ?: "")
                "click" -> svc.click(Regex("\"id\"\\s*:\\s*(\\d+)").find(reply)?.groupValues?.get(1)?.toInt() ?: -1)
                "type" -> svc.typeText(Regex("\"text\"\\s*:\\s*\"([^\"]*)\"").find(reply)?.groupValues?.get(1) ?: "")
                "scroll" -> svc.scroll()
                "back" -> svc.back()
                "home" -> svc.home()
                "done" -> { speak("Ho gaya"); running = false; "done" }
                else -> "samajh nahi aaya"
            }
            history.add("$action -> $result")
            log("   $result")
            waitMs(1500)
        }
    }
}
