package com.example.phoneagent

import android.content.Context
import com.google.mediapipe.tasks.genai.llminference.LlmInference

class LlmEngine(private val ctx: Context) {
    @Volatile private var llm: LlmInference? = null
    val ready get() = llm != null

    // Ek hi baar load ho (app + voice service dono load karne ki koshish karte the -> RAM double -> crash)
    @Synchronized
    fun load(path: String) {
        if (llm != null) return
        val opts = LlmInference.LlmInferenceOptions.builder()
            .setModelPath(path)
            .setMaxTokens(1024)
            .build()
        llm = LlmInference.createFromOptions(ctx, opts)
    }

    @Synchronized
    fun unload() {
        try { llm?.close() } catch (_: Throwable) {}
        llm = null
    }

    @Synchronized
    fun ask(prompt: String): String = llm!!.generateResponse(prompt)
}
