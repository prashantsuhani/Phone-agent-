package com.example.phoneagent

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.ViewGroup
import android.widget.*
import java.io.File

class MainActivity : Activity() {
    private lateinit var logView: TextView
    private lateinit var status: TextView
    private lateinit var toggle: Button
    private lateinit var goalBox: EditText
    private var listening = false
    private val PICK = 1
    private val VOICE = 2
    private val PERM = 3

    private fun log(s: String) = runOnUiThread { logView.append(s + "\n") }
    private fun setStatus(s: String) = runOnUiThread { status.text = s }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Agent.init(this)
        Agent.logger = { log(it) }
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(32, 48, 32, 32) }
        status = TextView(this).apply { text = "Model: load nahi hua" }
        val pick = Button(this).apply { text = "1. Model file chuno (.task)" }
        val acc = Button(this).apply { text = "2. Accessibility ON karo" }
        toggle = Button(this).apply { text = "3. 'Hey Baby' sunna ON karo" }
        goalBox = EditText(this).apply { hint = "Ya yahan likho (manual)" }
        val mic = Button(this).apply { text = "🎤 Ek baar bolo" }
        val start = Button(this).apply { text = "START (likha hua)" }
        val stop = Button(this).apply { text = "STOP" }
        val approve = CheckBox(this).apply {
            text = "Message bhejne se pehle mujhse poochho"
            isChecked = getSharedPreferences("cfg", 0).getBoolean("approve", true)
        }
        val memB = Button(this).apply { text = "🧠 Memory dekho" }
        val memC = Button(this).apply { text = "Memory saaf karo" }
        logView = TextView(this)
        val sv = ScrollView(this).apply { addView(logView) }
        listOf(status, pick, acc, toggle, approve, goalBox, mic, start, stop, memB, memC).forEach { root.addView(it) }
        root.addView(sv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)

        pick.setOnClickListener {
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"
            }, PICK)
        }
        acc.setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        stop.setOnClickListener { Agent.stop(); log("Stop dabaya") }
        start.setOnClickListener { Agent.handle(goalBox.text.toString().trim()) { log("🔊 $it") } }
        mic.setOnClickListener {
            val i = Intent(android.speech.RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                    android.speech.RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
                putExtra(android.speech.RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
            }
            try { startActivityForResult(i, VOICE) } catch (e: Exception) { log("Voice input nahi mila") }
        }
        toggle.setOnClickListener {
            if (listening) {
                stopService(Intent(this, VoiceService::class.java)); listening = false
                toggle.text = "3. 'Hey Baby' sunna ON karo"
            } else {
                val need = mutableListOf(Manifest.permission.RECORD_AUDIO)
                if (Build.VERSION.SDK_INT >= 33) need.add(Manifest.permission.POST_NOTIFICATIONS)
                if (need.all { checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }) startListening()
                else requestPermissions(need.toTypedArray(), PERM)
            }
        }
        approve.setOnCheckedChangeListener { _, c ->
            getSharedPreferences("cfg", 0).edit().putBoolean("approve", c).apply(); Agent.approveFirst = c
        }
        memB.setOnClickListener { log("Yaad: ${Memory.notes()}"); log("Seekh: ${Memory.lessons()}") }
        memC.setOnClickListener { Memory.clear(); log("Memory saaf") }
        if (File(filesDir, "model.task").exists()) loadModel(File(filesDir, "model.task"))
    }

    private fun startListening() {
        startForegroundService(Intent(this, VoiceService::class.java))
        listening = true
        toggle.text = "'Hey Baby' sunna band karo"
        log("Sun raha hoon. Bolo: hey baby, open Instagram and scroll reels")
    }

    override fun onRequestPermissionsResult(c: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(c, p, r)
        if (c == PERM && checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)
            startListening()
        else log("Mic permission chahiye")
    }

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req == VOICE) {
            val said = data?.getStringArrayListExtra(android.speech.RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (res == RESULT_OK && said != null) {
                goalBox.setText(said); log("Suna: $said")
                Agent.handle(said) { log("🔊 $it") }
            }
            return
        }
        if (req != PICK || res != RESULT_OK || data?.data == null) return
        Thread {
            try {
                setStatus("Model copy ho raha hai... (wait karo)")
                Agent.stop(); Agent.unloadModel()
                val tmp = File(filesDir, "model.tmp")
                val out = File(filesDir, "model.task")
                contentResolver.openInputStream(data.data!!)!!.use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
                out.delete(); tmp.renameTo(out)
                loadModel(out)
            } catch (e: Throwable) { setStatus("Copy error: ${e.message}") }
        }.start()
    }

    private fun loadModel(f: File) {
        Thread {
            try {
                if (Agent.llmReady) { setStatus("Model ready ✅"); return@Thread }
                setStatus("Model load ho raha hai...")
                Agent.loadModel(this, f)
                setStatus("Model ready ✅")
            } catch (e: Throwable) { setStatus("Model error: ${e.message}") }
        }.start()
    }
}
