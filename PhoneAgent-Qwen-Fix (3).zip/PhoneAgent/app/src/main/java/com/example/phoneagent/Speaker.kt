package com.example.phoneagent

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

// Ek hi jagah se bolna (app aur background service dono yahi use karte hain)
object Speaker {
    private var tts: TextToSpeech? = null
    private val main = Handler(Looper.getMainLooper())
    private val pending = mutableListOf<String>()
    @Volatile private var ready = false
    @Volatile private var failed = false
    @Volatile var speaking = false
    val usable get() = !failed
    @Volatile var onDone: (() -> Unit)? = null

    fun init(ctx: Context) {
        if (tts != null) return
        tts = TextToSpeech(ctx.applicationContext) { status ->
            val t = tts
            if (status != TextToSpeech.SUCCESS || t == null) {
                failed = true
                Agent.log("Awaaz engine nahi mila. Settings > General management > Text-to-speech me Google/Samsung engine chuno.")
                return@TextToSpeech
            }
            val enIn = Locale("en", "IN")
            val hiIn = Locale("hi", "IN")
            t.language = when {
                t.isLanguageAvailable(enIn) >= TextToSpeech.LANG_AVAILABLE -> enIn
                t.isLanguageAvailable(hiIn) >= TextToSpeech.LANG_AVAILABLE -> hiIn
                else -> Locale.getDefault()
            }
            t.setSpeechRate(0.95f)
            t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(id: String?) { speaking = true }
                override fun onDone(id: String?) { finish() }
                @Deprecated("old api") override fun onError(id: String?) { finish() }
            })
            ready = true
            synchronized(pending) { pending.forEach { say(it) }; pending.clear() }
        }
    }

    private fun finish() {
        speaking = false
        main.post { onDone?.invoke() }
    }

    private fun say(text: String) {
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "u" + System.nanoTime())
    }

    fun speak(text: String) {
        if (text.isBlank() || failed) return
        if (!ready) { synchronized(pending) { pending.add(text) }; return }
        speaking = true
        say(text)
    }

    fun stop() { tts?.stop(); speaking = false }
}
