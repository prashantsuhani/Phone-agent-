package com.example.phoneagent

import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.os.BatteryManager
import android.provider.AlarmClock
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Agent {
    @Volatile var running = false
    @Volatile var stopped = false
    @Volatile var pending: String? = null
    @Volatile var pendingAnswer = 0          // 0 = nahi aaya, 1 = haan, 2 = nahi
    @Volatile var approveFirst = true
    var armCallback: (() -> Unit)? = null
    var logger: ((String) -> Unit)? = null
    private var engine: LlmEngine? = null
    private var appCtx: Context? = null
    private var lastDraft = ""
    val llmReady get() = engine?.ready == true

    fun log(s: String) { logger?.invoke(s) }

    fun init(ctx: Context) {
        appCtx = ctx.applicationContext
        if (engine == null) engine = LlmEngine(ctx.applicationContext)
        Memory.init(ctx)
        approveFirst = ctx.getSharedPreferences("cfg", 0).getBoolean("approve", true)
    }

    fun loadModel(ctx: Context, f: File) { init(ctx); engine!!.load(f.absolutePath) }
    fun unloadModel() { engine?.unload() }

    fun ensureModel(ctx: Context) {
        init(ctx)
        val f = File(ctx.filesDir, "model.task")
        if (!llmReady && f.exists()) try { loadModel(ctx, f) } catch (e: Throwable) { log("Model error: ${e.message}") }
    }

    fun stop() { stopped = true; running = false; pendingAnswer = 2 }

    private fun waitMs(ms: Long) { var t = 0L; while (running && t < ms) { Thread.sleep(250); t += 250 } }
    private fun ask(p: String): String = try { engine!!.ask(p) } catch (e: Throwable) { log("LLM error: ${e.message}"); "" }
    private fun clean(r: String) = r.trim().removePrefix("Phool Kumari:").substringBefore("\nUser").trim().trim('"').take(400)

    private val crisis = listOf("suicide", "sucide", "marna chahta", "mar jaun", "mar jana", "jaan de", "khatam kar lu",
        "khud ko hurt", "khud ko nuksan", "सुसाइड", "मर जाऊं", "जान दे")
    private val actionWords = listOf("open", "kholo", "khol do", "scroll", "bhej", "send", "message", "msg", "whatsapp",
        "call", "search", "play", "alarm", "chalao", "lagao", "install",
        "ओपन", "खोलो", "खोल", "इंस्टाग्राम", "इंस्टा", "व्हाट्सएप", "व्हाट्सऐप", "वॉट्सऐप", "मैसेज", "मेसेज", "भेज", "अलार्म", "चलाओ", "लगाओ", "कॉल", "सर्च", "प्ले", "स्क्रॉल", "यूट्यूब", "क्रोम")

    fun handle(cmd: String, speak: (String) -> Unit) {
        val low = cmd.lowercase().trim()
        if (low.isEmpty()) return
        Memory.addTurn("User: $cmd")
        if (running) { speak("Pehle wala kaam chal raha hai. Pehle stop bolo."); return }

        // sehat/safety pehle
        if (crisis.any { low.contains(it) }) {
            speak("Mujhe tumhari bahut fikar ho rahi hai. Tum akele nahi ho. Abhi kisi apne ko phone karo ya paas bulao. " +
                "India me Tele-MANAS ka free number 14416 hai, 24 ghante. Main yahin hoon, baat karna chaho to karo.")
            armCallback?.invoke(); return
        }
        if (low.startsWith("yaad rakho") || low.startsWith("remember") || low.startsWith("ise yaad") || low.startsWith("is baat ko save")) {
            val fact = cmd.replace(Regex("(?i)^(yaad rakho|remember|ise yaad rakho|is baat ko save karo)\\s*"), "").trim().ifBlank { cmd }
            Memory.add("N", fact)
            speak("Theek hai, yaad rakh liya"); return
        }
        if (listOf("maja aaya", "mazaa aaya", "achha tha", "accha tha", "badhiya tha", "sahi tha").any { low.contains(it) }) {
            Memory.add("L", "User ko ye pasand aaya: '$lastDraft'"); speak("Badhiya, aise hi karunga"); return
        }
        if (listOf("galat tha", "bura tha", "mat bola karo", "aisa mat").any { low.contains(it) }) {
            Memory.add("L", "User ko ye pasand nahi aaya: '$lastDraft'. User ne bola: $cmd"); speak("Samajh gaya, aage dhyan rakhunga"); return
        }

        val svc = AgentService.instance
        val sayAndRemember: (String) -> Unit = { answer ->
            Memory.addTurn("Phool Kumari: $answer")
            speak(answer)
        }
        running = true; stopped = false
        Thread {
            var longTask = false
            try {
                val reel = (low.contains("reel") || low.contains("रील")) && (low.contains("insta") || low.contains("इंस्टा"))
                val wa = low.contains("manao") || low.contains("मनाओ") ||
                    ((low.contains("whatsapp") || low.contains("message") || low.contains("msg") || low.contains("व्हाट्स") || low.contains("वॉट्स") || low.contains("मैसेज")) &&
                        listOf("bol", "bhej", "send", "baat", "text", "puch", "pucho").any { low.contains(it) })
                val action = actionWords.any { low.contains(it) }
                when {
                    reel && svc != null -> {
                        val sec = Regex("(\\d+)\\s*(sec|second|सेकंड)").find(low)?.groupValues?.get(1)?.toIntOrNull() ?: 15
                        runReels(svc, sec.coerceIn(3, 120), sayAndRemember)
                    }
                    replyWa(norm(cmd)) && svc != null -> { longTask = true; replyFirstFlow(svc, sayAndRemember) }
                    lite(norm(cmd), svc, sayAndRemember) -> {}
                    !llmReady -> sayAndRemember("Is kaam ke liye model chahiye. Basic commands bina model ke chalte hain.")
                    wa && svc != null -> { longTask = true; whatsappFlow(svc, cmd, sayAndRemember) }
                    action && svc != null -> { longTask = true; runLlm(svc, cmd, sayAndRemember) }
                    action -> sayAndRemember("Accessibility chalu nahi hai.")
                    else -> chat(cmd, sayAndRemember)
                }
                if (longTask && !stopped) {
                    // kaam khatam: wapas background me sunna jari, aage ka poochho
                    sayAndRemember("Kaam ho gaya. Aage kya karna hai?")
                    armCallback?.invoke()
                }
            } catch (e: Throwable) { log("Error: ${e.message}") }
            finally { running = false; log("Agent ruk gaya.") }
        }.start()
    }

    // ---------- Dost jaisi baat ----------
    private fun chat(text: String, speak: (String) -> Unit) {
        val prompt = """<start_of_turn>user
Tum 'Phool Kumari' ho, user ke sabse achhe dost jaisa AI jo uske phone me rehta hai. Hinglish me, sirf English/Roman letters use karo (Devanagari bilkul nahi), insaan ki tarah garm aur chhota (1-3 line) jawab do. Pehle dhyan se suno aur dukh ko samjho, lecture mat do. User ki boli hui Hinglish, Roman Hindi, Hindi aur spelling mistakes samajhne ki koshish karo. Agar command ya sawal ke do matlab ho sakte hain, guess mat karo; ek chhota, seedha clarification question poochho. Pichhle context se referents resolve karo. Robot jaisa mat bolo. Agar user bahut dukhi ya hopeless lage to dheere se kisi apne insaan se baat karne ko kaho.
User ke baare me: ${Memory.notesText()}
Relevant purani baatein (sawal se milti-julti hon to inhe yaad karke jawab do):
${Memory.relevantHistory(text, 5000)}
Recent conversation:
${Memory.historyText()}
Uploaded study/document knowledge (sirf relevant facts use karo):
${Memory.relevantDocuments(text, 3500)}
User: $text
<end_of_turn>
<start_of_turn>model
"""
        val reply = clean(ask(prompt))
        if (reply.isEmpty()) return
        log("Phool Kumari: $reply")
        speak(reply)
        armCallback?.invoke()
    }

    // ---------- WhatsApp pe manana / baat karna ----------
    private fun approved(msg: String, speak: (String) -> Unit): Boolean {
        if (!approveFirst) return true
        pendingAnswer = 0; pending = msg
        speak("Main ye bhejna chahta hoon: $msg. Bhej doon? Haan ya nahi bolo.")
        var t = 0
        while (running && pendingAnswer == 0 && t < 45000) { Thread.sleep(250); t += 250 }
        val a = pendingAnswer; pending = null; pendingAnswer = 0
        return when (a) {
            1 -> { Memory.add("L", "User ne ye message approve kiya (style achha): $msg"); true }
            2 -> { Memory.add("L", "User ne ye message reject kiya: $msg"); speak("Theek hai, nahi bheja."); false }
            else -> { speak("Jawab nahi mila, isliye nahi bheja."); false }
        }
    }

    private val timeRx = Regex("^\\d{1,2}[:.]\\d{2}(\\s?[APap][Mm])?$")
    private fun isWa(svc: AgentService) = svc.currentPackage()?.startsWith("com.whatsapp") == true

    private fun whatsappFlow(svc: AgentService, cmd: String, speak: (String) -> Unit) {
        val ext = ask("""<start_of_turn>user
Known facts about user: ${Memory.notesText()}
Relevant saved documents: ${Memory.relevantDocuments(cmd, 2500)}
Command: $cmd
Extract JSON only: {"contact":"<contact name as saved in phone>","goal":"<what user wants to achieve in the chat>"}
<end_of_turn>
<start_of_turn>model
""")
        val contact = Regex("\"contact\"\\s*:\\s*\"([^\"]*)\"").find(ext)?.groupValues?.get(1)?.trim().orEmpty()
        val goal = Regex("\"goal\"\\s*:\\s*\"([^\"]*)\"").find(ext)?.groupValues?.get(1)?.trim().orEmpty().ifEmpty { cmd }
        if (contact.isEmpty() || contact.length > 40) {
            speak("Kis contact ko message karna hai? Naam batao. Aur 'yaad rakho meri girlfriend ka naam Riya hai' bolke save bhi kara do.")
            return
        }
        speak("Theek hai, $contact ko WhatsApp par message karta hoon")
        svc.openApp("WhatsApp"); waitMs(3500)
        if (!svc.clickByLabel("Search")) log("Search icon nahi mila")
        waitMs(1200)
        svc.typeInEditable(contact); waitMs(1800)
        if (!svc.clickByLabel(contact, skipEditable = true)) { speak("$contact naam ka chat nahi mila"); return }
        waitMs(2500)
        if (!isWa(svc)) { speak("WhatsApp nahi khula, ruk raha hoon"); return }

        var before = svc.readAllText()
        for (round in 1..4) {
            if (!running) return
            val chatLines = before.filter { !timeRx.matches(it) }.takeLast(12).joinToString(" | ").take(700)
            val draft = clean(ask("""<start_of_turn>user
Tum user ki taraf se WhatsApp message likh rahe ho. User ka goal: $goal
User ke baare me: ${Memory.notesText()}
Relevant saved documents: ${Memory.relevantDocuments(goal, 1800)}
Chat ki pichli lines (screen se): $chatLines
Ek chhota, sachcha, pyaar bhara natural Hinglish message likho (sirf Roman letters, Devanagari nahi) (max 2 line). Sirf message likho, aur kuch nahi.
<end_of_turn>
<start_of_turn>model
""")).replace("\n", " ")
            if (draft.isEmpty()) { speak("Message nahi likh paya"); return }
            if (!approved(draft, speak)) return
            if (!isWa(svc)) { speak("WhatsApp se bahar chala gaya, ruk raha hoon"); return }
            svc.typeInEditable(draft); waitMs(700)
            if (!svc.clickByLabel("Send")) { speak("Send button nahi mila"); return }
            lastDraft = draft
            speak("Bhej diya: $draft")
            waitMs(1500)
            val sent = draft
            val seen = svc.readAllText().toSet()

            var reply: String? = null
            var t = 0
            while (running && t < 60000) {
                waitMs(4000); t += 4000
                if (!isWa(svc)) { speak("WhatsApp se bahar chala gaya, ruk raha hoon"); return }
                val newL = svc.readAllText().filter { it !in seen && it != sent && !timeRx.matches(it) }
                if (newL.isNotEmpty()) { reply = newL.joinToString(" ").take(300); break }
            }
            if (reply == null) { speak("Abhi tak $contact ka jawab nahi aaya. Aaye to bol dena, dobara dekhunga."); return }
            speak("$contact ne bola: $reply")
            Memory.addTurn("$contact: $reply")
            before = svc.readAllText()
        }
        speak("Maine kaafi baar baat kar li. Ab aage tum dekh lo.")
    }

    // ---------- Instagram reels ----------
    private fun runReels(svc: AgentService, sec: Int, speak: (String) -> Unit) {
        speak("Instagram khol raha hoon")
        log("Instagram reels mode, har $sec sec me scroll")
        svc.openApp("Instagram"); waitMs(3500)
        if (!svc.clickByLabel("Reels")) log("Reels tab nahi mila, jo screen hai usi par scroll karunga")
        waitMs(2500)
        while (running) {
            waitMs(sec * 1000L)
            if (!running) break
            if (svc.currentPackage() != "com.instagram.android") { speak("Instagram band ho gaya, ruk raha hoon"); break }
            log("scroll → ${svc.scroll()}")
        }
    }

    // ---------- Kuch bhi phone kaam (generic) ----------
    private val payPk = listOf("paytm", "phonepe", "paisa", "bhim", "upi", "bank", "wallet", "pay")

    private fun runLlm(svc: AgentService, goal: String, speak: (String) -> Unit) {
        val history = mutableListOf<String>()
        var lastReply = ""
        var same = 0
        speak("Theek hai")
        svc.home(); waitMs(1200)
        for (step in 1..15) {
            if (!running) break
            val pk = svc.currentPackage() ?: ""
            if (payPk.any { pk.contains(it, true) }) { speak("Ye payment ya bank app hai, main ise nahi chalaunga"); svc.home(); break }
            val screen = svc.readScreen()
            val prompt = """<start_of_turn>user
You control an Android phone. Goal: $goal
Things learned about the user: ${Memory.notesText()}
Relevant saved documents:
${Memory.relevantDocuments(goal, 3000)}
Recent actions: ${history.takeLast(5)}
Current screen:
$screen
Reply with ONE JSON line only. Options:
{"action":"open_app","app":"name"}
{"action":"click","id":N}
{"action":"type","text":"..."}
{"action":"scroll"}
{"action":"back"}
{"action":"home"}
{"action":"done"}
<end_of_turn>
<start_of_turn>model
"""
            val reply = ask(prompt)
            if (reply.isEmpty()) break
            same = if (reply.trim() == lastReply) same + 1 else 0
            lastReply = reply.trim()
            if (same >= 2) { speak("Main atak gaya, ruk raha hoon. Command thoda seedha karke bolo."); break }
            log("Step $step: ${reply.trim().take(120)}")
            val action = Regex("\"action\"\\s*:\\s*\"(\\w+)\"").find(reply)?.groupValues?.get(1)
            val result = when (action) {
                "open_app" -> svc.openApp(Regex("\"app\"\\s*:\\s*\"([^\"]*)\"").find(reply)?.groupValues?.get(1) ?: "")
                "click" -> svc.click(Regex("\"id\"\\s*:\\s*(\\d+)").find(reply)?.groupValues?.get(1)?.toInt() ?: -1)
                "type" -> svc.typeText(Regex("\"text\"\\s*:\\s*\"([^\"]*)\"").find(reply)?.groupValues?.get(1) ?: "")
                "scroll" -> svc.scroll()
                "back" -> svc.back()
                "home" -> svc.home()
                "done" -> { speak("Ho gaya"); running = false; "done" }
                else -> "samajh nahi aaya"
            }
            history.add("$action -> $result")
            log("   $result")
            waitMs(1500)
        }
    }
    // ---------- "WhatsApp kholo aur pehle message ka reply do" ----------
    private fun replyWa(n: String) =
        Regex("\\b(reply|jawab)\\b").containsMatchIn(n) && (n.contains("whatsapp") || n.contains("message"))

    private fun replyFirstFlow(svc: AgentService, speak: (String) -> Unit) {
        speak("WhatsApp khol raha hoon")
        svc.openApp("WhatsApp"); waitMs(3500)
        var name = svc.clickFirstChat()
        if (name == null) { svc.back(); waitMs(1200); name = svc.clickFirstChat() }
        if (name == null) { speak("Chat list nahi mili. WhatsApp ki main screen kholke dobara bolo."); return }
        waitMs(2500)
        if (!isWa(svc)) { speak("WhatsApp nahi khula, ruk raha hoon"); return }
        speak("$name ka chat khola")
        val lines = svc.readAllText().filter { !timeRx.matches(it) }.takeLast(12).joinToString(" | ").take(700)
        val draft = clean(ask("""<start_of_turn>user
Tum user ki taraf se WhatsApp par reply likh rahe ho.
User ke baare me: ${Memory.notesText()}
Relevant saved documents: ${Memory.relevantDocuments(lines, 1800)}
Chat ki screen ki lines (aakhri message sabse neeche): $lines
Aakhri message ka chhota, natural Hinglish reply likho (max 2 line, sirf Roman letters). Sirf reply likho, aur kuch nahi.
<end_of_turn>
<start_of_turn>model
""")).replace("\n", " ")
        if (draft.isEmpty()) { speak("Reply nahi likh paya"); return }
        if (!approved(draft, speak)) return
        if (!isWa(svc)) { speak("WhatsApp se bahar chala gaya, ruk raha hoon"); return }
        svc.typeInEditable(draft); waitMs(700)
        if (!svc.clickByLabel("Send")) { speak("Send button nahi mila"); return }
        lastDraft = draft
        speak("Reply bhej diya: $draft")
    }

    // =====================================================================
    //  LITE MODE: bina LLM / bina kisi download ke chalne wale commands
    // =====================================================================
    private val dev = listOf(
        "ओपन" to "open", "खोलो" to "kholo", "खोल" to "khol", "इंस्टाग्राम" to "instagram",
        "व्हाट्सएप" to "whatsapp", "व्हाट्सऐप" to "whatsapp", "वॉट्सऐप" to "whatsapp", "व्हाट्सअप" to "whatsapp",
        "यूट्यूब" to "youtube", "क्रोम" to "chrome", "गूगल" to "google", "कैमरा" to "camera",
        "सेटिंग्स" to "settings", "गैलरी" to "gallery", "कैलकुलेटर" to "calculator", "स्नैपचैट" to "snapchat",
        "टेलीग्राम" to "telegram", "जीमेल" to "gmail", "मैप्स" to "maps", "मैसेज" to "message", "मेसेज" to "message",
        "भेजो" to "bhejo", "भेज" to "bhej", "सर्च" to "search", "अलार्म" to "alarm", "टाइम" to "time", "समय" to "samay",
        "बजे" to "baje", "फ्लैशलाइट" to "flashlight", "टॉर्च" to "torch", "स्क्रॉल" to "scroll", "सेकंड" to "second",
        "रिप्लाई" to "reply", "जवाब" to "jawab", "पहला" to "pehla", "पहले" to "pehle", "फर्स्ट" to "first",
        "को" to "ko", "पर" to "par", "बोलो" to "bolo", "लिखो" to "likho", "लगाओ" to "lagao", "चालू" to "chalu",
        "बंद" to "band", "बैक" to "back", "होम" to "home", "बैटरी" to "battery", "क्या" to "kya", "कितने" to "kitne",
        "करो" to "karo", "कर दो" to "kar do", "चलाओ" to "chalao", "हेलो" to "hello", "नमस्ते" to "namaste", "नाम" to "naam"
    )

    private fun norm(s: String): String {
        var r = s.lowercase(Locale.ROOT).trim()
        for ((a, b) in dev) r = r.replace(a, " $b ")
        // Common Hinglish spellings and speech-to-text variations.
        val aliases = listOf(
            "insta gram" to "instagram", "insta" to "instagram",
            "whats app" to "whatsapp", "what's app" to "whatsapp",
            "watsapp" to "whatsapp", "whatsap" to "whatsapp",
            "you tube" to "youtube", "face book" to "facebook",
            "khoolo" to "kholo", "kholna" to "kholo",
            "open karo" to "open", "khul ja" to "kholo"
        )
        for ((a, b) in aliases) r = r.replace(a, b)
        return r.replace(Regex("[?!।,.]"), " ").replace(Regex("\\s+"), " ").trim()
    }

    private fun startAct(svc: AgentService?, i: Intent) {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val c: Context? = svc ?: appCtx
        c?.startActivity(i)
    }

    private fun waSend(svc: AgentService, contact: String, msg: String, speak: (String) -> Unit) {
        speak("Theek hai, $contact ko WhatsApp par message karta hoon")
        svc.openApp("WhatsApp"); waitMs(3500)
        if (!svc.clickByLabel("Search")) log("Search icon nahi mila")
        waitMs(1200)
        svc.typeInEditable(contact); waitMs(1800)
        if (!svc.clickByLabel(contact, skipEditable = true)) { speak("$contact naam ka chat nahi mila"); return }
        waitMs(2500)
        if (!isWa(svc)) { speak("WhatsApp nahi khula, ruk raha hoon"); return }
        if (!approved(msg, speak)) return
        svc.typeInEditable(msg); waitMs(700)
        if (!svc.clickByLabel("Send")) { speak("Send button nahi mila"); return }
        lastDraft = msg
        speak("Bhej diya: $msg")
    }

    private fun launchAppDirect(name: String): String {
        val ctx = appCtx ?: return "app launch unavailable"
        val aliases = mapOf(
            "instagram" to "com.instagram.android", "insta" to "com.instagram.android",
            "whatsapp" to "com.whatsapp", "whats app" to "com.whatsapp",
            "youtube" to "com.google.android.youtube", "chrome" to "com.android.chrome",
            "telegram" to "org.telegram.messenger", "snapchat" to "com.snapchat.android",
            "gmail" to "com.google.android.gm"
        )
        val key = name.trim().lowercase(Locale.ROOT)
        val pkg = aliases[key]
        val intent = (pkg?.let { ctx.packageManager.getLaunchIntentForPackage(it) }
            ?: ctx.packageManager.getInstalledApplications(0).firstOrNull {
                ctx.packageManager.getApplicationLabel(it).toString().equals(name.trim(), true)
            }?.let { ctx.packageManager.getLaunchIntentForPackage(it.packageName) })
            ?: return "app not found: $name"
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(intent)
        return "opened $name"
    }

    // true = command sambhal liya (ya bata diya), false = LLM ko dena hai
    private fun lite(n: String, svc: AgentService?, speak: (String) -> Unit): Boolean {
        val ctx = appCtx ?: return false
        val ctl = "Pehle app me 'Control' dabake Accessibility ON karo."

        // 1) WhatsApp message (fixed text)
        val r1 = Regex("^(?:whatsapp\\s+(?:pe|par|on)\\s+|message\\s+)?(.+?)\\s+ko\\s+(.+?)\\s+(?:bhejo|bhej do|bhej|bol do|bolo|likho|likh do|send karo|send)$")
        val r2 = Regex("^(?:send|message|msg)\\s+(.+?)\\s+to\\s+(.+?)(?:\\s+on whatsapp)?$")
        var contact = ""; var text = ""
        r1.find(n)?.let { contact = it.groupValues[1]; text = it.groupValues[2] }
            ?: r2.find(n)?.let { text = it.groupValues[1]; contact = it.groupValues[2] }
        contact = contact.replace(Regex("\\b(whatsapp|pe|par|message|msg)\\b"), "").trim()
        if (contact.isNotEmpty() && text.isNotEmpty() && contact.length <= 30) {
            if (svc == null) { speak(ctl); return true }
            waSend(svc, contact, text, speak); return true
        }

        // 2) alarm
        if (n.contains("alarm")) {
            val m = Regex("(\\d{1,2})(?:[:.](\\d{2}))?\\s*(am|pm|baje)?").find(n)
            if (m == null) { speak("Kitne baje ka alarm? Jaise bolo: alarm 7 baje"); return true }
            var hr = m.groupValues[1].toInt()
            val mi = m.groupValues[2].toIntOrNull() ?: 0
            val ap = m.groupValues[3]
            if (ap == "pm" && hr < 12) hr += 12
            if (ap == "am" && hr == 12) hr = 0
            if (hr > 23 || mi > 59) { speak("Ye time samajh nahi aaya"); return true }
            try {
                startAct(svc, Intent(AlarmClock.ACTION_SET_ALARM)
                    .putExtra(AlarmClock.EXTRA_HOUR, hr).putExtra(AlarmClock.EXTRA_MINUTES, mi)
                    .putExtra(AlarmClock.EXTRA_SKIP_UI, true))
                speak("Alarm lag gaya, " + String.format(Locale.ENGLISH, "%02d:%02d", hr, mi) + " ke liye")
            } catch (e: Throwable) { speak("Alarm nahi lag paya") }
            return true
        }

        // 3) torch
        if (n.contains("flashlight") || n.contains("torch") || n.contains("flash light")) {
            val on = !(n.contains("band") || n.contains("off") || n.contains("bujha"))
            try {
                val cm = ctx.getSystemService(CameraManager::class.java)
                val id = cm.cameraIdList.firstOrNull { cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
                if (id == null) speak("Is phone me torch nahi mili")
                else { cm.setTorchMode(id, on); speak(if (on) "Torch chalu" else "Torch band") }
            } catch (e: Throwable) { speak("Torch nahi chal paayi") }
            return true
        }

        // 4) time / date / battery
        if (n.contains("battery")) {
            val b = ctx.getSystemService(BatteryManager::class.java).getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
            speak("Battery $b percent hai"); return true
        }
        if (Regex("\\b(date|tareekh|din)\\b").containsMatchIn(n) && (n.contains("kya") || n.contains("aaj") || n.contains("today"))) {
            speak("Aaj " + SimpleDateFormat("d MMMM yyyy, EEEE", Locale.ENGLISH).format(Date()) + " hai"); return true
        }
        if (Regex("\\b(time|samay)\\b|kitne baje|baj gaye").containsMatchIn(n)) {
            speak("Abhi " + SimpleDateFormat("h:mm a", Locale.ENGLISH).format(Date()) + " baje hain"); return true
        }

        // 5) youtube / web search
        if (n.contains("youtube")) {
            val q = n.replace(Regex("youtube|\\b(pe|par|on|search|karo|kholo|open|chalao|play|dhundo)\\b"), " ").replace(Regex("\\s+"), " ").trim()
            val url = if (q.isEmpty()) "https://www.youtube.com" else "https://www.youtube.com/results?search_query=" + Uri.encode(q)
            try { startAct(svc, Intent(Intent.ACTION_VIEW, Uri.parse(url))); speak("YouTube khol raha hoon") }
            catch (e: Throwable) { speak("YouTube nahi khul paya") }
            return true
        }
        if (Regex("^(search|google)\\b|\\b(search karo|search kar|dhundo|google karo)$").containsMatchIn(n)) {
            val q = n.replace(Regex("\\b(search|google|karo|kar|dhundo|pe|par|for)\\b"), " ").replace(Regex("\\s+"), " ").trim()
            if (q.isEmpty()) { speak("Kya search karna hai?"); return true }
            try { startAct(svc, Intent(Intent.ACTION_WEB_SEARCH).putExtra(SearchManager.QUERY, q)); speak("$q search kar raha hoon") }
            catch (e: Throwable) { speak("Search nahi ho paya") }
            return true
        }

        // 6) scroll / back / home
        val nav = when {
            n.contains("scroll") -> 1
            Regex("\\b(back|peeche)\\b").containsMatchIn(n) -> 2
            Regex("^(go )?home( jao| karo)?$|^ghar jao$").containsMatchIn(n) -> 3
            else -> 0
        }
        if (nav != 0) {
            if (svc == null) { speak(ctl); return true }
            when (nav) { 1 -> svc.scroll(); 2 -> svc.back(); else -> svc.home() }
            speak("Ho gaya"); return true
        }

        // 7) app kholna
        val om = Regex("^(?:please\\s+)?(?:open|launch|start)\\s+(.+?)(?:\\s+(?:karo|kar do|please))?$").find(n)
            ?: Regex("^(.+?)\\s+(?:kholo|khol do|khol|chalu karo|chalao|open karo|start karo)$").find(n)
        if (om != null) {
            val app = om.groupValues[1].trim()
            if (payPk.any { app.contains(it, true) }) { speak("Ye payment ya bank app hai, main ise nahi chalaunga"); return true }
            val r = if (svc == null) launchAppDirect(app) else svc.openApp(app)
            log(r)
            speak(if (r.startsWith("opened")) "$app khul gaya" else "$app naam ka app nahi mila")
            return true
        }

        // 8) model nahi hai to chhoti baat-cheet
        if (!llmReady) {
            when {
                Regex("\\b(hello|hi|hey|namaste|namaskar)\\b").containsMatchIn(n) -> speak("Namaste! Main Phool Kumari hoon. Bolo kya karna hai.")
                n.contains("kaise ho") -> speak("Main badhiya hoon. Tum batao, kya karna hai?")
                n.contains("naam") || n.contains("who are you") -> speak("Main Phool Kumari hoon, tumhara phone assistant.")
                n.contains("thank") || n.contains("shukriya") || n.contains("dhanyavad") -> speak("Koi baat nahi!")
                else -> speak("Ye command samajh nahi aaya. Aise bolo: open Instagram, WhatsApp pe Riya ko hi bhejo, alarm 7 baje, time kya hai, torch chalu karo.")
            }
            return true
        }
        return false
    }
}
