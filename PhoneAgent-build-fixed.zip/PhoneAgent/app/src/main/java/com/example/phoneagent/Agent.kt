package com.example.phoneagent

import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.os.BatteryManager
import android.provider.AlarmClock
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Agent {
@Volatile var running = false
@Volatile var stopped = false
@Volatile var pending: String? = null
@Volatile var pendingAnswer = 0
@Volatile var approveFirst = true
@Volatile var whatsappStyleLearning = true
@Volatile var whatsappReadDelayMs = 1500L
var armCallback: (() -> Unit)? = null
var logger: ((String) -> Unit)? = null
private var engine: LlmEngine? = null
private var appCtx: Context? = null
private var lastDraft = ""
val llmReady get() = engine?.ready == true

fun log(s: String) { logger?.invoke(s) }  

fun init(ctx: Context) {  
    appCtx = ctx.applicationContext  
    if (engine == null) engine = LlmEngine(ctx.applicationContext)  
    Memory.init(ctx)  
    approveFirst = ctx.getSharedPreferences("cfg", 0).getBoolean("approve", true)  
    whatsappStyleLearning = ctx.getSharedPreferences("cfg", 0).getBoolean("wa_read", true)  
}  

fun loadModel(ctx: Context, f: File) { init(ctx); engine!!.load(f.absolutePath) }  
fun unloadModel() { engine?.unload() }  

fun ensureModel(ctx: Context) {  
    init(ctx)  
    val f = File(ctx.filesDir, "model.task")  
    if (!llmReady && f.exists()) try { loadModel(ctx, f) } catch (e: Throwable) { log("Model error: ${e.message}") }  
}  

fun stop() {  
    stopped = true  
    running = false  
    pendingAnswer = 2  
}  

fun emergencyStopAll() {  
    Memory.setEmergencyStop(true)  
    Memory.setAutoReplyMasterOn(false)  
    stop()  
    log("🛑 EMERGENCY STOP: Auto-Reply aur sabhi tasks turant band kar diye gaye!")  
}  

private fun waitMs(ms: Long) {  
    var t = 0L  
    while (running && !Memory.isEmergencyStop() && t < ms) {  
        Thread.sleep(200)  
        t += 200  
    }  
}  

private fun ask(p: String): String = try { engine!!.ask(p) } catch (e: Throwable) { log("LLM error: ${e.message}"); "" }  
private fun clean(r: String) = r.trim().removePrefix("Phool Kumari:").substringBefore("\nUser").trim().trim('"').take(400)  

private val crisis = listOf("suicide", "sucide", "marna chahta", "mar jaun", "mar jana", "jaan de", "khatam kar lu",  
    "khud ko hurt", "khud ko nuksan", "सुसाइड", "मर जाऊं", "जान दे")  
private val actionWords = listOf("open", "kholo", "khol do", "scroll", "bhej", "send", "message", "msg", "whatsapp",  
    "call", "search", "play", "alarm", "chalao", "lagao", "install",  
    "ओपन", "खोलो", "खोल", "इंस्टाग्राम", "इंस्टा", "व्हाट्सएप", "व्हाट्सऐप", "वॉट्सऐप", "मैसेज", "मेसेज", "भेज", "अलार्म", "चलाओ", "लगाओ", "कॉल", "सर्च", "प्ले", "स्क्रॉल", "यूट्यूब", "क्रोम")  

fun handle(cmd: String, speak: (String) -> Unit) {  
    val low = cmd.lowercase().trim()  
    if (low.isEmpty()) return  
    Memory.addTurn("User: $cmd")  
    Memory.learnUserStyleSample(cmd)  

    if (Memory.isEmergencyStop()) {  
        speak("Emergency Stop ON hai. Pehle Emergency Stop OFF karo.")  
        return  
    }  
    if (running) { speak("Pehle wala kaam chal raha hai. Pehle stop bolo."); return }  

    if (crisis.any { low.contains(it) }) {  
        speak("Mujhe tumhari bahut fikar ho rahi hai. Tum akele nahi ho. Abhi kisi apne ko phone karo ya paas bulao. " +  
            "India me Tele-MANAS ka free number 14416 hai, 24 ghante. Main yahin hoon, baat karna chaho to karo.")  
        armCallback?.invoke(); return  
    }  

    // Save relationship / addressing commands e.g. "Riya ko Baby bulao" or "Mummy ka naam Maa hai"  
    val relMatch = Regex("^(.+?)\\s+ko\\s+(baby|bhai|mummy|papa|didi|jaan|babu|sir|boss|dost)\\s+(?:bulao|bolna|kehna|save karo)$", RegexOption.IGNORE_CASE).find(cmd.trim())  
    if (relMatch != null) {  
        val person = relMatch.groupValues[1].trim()  
        val title = relMatch.groupValues[2].trim().replaceFirstChar { it.uppercase() }  
        Memory.setRelation(person, title)  
        speak("Theek hai, ab se $person ko '$title' kehkar baat karunga.")  
        return  
    }  

    if (low.startsWith("yaad rakho") || low.startsWith("remember") || low.startsWith("ise yaad") || low.startsWith("is baat ko save")) {  
        val fact = cmd.replace(Regex("(?i)^(yaad rakho|remember|ise yaad rakho|is baat ko save karo)\\s*"), "").trim().ifBlank { cmd }  
        Memory.add("N", fact)  
        speak("Theek hai, yaad rakh liya"); return  
    }  

    val svc = AgentService.instance  
    val sayAndRemember: (String) -> Unit = { answer ->  
        Memory.addTurn("Phool Kumari: $answer")  
        speak(answer)  
    }  
    running = true; stopped = false  
    Thread {  
        var longTask = false  
        try {  
            val reel = (low.contains("reel") || low.contains("रील")) && (low.contains("insta") || low.contains("इंस्टा"))  
            val wa = low.contains("manao") || low.contains("मनाओ") ||  
                ((low.contains("whatsapp") || low.contains("message") || low.contains("msg") || low.contains("व्हाट्स") || low.contains("वॉट्स") || low.contains("मैसेज")) &&  
                    listOf("bol", "bhej", "send", "baat", "text", "puch", "pucho").any { low.contains(it) })  
            val action = actionWords.any { low.contains(it) }  
            when {  
                reel && svc != null -> {  
                    val sec = Regex("(\\d+)\\s*(sec|second|सेकंड)").find(low)?.groupValues?.get(1)?.toIntOrNull() ?: 15  
                    runReels(svc, sec.coerceIn(3, 120), sayAndRemember)  
                }  
                replyWa(norm(cmd)) && svc != null -> { longTask = true; replyFirstFlow(svc, sayAndRemember) }  
                lite(norm(cmd), svc, sayAndRemember) -> {}  
                !llmReady -> sayAndRemember("Is kaam ke liye model chahiye. Basic commands bina model ke chalte hain.")  
                wa && svc != null -> { longTask = true; whatsappFlow(svc, cmd, sayAndRemember) }  
                action && svc != null -> { longTask = true; runLlm(svc, cmd, sayAndRemember) }  
                action -> sayAndRemember("Accessibility chalu nahi hai.")  
                else -> chat(cmd, sayAndRemember)  
            }  
            if (longTask && !stopped) {  
                sayAndRemember("Kaam ho gaya. Aage kya karna hai?")  
                armCallback?.invoke()  
            }  
        } catch (e: Throwable) { log("Error: ${e.message}") }  
        finally { running = false; log("Agent ruk gaya.") }  
    }.start()  
}  

/** Triggered automatically when WhatsApp Auto-Reply is ON for a selected contact or ALL */  
fun triggerAutoReplyFromScreen(svc: AgentService, contactName: String) {  
    if (running || Memory.isEmergencyStop() || !Memory.canAutoReplyTo(contactName)) return  
    running = true; stopped = false  
    Thread {  
        try {  
            log("📩 Naya message mila ($contactName). Chat khol kar 1.5s padh raha hoon...")  
            if (!svc.clickByLabel(contactName, skipEditable = true)) return@Thread  
            // Wait 1.5 seconds (1-2 sec rule) after opening chat to read messages naturally  
            waitMs(whatsappReadDelayMs.coerceIn(1000L, 2000L))  
            if (!running || Memory.isEmergencyStop() || !isWa(svc)) return@Thread  

            val lines = readVisibleWhatsAppChat(svc)  
            if (lines.isBlank()) return@Thread  

            // Learn user's writing style from available chat history & save to contact's separate memory  
            Memory.appendContactMemory(contactName, "Visible chat: $lines")  
            val relation = Memory.getRelation(contactName)  
            val personMem = Memory.getContactMemory(contactName, 1500)  
            val styleSamples = Memory.getStyleSamples(15)  

            val draft = if (llmReady) {  
                clean(ask("""<start_of_turn>user

Tum user ki taraf se WhatsApp par auto-reply likh rahe ho.
Contact ka naam: $contactName
Is vyakti ka sambodhan/rishta: ${relation.ifBlank { "Dost/Normal" }}
Is vyakti ki alag memory: $personMem
User ki likhne ki shaili (style examples): $styleSamples
General yaad: ${Memory.notesText()}
Chat ki screen ki lines (sabse neeche naya message hai): $lines

Rules:

1. User ki tarah natural Hindi aur Hinglish me jawab do (sirf Roman letters me).

2. Agar rishta 'Baby', 'Bhai', 'Mummy' ya koi naam saved hai to usi pyaar/izzat wale sambodhan ka use karo.

3. Chhota (1-2 line) aur insaan jaisa reply likho. Sirf reply text likho, aur kuch nahi.
   <end_of_turn>
   <start_of_turn>model
   """)).replace("\n", " ")
   } else {
   fallbackHinglishReply(contactName, relation, lines)
   }

   if (draft.isBlank() || !running || Memory.isEmergencyStop()) return@Thread  
            if (approveFirst && !approved(draft) { Speaker.speak(it) }) return@Thread  

            if (!isWa(svc)) return@Thread  
            svc.typeInEditable(draft)  
            waitMs(600)  
            if (svc.clickByLabel("Send")) {  
                lastDraft = draft  
                Memory.appendContactMemory(contactName, "Auto-Replied: $draft")  
                Memory.addTurn("Auto-Reply to $contactName ($relation): $draft")  
                log("✅ Auto-Reply bhej diya ($contactName): $draft")  
            }  
        } catch (e: Throwable) {  
            log("Auto-Reply error: ${e.message}")  
        } finally {  
            running = false  
        }  
    }.start()

   }

   private fun fallbackHinglishReply(contact: String, relation: String, lines: String): String {
   val prefix = if (relation.isNotBlank()) "$relation, " else ""
   val low = lines.lowercase(Locale.ROOT)
   return when {
   low.contains("kaha ho") || low.contains("kidhar") -> "${prefix}bas thoda busy hoon abhi, thodi der me baat karta hoon."
   low.contains("khana") -> "${prefix}haan abhi dekh raha hoon, tumne khaya?"
   low.contains("hi") || low.contains("hello") || low.contains("hlw") -> "Haan ${relation.ifBlank { contact }}, bolo kya haal hai?"
   else -> "${prefix}abhi message dekha, thodi der me free hoke reply karta hoon."
   }
   }

   private fun chat(text: String, speak: (String) -> Unit) {
   val prompt = """<start_of_turn>user
   Tum 'Phool Kumari' ho, user ke sabse achhe dost jaisa AI jo uske phone me rehta hai. Hinglish me, sirf English/Roman letters use karo (Devanagari bilkul nahi), insaan ki tarah garm aur chhota (1-3 line) jawab do.
   User ke baare me: ${Memory.notesText()}
   Relevant purani baatein:
   ${Memory.relevantHistory(text, 5000)}
   Recent conversation:
   ${Memory.historyText()}
   Uploaded study/document knowledge:
   ${Memory.relevantDocuments(text, 3500)}
   User: $text
   <end_of_turn>
   <start_of_turn>model
   """
   val reply = clean(ask(prompt))
   if (reply.isEmpty()) return
   log("Phool Kumari: $reply")
   speak(reply)
   armCallback?.invoke()
   }

   private fun approved(msg: String, speak: (String) -> Unit): Boolean {
   if (!approveFirst) return true
   pendingAnswer = 0; pending = msg
   speak("Main ye bhejna chahta hoon: $msg. Bhej doon? Haan ya nahi bolo.")
   var t = 0
   while (running && !Memory.isEmergencyStop() && pendingAnswer == 0 && t < 45000) { Thread.sleep(250); t += 250 }
   val a = pendingAnswer; pending = null; pendingAnswer = 0
   return when (a) {
   1 -> { Memory.add("L", "User ne ye message approve kiya: $msg"); true }
   2 -> { Memory.add("L", "User ne ye message reject kiya: $msg"); speak("Theek hai, nahi bheja."); false }
   else -> { speak("Jawab nahi mila, isliye nahi bheja."); false }
   }
   }

   private val timeRx = Regex("^\d{1,2}[:.]\d{2}(\s?[APap][Mm])?$")
   private fun isWa(svc: AgentService) = svc.currentPackage()?.startsWith("com.whatsapp") == true

   private fun readVisibleWhatsAppChat(svc: AgentService): String {
   return svc.readAllText()
   .filter { !timeRx.matches(it) }
   .distinct()
   .takeLast(80)
   .joinToString(" | ")
   .take(4200)
   }

   private fun whatsappFlow(svc: AgentService, cmd: String, speak: (String) -> Unit) {
   val ext = ask("""<start_of_turn>user
   Known facts about user: ${Memory.notesText()}
   Command: $cmd
   Extract JSON only: {"contact":"<contact name as saved in phone>","goal":"<what user wants to achieve in the chat>"}
   <end_of_turn>
   <start_of_turn>model
   """)
   val contact = Regex("\"contact\"\\s*:\\s*\"([^\"]*)\"").find(ext)?.groupValues?.get(1)?.trim().orEmpty()
   val goal = Regex("\"goal\"\\s*:\\s*\"([^\"]*)\"").find(ext)?.groupValues?.get(1)?.trim().orEmpty().ifEmpty { cmd }
   if (contact.isEmpty() || contact.length > 40) {
   speak("Kis contact ko message karna hai? Naam batao.")
   return
   }
   speak("Theek hai, $contact ko WhatsApp par message karta hoon")
   svc.openApp("WhatsApp"); waitMs(3500)
   if (!svc.clickByLabel("Search")) log("Search icon nahi mila")
   waitMs(1200)
   svc.typeInEditable(contact); waitMs(1800)
   if (!svc.clickByLabel(contact, skipEditable = true)) { speak("$contact naam ka chat nahi mila"); return }
   waitMs(2500)
   if (!isWa(svc)) { speak("WhatsApp nahi khula, ruk raha hoon"); return }

   val relation = Memory.getRelation(contact)  
    val personMem = Memory.getContactMemory(contact, 1500)  

    for (round in 1..4) {  
        if (!running || Memory.isEmergencyStop()) return  
        waitMs(whatsappReadDelayMs.coerceIn(1000L, 2000L))  
        val chatLines = readVisibleWhatsAppChat(svc)  
        Memory.appendContactMemory(contact, "Chat read: $chatLines")  

        val draft = clean(ask("""<start_of_turn>user

Tum user ki taraf se WhatsApp message likh rahe ho.
Contact: $contact | Sambodhan/Rishta: ${relation.ifBlank { "Friend" }}
Is vyakti ki memory: $personMem
User ki style samples: ${Memory.getStyleSamples(15)}
User ka goal: $goal
User ke baare me: ${Memory.notesText()}
Chat ki pichli lines (screen se): $chatLines
Ek chhota, sachcha, natural Hindi/Hinglish message likho (sirf Roman letters, Devanagari nahi, max 2 line). Sirf message likho.
<end_of_turn>
<start_of_turn>model
""")).replace("\n", " ")
if (draft.isEmpty()) { speak("Message nahi likh paya"); return }
if (!approved(draft, speak)) return
if (!isWa(svc)) { speak("WhatsApp se bahar chala gaya, ruk raha hoon"); return }
svc.typeInEditable(draft); waitMs(700)
if (!svc.clickByLabel("Send")) { speak("Send button nahi mila"); return }
lastDraft = draft
Memory.appendContactMemory(contact, "Sent: $draft")
speak("Bhej diya: $draft")
waitMs(1500)
val sent = draft
val seen = svc.readAllText().toSet()

var reply: String? = null  
        var t = 0  
        while (running && !Memory.isEmergencyStop() && t < 60000) {  
            waitMs(4000); t += 4000  
            if (!isWa(svc)) { speak("WhatsApp se bahar chala gaya, ruk raha hoon"); return }  
            val newL = svc.readAllText().filter { it !in seen && it != sent && !timeRx.matches(it) }  
            if (newL.isNotEmpty()) { reply = newL.joinToString(" ").take(300); break }  
        }  
        if (reply == null) { speak("Abhi tak $contact ka jawab nahi aaya."); return }  
        speak("$contact ne bola: $reply")  
        Memory.appendContactMemory(contact, "Received: $reply")  
        Memory.addTurn("$contact: $reply")  
    }  
    speak("Maine kaafi baar baat kar li. Ab aage tum dekh lo.")  
}  

private fun runReels(svc: AgentService, sec: Int, speak: (String) -> Unit) {  
    speak("Instagram khol raha hoon")  
    svc.openApp("Instagram"); waitMs(3500)  
    svc.clickByLabel("Reels")  
    waitMs(2500)  
    while (running && !Memory.isEmergencyStop()) {  
        waitMs(sec * 1000L)  
        if (!running) break  
        if (svc.currentPackage() != "com.instagram.android") { speak("Instagram band ho gaya, ruk raha hoon"); break }  
        log("scroll → ${svc.scroll()}")  
    }  
}  

private val payPk = listOf("paytm", "phonepe", "paisa", "bhim", "upi", "bank", "wallet", "pay")  

private fun runLlm(svc: AgentService, goal: String, speak: (String) -> Unit) {  
    val history = mutableListOf<String>()  
    var lastReply = ""  
    var same = 0  
    speak("Theek hai")  
    svc.home(); waitMs(1200)  
    for (step in 1..15) {  
        if (!running || Memory.isEmergencyStop()) break  
        val pk = svc.currentPackage() ?: ""  
        if (payPk.any { pk.contains(it, true) }) { speak("Ye payment ya bank app hai, main ise nahi chalaunga"); svc.home(); break }  
        val screen = svc.readScreen()  
        val prompt = """<start_of_turn>user

You control an Android phone. Goal: $goal
Things learned about the user: ${Memory.notesText()}
Recent actions: ${history.takeLast(5)}
Current screen:
$screen
Reply with ONE JSON line only. Options:
{"action":"open_app","app":"name"}
{"action":"click","id":N}
{"action":"type","text":"..."}
{"action":"scroll"}
{"action":"back"}
{"action":"home"}
{"action":"done"}
<end_of_turn>
<start_of_turn>model
"""
val reply = ask(prompt)
if (reply.isEmpty()) break
same = if (reply.trim() == lastReply) same + 1 else 0
lastReply = reply.trim()
if (same >= 2) { speak("Main atak gaya, ruk raha hoon."); break }
val action = Regex(""action"\s*:\s*"(\w+)"").find(reply)?.groupValues?.get(1)
val result = when (action) {
"open_app" -> svc.openApp(Regex(""app"\s*:\s*"([^"])"").find(reply)?.groupValues?.get(1) ?: "")
"click" -> svc.click(Regex(""id"\s:\s*(\d+)").find(reply)?.groupValues?.get(1)?.toInt() ?: -1)
"type" -> svc.typeText(Regex(""text"\s*:\s*"([^"]*)"").find(reply)?.groupValues?.get(1) ?: "")
"scroll" -> svc.scroll()
"back" -> svc.back()
"home" -> svc.home()
"done" -> { speak("Ho gaya"); running = false; "done" }
else -> "samajh nahi aaya"
}
history.add("$action -> $result")
waitMs(1500)
}
}

private fun replyWa(n: String) =  
    Regex("\\b(reply|jawab)\\b").containsMatchIn(n) && (n.contains("whatsapp") || n.contains("message"))  

private fun replyFirstFlow(svc: AgentService, speak: (String) -> Unit) {  
    speak("WhatsApp khol raha hoon")  
    svc.openApp("WhatsApp"); waitMs(3500)  
    var name = svc.clickFirstChat()  
    if (name == null) { svc.back(); waitMs(1200); name = svc.clickFirstChat() }  
    if (name == null) { speak("Chat list nahi mili."); return }  
    waitMs(2000)  
    if (!isWa(svc)) { speak("WhatsApp nahi khula, ruk raha hoon"); return }  
    speak("$name ka chat khola, message padh raha hoon")  
    waitMs(whatsappReadDelayMs.coerceIn(1000L, 2000L))  
    val lines = readVisibleWhatsAppChat(svc)  
    val relation = Memory.getRelation(name)  
    val personMem = Memory.getContactMemory(name, 1500)  
    Memory.appendContactMemory(name, "Visible chat: $lines")  

    val draft = if (llmReady) {  
        clean(ask("""<start_of_turn>user

Tum user ki taraf se WhatsApp par reply likh rahe ho.
Contact: $name | Sambodhan/Rishta: ${relation.ifBlank { "Friend" }}
Is vyakti ki memory: $personMem
User ki style samples: ${Memory.getStyleSamples(15)}
User ke baare me: ${Memory.notesText()}
Chat ki screen ki lines: $lines
Aakhri message ka chhota, natural Hindi/Hinglish reply likho (max 2 line, sirf Roman letters). Sirf reply likho.
<end_of_turn>
<start_of_turn>model
""")).replace("\n", " ")
} else {
fallbackHinglishReply(name, relation, lines)
}

if (draft.isEmpty()) { speak("Reply nahi likh paya"); return }  
    if (!approved(draft, speak)) return  
    if (!isWa(svc)) { speak("WhatsApp se bahar chala gaya, ruk raha hoon"); return }  
    svc.typeInEditable(draft); waitMs(700)  
    if (!svc.clickByLabel("Send")) { speak("Send button nahi mila"); return }  
    lastDraft = draft  
    Memory.appendContactMemory(name, "Replied: $draft")  
    speak("Reply bhej diya: $draft")  
}  

private val dev = listOf(  
    "ओपन" to "open", "खोलो" to "kholo", "खोल" to "khol", "इंस्टाग्राम" to "instagram",  
    "व्हाट्सएप" to "whatsapp", "व्हाट्सऐप" to "whatsapp", "वॉट्सऐप" to "whatsapp",  
    "यूट्यूब" to "youtube", "क्रोम" to "chrome", "गूगल" to "google", "कैमरा" to "camera",  
    "मैसेज" to "message", "मेसेज" to "message", "भेजो" to "bhejo", "भेज" to "bhej",  
    "अलार्म" to "alarm", "टाइम" to "time", "फ्लैशलाइट" to "flashlight", "टॉर्च" to "torch",  
    "स्क्रॉल" to "scroll", "सेकंड" to "second", "रिप्लाई" to "reply", "जवाब" to "jawab",  
    "को" to "ko", "पर" to "par", "बोलो" to "bolo", "लिखो" to "likho", "लगाओ" to "lagao",  
    "चालू" to "chalu", "बंद" to "band", "बैक" to "back", "होम" to "home", "बैटरी" to "battery"  
)  

private fun norm(s: String): String {  
    var r = s.lowercase(Locale.ROOT).trim()  
    for ((a, b) in dev) r = r.replace(a, " $b ")  
    return r.replace(Regex("[?!।,.]"), " ").replace(Regex("\\s+"), " ").trim()  
}  

private fun startAct(svc: AgentService?, i: Intent) {  
    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)  
    val c: Context? = svc ?: appCtx  
    c?.startActivity(i)  
}  

private fun waSend(svc: AgentService, contact: String, msg: String, speak: (String) -> Unit) {  
    speak("Theek hai, $contact ko WhatsApp par message karta hoon")  
    svc.openApp("WhatsApp"); waitMs(3500)  
    svc.clickByLabel("Search"); waitMs(1200)  
    svc.typeInEditable(contact); waitMs(1800)  
    if (!svc.clickByLabel(contact, skipEditable = true)) { speak("$contact naam ka chat nahi mila"); return }  
    waitMs(2500)  
    if (!isWa(svc)) { speak("WhatsApp nahi khula"); return }  
    if (!approved(msg, speak)) return  
    svc.typeInEditable(msg); waitMs(700)  
    if (!svc.clickByLabel("Send")) { speak("Send button nahi mila"); return }  
    lastDraft = msg  
    Memory.appendContactMemory(contact, "Sent: $msg")  
    speak("Bhej diya: $msg")  
}  

private fun launchAppDirect(name: String): String {  
    val ctx = appCtx ?: return "app launch unavailable"  
    val aliases = mapOf(  
        "instagram" to "com.instagram.android", "insta" to "com.instagram.android",  
        "whatsapp" to "com.whatsapp", "youtube" to "com.google.android.youtube",  
        "chrome" to "com.android.chrome", "telegram" to "org.telegram.messenger"  
    )  
    val pkg = aliases[name.trim().lowercase(Locale.ROOT)]  
    val intent = (pkg?.let { ctx.packageManager.getLaunchIntentForPackage(it) }  
        ?: ctx.packageManager.getInstalledApplications(0).firstOrNull {  
            ctx.packageManager.getApplicationLabel(it).toString().equals(name.trim(), true)  
        }?.let { ctx.packageManager.getLaunchIntentForPackage(it.packageName) })  
        ?: return "app not found: $name"  
    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)  
    ctx.startActivity(intent)  
    return "opened $name"  
}  

private fun lite(n: String, svc: AgentService?, speak: (String) -> Unit): Boolean {  
    val ctx = appCtx ?: return false  
    val ctl = "Pehle app me 'Control' dabake Accessibility ON karo."  

    val r1 = Regex("^(?:whatsapp\\s+(?:pe|par|on)\\s+|message\\s+)?(.+?)\\s+ko\\s+(.+?)\\s+(?:bhejo|bhej do|bhej|bol do|bolo|likho|likh do|send karo|send)$")  
    var contact = ""; var text = ""  
    r1.find(n)?.let { contact = it.groupValues[1]; text = it.groupValues[2] }  
    contact = contact.replace(Regex("\\b(whatsapp|pe|par|message|msg)\\b"), "").trim()  
    if (contact.isNotEmpty() && text.isNotEmpty() && contact.length <= 30) {  
        if (svc == null) { speak(ctl); return true }  
        waSend(svc, contact, text, speak); return true  
    }  

    if (n.contains("alarm")) {  
        val m = Regex("(\\d{1,2})(?:[:.](\\d{2}))?\\s*(am|pm|baje)?").find(n)  
        if (m == null) { speak("Kitne baje ka alarm?"); return true }  
        var hr = m.groupValues[1].toInt()  
        val mi = m.groupValues[2].toIntOrNull() ?: 0  
        val ap = m.groupValues[3]  
        if (ap == "pm" && hr < 12) hr += 12  
        if (ap == "am" && hr == 12) hr = 0  
        try {  
            startAct(svc, Intent(AlarmClock.ACTION_SET_ALARM)  
                .putExtra(AlarmClock.EXTRA_HOUR, hr).putExtra(AlarmClock.EXTRA_MINUTES, mi)  
                .putExtra(AlarmClock.EXTRA_SKIP_UI, true))  
            speak("Alarm lag gaya, " + String.format(Locale.ENGLISH, "%02d:%02d", hr, mi) + " ke liye")  
        } catch (_: Throwable) { speak("Alarm nahi lag paya") }  
        return true  
    }  

    if (n.contains("flashlight") || n.contains("torch")) {  
        val on = !(n.contains("band") || n.contains("off"))  
        try {  
            val cm = ctx.getSystemService(CameraManager::class.java)  
            val id = cm.cameraIdList.firstOrNull { cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }  
            if (id != null) { cm.setTorchMode(id, on); speak(if (on) "Torch chalu" else "Torch band") }  
        } catch (_: Throwable) {}  
        return true  
    }  

    if (n.contains("battery")) {  
        val b = ctx.getSystemService(BatteryManager::class.java).getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)  
        speak("Battery $b percent hai"); return true  
    }  

    if (Regex("\\b(time|samay)\\b|kitne baje").containsMatchIn(n)) {  
        speak("Abhi " + SimpleDateFormat("h:mm a", Locale.ENGLISH).format(Date()) + " baje hain"); return true  
    }  

    val om = Regex("^(?:please\\s+)?(?:open|launch|start)\\s+(.+?)(?:\\s+(?:karo|kar do|please))?$").find(n)  
        ?: Regex("^(.+?)\\s+(?:kholo|khol do|khol|chalu karo|chalao|open karo)$").find(n)  
    if (om != null) {  
        val app = om.groupValues[1].trim()  
        val r = if (svc == null) launchAppDirect(app) else svc.openApp(app)  
        speak(if (r.startsWith("opened")) "$app khul gaya" else "$app naam ka app nahi mila")  
        return true  
    }  

    if (!llmReady) {  
        speak("Namaste! Main Phool Kumari hoon. Bolo kya karna hai.")  
        return true  
    }  
    return false  
}

}
