package com.example.phoneagent

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.graphics.Rect
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class AgentService : AccessibilityService() {
companion object { @Volatile var instance: AgentService? = null }

private var nodes: List<AccessibilityNodeInfo> = emptyList()  
private var lastAutoTriggerAt = 0L  

override fun onServiceConnected() { instance = this }  
override fun onUnbind(intent: Intent?): Boolean { instance = null; return super.onUnbind(intent) }  

override fun onAccessibilityEvent(event: AccessibilityEvent?) {  
    if (event == null) return  
    val pkg = event.packageName?.toString() ?: return  
    if (pkg != "com.whatsapp" && pkg != "com.whatsapp.w4b") return  
    if (Memory.isEmergencyStop() || !Memory.isAutoReplyMasterOn()) return  
    if (Agent.running) return  

    val now = System.currentTimeMillis()  
    if (now - lastAutoTriggerAt < 5000L) return  

    // Detect new unread chat in WhatsApp list or new incoming message inside open chat  
    val unreadContact = findFirstUnreadChatContact()  
    if (unreadContact != null && Memory.canAutoReplyTo(unreadContact)) {  
        lastAutoTriggerAt = now  
        Agent.triggerAutoReplyFromScreen(this, unreadContact)  
    }  
}  

override fun onInterrupt() {}  

private fun collect(n: AccessibilityNodeInfo?, out: MutableList<AccessibilityNodeInfo>) {  
    if (n == null || out.size >= 40) return  
    if (n.isVisibleToUser) {  
        val label = (n.text ?: n.contentDescription)?.toString()  
        if (!label.isNullOrBlank() || n.isClickable || n.isEditable) out.add(n)  
    }  
    for (i in 0 until n.childCount) collect(n.getChild(i), out)  
}  

fun readScreen(): String {  
    val root = rootInActiveWindow ?: return "(screen not readable)"  
    val list = mutableListOf<AccessibilityNodeInfo>()  
    collect(root, list)  
    nodes = list  
    val sb = StringBuilder()  
    list.forEachIndexed { i, n ->  
        val label = (n.text ?: n.contentDescription)?.toString()?.replace("\n", " ")?.take(40) ?: ""  
        val kind = when {  
            n.isEditable -> "input"  
            n.isClickable -> "button"  
            else -> "text"  
        }  
        sb.append("[$i] $kind \"$label\"\n")  
    }  
    return sb.toString().take(1800)  
}  

private fun tap(x: Float, y: Float) {  
    val p = Path().apply { moveTo(x, y) }  
    val g = GestureDescription.Builder()  
        .addStroke(GestureDescription.StrokeDescription(p, 0, 60)).build()  
    dispatchGesture(g, null, null)  
}  

fun click(id: Int): String {  
    val node = nodes.getOrNull(id) ?: return "invalid id $id"  
    var n: AccessibilityNodeInfo? = node  
    while (n != null && !n.isClickable) n = n.parent  
    if (n != null && n.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return "clicked $id"  
    val r = Rect(); node.getBoundsInScreen(r)  
    tap(r.exactCenterX(), r.exactCenterY())  
    return "tapped $id"  
}  

fun typeText(text: String): String {  
    val target = nodes.firstOrNull { it.isEditable && it.isFocused }  
        ?: nodes.firstOrNull { it.isEditable }  
        ?: return "no input field"  
    target.performAction(AccessibilityNodeInfo.ACTION_FOCUS)  
    val b = Bundle()  
    b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)  
    target.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)  
    return "typed"  
}  

fun scroll(): String {  
    val m = resources.displayMetrics  
    val p = Path().apply {  
        moveTo(m.widthPixels / 2f, m.heightPixels * 0.7f)  
        lineTo(m.widthPixels / 2f, m.heightPixels * 0.3f)  
    }  
    val g = GestureDescription.Builder()  
        .addStroke(GestureDescription.StrokeDescription(p, 0, 300)).build()  
    dispatchGesture(g, null, null)  
    return "scrolled"  
}  

fun back(): String { performGlobalAction(GLOBAL_ACTION_BACK); return "back" }  
fun home(): String { performGlobalAction(GLOBAL_ACTION_HOME); return "home" }  

private val blocked = listOf("paytm", "phonepe", "gpay", "google pay", "bank", "upi", "bhim", "wallet")  

fun openApp(name: String): String {  
    if (blocked.any { name.contains(it, ignoreCase = true) })  
        return "BLOCKED: payment/bank apps allowed nahi"  
    val pm = packageManager  
    val aliases = mapOf(  
        "instagram" to "com.instagram.android",  
        "insta" to "com.instagram.android",  
        "whatsapp" to "com.whatsapp",  
        "whats app" to "com.whatsapp",  
        "wa" to "com.whatsapp",  
        "youtube" to "com.google.android.youtube",  
        "chrome" to "com.android.chrome",  
        "facebook" to "com.facebook.katana",  
        "telegram" to "org.telegram.messenger",  
        "snapchat" to "com.snapchat.android",  
        "gmail" to "com.google.android.gm"  
    )  
    val key = name.trim().lowercase()  
    val preferred = aliases[key]  
    val installed = pm.getInstalledApplications(0).filter {  
        pm.getLaunchIntentForPackage(it.packageName) != null  
    }  
    val app = installed.firstOrNull { preferred != null && it.packageName == preferred }  
        ?: installed.firstOrNull { pm.getApplicationLabel(it).toString().equals(name.trim(), ignoreCase = true) }  
        ?: installed.firstOrNull { pm.getApplicationLabel(it).toString().contains(name.trim(), ignoreCase = true) }  
        ?: return "app not found: $name"  
    val i = pm.getLaunchIntentForPackage(app.packageName)!!  
    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)  
    startActivity(i)  
    return "opened $name"  
}  

/** Finds the first visible unread chat row in WhatsApp chat list */  
fun findFirstUnreadChatContact(): String? {  
    val root = rootInActiveWindow ?: return null  
    var resultName: String? = null  
    fun walk(n: AccessibilityNodeInfo?) {  
        if (n == null || resultName != null) return  
        val id = n.viewIdResourceName ?: ""  
        if (id.endsWith("conversations_row_contact_name") && n.isVisibleToUser) {  
            val contactName = n.text?.toString()?.trim().orEmpty()  
            var row: AccessibilityNodeInfo? = n.parent  
            var hasUnread = false  
            for (up in 0..3) {  
                if (row == null) break  
                if (containsUnreadBadge(row)) { hasUnread = true; break }  
                row = row.parent  
            }  
            if (hasUnread && contactName.isNotEmpty()) {  
                resultName = contactName  
                return  
            }  
        }  
        for (i in 0 until n.childCount) walk(n.getChild(i))  
    }  
    walk(root)  
    return resultName  
}  

private fun containsUnreadBadge(node: AccessibilityNodeInfo?): Boolean {  
    if (node == null) return false  
    val id = node.viewIdResourceName ?: ""  
    val desc = node.contentDescription?.toString()?.lowercase() ?: ""  
    if (id.contains("unread") || desc.contains("unread")) return true  
    for (i in 0 until node.childCount) {  
        if (containsUnreadBadge(node.getChild(i))) return true  
    }  
    return false  
}  

fun clickFirstChat(): String? {  
    val root = rootInActiveWindow ?: return null  
    var found: AccessibilityNodeInfo? = null  
    fun walk(n: AccessibilityNodeInfo?) {  
        if (n == null || found != null) return  
        val id = n.viewIdResourceName ?: ""  
        if (id.endsWith("conversations_row_contact_name") && n.isVisibleToUser) { found = n; return }  
        for (i in 0 until n.childCount) walk(n.getChild(i))  
    }  
    walk(root)  
    val f = found ?: return null  
    val name = f.text?.toString() ?: ""  
    var c: AccessibilityNodeInfo? = f  
    while (c != null && !c.isClickable) c = c.parent  
    return if (c != null && c.performAction(AccessibilityNodeInfo.ACTION_CLICK)) name else null  
}  

fun getOpenChatTitle(): String {  
    val root = rootInActiveWindow ?: return ""  
    var title = ""  
    fun walk(n: AccessibilityNodeInfo?) {  
        if (n == null || title.isNotEmpty()) return  
        val id = n.viewIdResourceName ?: ""  
        if ((id.endsWith("conversation_contact_name") || id.endsWith("toolbar_title")) && n.isVisibleToUser) {  
            title = n.text?.toString()?.trim().orEmpty()  
            return  
        }  
        for (i in 0 until n.childCount) walk(n.getChild(i))  
    }  
    walk(root)  
    return title  
}  

fun currentPackage(): String? = rootInActiveWindow?.packageName?.toString()  

fun clickByLabel(label: String, skipEditable: Boolean = false): Boolean {  
    val root = rootInActiveWindow ?: return false  
    val found = root.findAccessibilityNodeInfosByText(label)  
        .firstOrNull { it.isVisibleToUser && !(skipEditable && it.isEditable) } ?: return false  
    var n: AccessibilityNodeInfo? = found  
    while (n != null && !n.isClickable) n = n.parent  
    if (n != null && n.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true  
    val r = Rect(); found.getBoundsInScreen(r)  
    tap(r.exactCenterX(), r.exactCenterY())  
    return true  
}  

fun readAllText(): List<String> {  
    val root = rootInActiveWindow ?: return emptyList()  
    val out = mutableListOf<String>()  
    fun walk(n: AccessibilityNodeInfo?) {  
        if (n == null || out.size > 200) return  
        if (n.isVisibleToUser && !n.isEditable) {  
            val t = n.text?.toString()  
            if (!t.isNullOrBlank()) out.add(t.trim())  
        }  
        for (i in 0 until n.childCount) walk(n.getChild(i))  
    }  
    walk(root)  
    return out  
}  

fun typeInEditable(text: String): Boolean {  
    val root = rootInActiveWindow ?: return false  
    var target: AccessibilityNodeInfo? = null  
    fun walk(n: AccessibilityNodeInfo?) {  
        if (n == null || target != null) return  
        if (n.isVisibleToUser && n.isEditable) { target = n; return }  
        for (i in 0 until n.childCount) walk(n.getChild(i))  
    }  
    walk(root)  
    val t = target ?: return false  
    t.performAction(AccessibilityNodeInfo.ACTION_FOCUS)  
    val b = Bundle()  
    b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)  
    return t.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)  
}

}
