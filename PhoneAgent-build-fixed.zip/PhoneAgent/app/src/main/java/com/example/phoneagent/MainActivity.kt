package com.example.phoneagent

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.OpenableColumns
import android.provider.Settings
import android.speech.RecognizerIntent
import android.text.Html
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import java.io.File
import java.util.zip.ZipInputStream

class MainActivity : Activity() {
// Premium Deep Obsidian & Glassmorphic Accent Palette
private val BG = Color.parseColor("#0B0D12")
private val CARD = Color.parseColor("#141821")
private val CARD2 = Color.parseColor("#1E2433")
private val ACCENT = Color.parseColor("#7C5CFF")
private val GOLD = Color.parseColor("#F59E0B")
private val MUTED = Color.parseColor("#94A3B8")
private val GREEN = Color.parseColor("#10B981")
private val RED = Color.parseColor("#EF4444")

private val MP = ViewGroup.LayoutParams.MATCH_PARENT  
private val WC = ViewGroup.LayoutParams.WRAP_CONTENT  
private val PICK = 1  
private val VOICE = 2  
private val PERM = 3  
private val DOC_PICK = 4  
private val BACKUP_PICK = 5  
private val h = Handler(Looper.getMainLooper())  

private lateinit var chat: LinearLayout  
private lateinit var scroll: ScrollView  
private lateinit var hint: LinearLayout  
private lateinit var note: TextView  
private lateinit var input: EditText  
private lateinit var chipModel: TextView  
private lateinit var chipCtl: TextView  
private lateinit var chipListen: TextView  
private lateinit var btnAutoMaster: TextView  
private lateinit var btnAutoAll: TextView  
private lateinit var btnEmergency: TextView  
private lateinit var tvSelectedSummary: TextView  
private lateinit var stopBar: TextView  
private lateinit var settings: LinearLayout  
private var modelStatus = ""  

private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()  

private fun shape(color: Int, radius: Int, oval: Boolean = false, strokeColor: Int = 0): GradientDrawable =  
    GradientDrawable().apply {  
        setColor(color)  
        if (oval) shape = GradientDrawable.OVAL else cornerRadius = dp(radius).toFloat()  
        if (strokeColor != 0) setStroke(dp(1), strokeColor)  
    }  

private fun tv(msg: String, size: Float, color: Int, bold: Boolean = false): TextView =  
    TextView(this).apply {  
        text = msg  
        textSize = size  
        setTextColor(color)  
        if (bold) setTypeface(typeface, Typeface.BOLD)  
    }  

private fun circle(label: String, sizeDp: Int, color: Int, onClick: () -> Unit): TextView =  
    TextView(this).apply {  
        text = label  
        textSize = 18f  
        gravity = Gravity.CENTER  
        setTextColor(Color.WHITE)  
        background = shape(color, 0, true)  
        layoutParams = LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp))  
        setOnClickListener { onClick() }  
    }  

private fun btn(label: String, bgColor: Int = CARD2, onClick: () -> Unit): TextView =  
    TextView(this).apply {  
        text = label  
        textSize = 13f  
        gravity = Gravity.CENTER  
        setTextColor(Color.WHITE)  
        setTypeface(typeface, Typeface.BOLD)  
        setPadding(dp(12), dp(11), dp(12), dp(11))  
        background = shape(bgColor, 12)  
        layoutParams = LinearLayout.LayoutParams(MP, WC).apply { topMargin = dp(8) }  
        setOnClickListener { onClick() }  
    }  

private fun chip(onClick: () -> Unit): TextView =  
    TextView(this).apply {  
        textSize = 12f  
        setTypeface(typeface, Typeface.BOLD)  
        setPadding(dp(11), dp(7), dp(11), dp(7))  
        layoutParams = LinearLayout.LayoutParams(WC, WC).apply { marginEnd = dp(6) }  
        setOnClickListener { onClick() }  
    }  

private fun styleChip(c: TextView, ok: Boolean, label: String) {  
    c.text = label + if (ok) " ✓" else " ✗"  
    c.setTextColor(if (ok) GREEN else MUTED)  
    c.background = shape(  
        if (ok) Color.parseColor("#0F2E22") else Color.parseColor("#181C26"),  
        20,  
        strokeColor = if (ok) Color.parseColor("#1E4D3B") else Color.parseColor("#2A3040")  
    )  
}  

override fun onCreate(b: Bundle?) {  
    super.onCreate(b)  
    window.statusBarColor = BG  
    window.navigationBarColor = BG  
    Agent.init(this)  
    Speaker.init(this)  
    Agent.logger = { onLog(it) }  
    setContentView(build())  
    val f = File(filesDir, "model.task")  
    if (f.exists() && !Agent.llmReady) loadModel(f)  
    tick.run()  
}  

override fun onDestroy() {  
    h.removeCallbacks(tick)  
    Agent.logger = null  
    super.onDestroy()  
}  

override fun onResume() {  
    super.onResume()  
    refresh()  
}  

private val tick = object : Runnable {  
    override fun run() {  
        refresh()  
        h.postDelayed(this, 700)  
    }  
}  

private fun refresh() {  
    styleChip(chipModel, Agent.llmReady, "🧠 Model")  
    styleChip(chipCtl, AgentService.instance != null, "🖐 Control")  
    styleChip(chipListen, VoiceService.running, "👂 Sunna")  

    val masterOn = Memory.isAutoReplyMasterOn()  
    val allOn = Memory.isAutoReplyAllOn()  
    val eStop = Memory.isEmergencyStop()  

    btnAutoMaster.text = if (masterOn) "🤖 Auto Reply: ON" else "🤖 Auto Reply: OFF"  
    btnAutoMaster.background = shape(if (masterOn) Color.parseColor("#0F3D2E") else CARD2, 12, strokeColor = if (masterOn) GREEN else 0)  
    btnAutoMaster.setTextColor(if (masterOn) GREEN else Color.WHITE)  

    btnAutoAll.text = if (allOn) "🌐 ALL Chats: ON" else "🌐 ALL Chats: OFF"  
    btnAutoAll.background = shape(if (allOn) Color.parseColor("#2D2159") else CARD2, 12, strokeColor = if (allOn) ACCENT else 0)  
    btnAutoAll.setTextColor(if (allOn) Color.WHITE else MUTED)  

    btnEmergency.text = if (eStop) "🚨 EMERGENCY: STOPPED (Tap to Reset)" else "🛑 EMERGENCY STOP"  
    btnEmergency.background = shape(if (eStop) Color.parseColor("#7F1D1D") else Color.parseColor("#991B1B"), 12, strokeColor = RED)  

    val selected = Memory.getSelectedContacts()  
    tvSelectedSummary.text = when {  
        eStop -> "⚠️ Emergency Stop Active — Sabhi Auto-Reply aur actions band hain."  
        !masterOn -> "Auto-Reply abhi OFF hai. ON karne par 1.5s padhkar aapki style me reply jayega."  
        allOn -> "✅ Sabhi eligible WhatsApp chats ke liye Auto-Reply active hai."  
        selected.isEmpty() -> "🎯 Koi specific contact chuna nahi gaya. '+ Contact Chuno' dabao ya ALL ON karo."  
        else -> "🎯 Selected (${selected.size}): ${selected.joinToString(", ")}"  
    }  

    stopBar.visibility = if (Agent.running) View.VISIBLE else View.GONE  
    note.text = when {  
        AgentService.instance == null -> "① 'Control' dabao aur Phone Agent Accessibility ko ON karo"  
        !VoiceService.running -> "② 'Sunna' dabao taaki background me bhi awaaz sune"  
        !Agent.llmReady -> if (modelStatus.isNotEmpty()) modelStatus else "Basic & Auto-Reply ready ✅ (Deep chat ke liye .task model load karein)"  
        else -> "Sab ready ✅  Bolo: \"hey Phool Kumari, open WhatsApp\""  
    }  
}  

private fun build(): View {  
    val root = LinearLayout(this).apply {  
        orientation = LinearLayout.VERTICAL  
        setBackgroundColor(BG)  
        setPadding(dp(14), dp(14), dp(14), dp(10))  
    }  

    // Premium Header  
    val head = LinearLayout(this).apply {  
        orientation = LinearLayout.HORIZONTAL  
        gravity = Gravity.CENTER_VERTICAL  
    }  
    val titles = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }  
    titles.addView(tv("Phool Kumari ✨", 24f, Color.WHITE, true))  
    titles.addView(tv("Personal AI • Hindi & Hinglish • Smart Memory", 12f, MUTED))  
    head.addView(titles, LinearLayout.LayoutParams(0, WC, 1f))  
    head.addView(circle("⚙", 40, CARD2) {  
        settings.visibility = if (settings.visibility == View.VISIBLE) View.GONE else View.VISIBLE  
    })  
    root.addView(head)  

    // Status Chips Row  
    val chips = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }  
    chipModel = chip { pickModel() }  
    chipCtl = chip { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }  
    chipListen = chip { toggleListen() }  
    chips.addView(chipModel); chips.addView(chipCtl); chips.addView(chipListen)  
    root.addView(chips, LinearLayout.LayoutParams(MP, WC).apply { topMargin = dp(10) })  

    // Premium WhatsApp Auto-Reply & Emergency Control Dashboard Card  
    val waCard = LinearLayout(this).apply {  
        orientation = LinearLayout.VERTICAL  
        background = shape(CARD, 16, strokeColor = Color.parseColor("#252B3B"))  
        setPadding(dp(12), dp(12), dp(12), dp(12))  
    }  
    waCard.addView(tv("💬 WhatsApp Auto-Reply & Memory Control", 14f, Color.WHITE, true))  

    val toggleRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }  
    btnAutoMaster = TextView(this).apply {  
        textSize = 12f; gravity = Gravity.CENTER; setTypeface(typeface, Typeface.BOLD)  
        setPadding(dp(8), dp(10), dp(8), dp(10))  
        setOnClickListener {  
            if (Memory.isEmergencyStop()) {  
                addNote("Pehle Emergency Stop reset karo!")  
            } else {  
                val next = !Memory.isAutoReplyMasterOn()  
                Memory.setAutoReplyMasterOn(next)  
                refresh()  
            }  
        }  
    }  
    btnAutoAll = TextView(this).apply {  
        textSize = 12f; gravity = Gravity.CENTER; setTypeface(typeface, Typeface.BOLD)  
        setPadding(dp(8), dp(10), dp(8), dp(10))  
        setOnClickListener {  
            val next = !Memory.isAutoReplyAllOn()  
            Memory.setAutoReplyAllOn(next)  
            if (next && !Memory.isEmergencyStop()) Memory.setAutoReplyMasterOn(true)  
            refresh()  
        }  
    }  
    toggleRow.addView(btnAutoMaster, LinearLayout.LayoutParams(0, WC, 1f).apply { marginEnd = dp(6) })  
    toggleRow.addView(btnAutoAll, LinearLayout.LayoutParams(0, WC, 1f).apply { marginStart = dp(6) })  
    waCard.addView(toggleRow, LinearLayout.LayoutParams(MP, WC).apply { topMargin = dp(8) })  

    // Selected Contacts & Relationship Quick Buttons  
    val personRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }  
    val btnManageContacts = TextView(this).apply {  
        text = "👤 Contacts Chuno"  
        textSize = 12f; gravity = Gravity.CENTER; setTextColor(Color.WHITE); setTypeface(typeface, Typeface.BOLD)  
        background = shape(CARD2, 10)  
        setPadding(dp(8), dp(9), dp(8), dp(9))  
        setOnClickListener { showContactSelectorDialog() }  
    }  
    val btnSetRelation = TextView(this).apply {  
        text = "❤️ Rishta / Naam Set"  
        textSize = 12f; gravity = Gravity.CENTER; setTextColor(GOLD); setTypeface(typeface, Typeface.BOLD)  
        background = shape(CARD2, 10)  
        setPadding(dp(8), dp(9), dp(8), dp(9))  
        setOnClickListener { showRelationDialog() }  
    }  
    personRow.addView(btnManageContacts, LinearLayout.LayoutParams(0, WC, 1f).apply { marginEnd = dp(6) })  
    personRow.addView(btnSetRelation, LinearLayout.LayoutParams(0, WC, 1f).apply { marginStart = dp(6) })  
    waCard.addView(personRow, LinearLayout.LayoutParams(MP, WC).apply { topMargin = dp(8) })  

    tvSelectedSummary = tv("", 11f, MUTED).apply { setPadding(dp(2), dp(6), dp(2), dp(4)) }  
    waCard.addView(tvSelectedSummary)  

    btnEmergency = TextView(this).apply {  
        textSize = 12f; gravity = Gravity.CENTER; setTextColor(Color.WHITE); setTypeface(typeface, Typeface.BOLD)  
        setPadding(dp(10), dp(10), dp(10), dp(10))  
        setOnClickListener {  
            if (Memory.isEmergencyStop()) {  
                Memory.setEmergencyStop(false)  
                addNote("✅ Emergency Stop reset ho gaya.")  
            } else {  
                Agent.emergencyStopAll()  
                Speaker.stop()  
                addNote("🚨 EMERGENCY STOP: Sab kuch turant rok diya gaya!")  
            }  
            refresh()  
        }  
    }  
    waCard.addView(btnEmergency, LinearLayout.LayoutParams(MP, WC).apply { topMargin = dp(6) })  
    root.addView(waCard, LinearLayout.LayoutParams(MP, WC).apply { topMargin = dp(10) })  

    // Collapsible Settings Panel  
    settings = LinearLayout(this).apply {  
        orientation = LinearLayout.VERTICAL  
        visibility = View.GONE  
        background = shape(CARD, 16)  
        setPadding(dp(14), dp(10), dp(14), dp(14))  
    }  
    val approve = CheckBox(this).apply {  
        text = "Message bhejne se pehle mujhse poochho"  
        setTextColor(Color.WHITE)  
        isChecked = getSharedPreferences("cfg", 0).getBoolean("approve", true)  
        setOnCheckedChangeListener { _, c ->  
            getSharedPreferences("cfg", 0).edit().putBoolean("approve", c).apply()  
            Agent.approveFirst = c  
        }  
    }  
    settings.addView(approve)  

    val waRead = CheckBox(this).apply {  
        text = "Purani chat se likhne ki shaili (style) seekho"  
        setTextColor(Color.WHITE)  
        isChecked = getSharedPreferences("cfg", 0).getBoolean("wa_read", true)  
        setOnCheckedChangeListener { _, enabled ->  
            getSharedPreferences("cfg", 0).edit().putBoolean("wa_read", enabled).apply()  
            Agent.whatsappStyleLearning = enabled  
        }  
    }  
    settings.addView(waRead)  
    settings.addView(tv("⏱️ Read delay: 1.5 second (1–2 sec natural pause)", 12f, MUTED))  
    settings.addView(btn("📚 Study file import karo (PDF / DOCX / TXT)") { pickDocument() })  
    settings.addView(btn("💾 Memory ka TXT backup export karo") { exportMemory() })  
    settings.addView(btn("📂 AI model (.task file) chuno") { pickModel() })  
    settings.addView(btn("🧠 Saved Rishte & Memory dekho") {  
        addNote("Rishte: ${Memory.getAllRelations()}")  
        addNote("Yaad: ${Memory.notes()}")  
    })  
    settings.addView(btn("🗑 Memory saaf karo", Color.parseColor("#451A1A")) {  
        Memory.clear()  
        addNote("Memory saaf ho gayi")  
    })  
    root.addView(settings, LinearLayout.LayoutParams(MP, WC).apply { topMargin = dp(8) })  

    // Chat Area  
    chat = LinearLayout(this).apply {  
        orientation = LinearLayout.VERTICAL  
        setPadding(0, dp(6), 0, dp(6))  
    }  
    hint = LinearLayout(this).apply {  
        orientation = LinearLayout.VERTICAL  
        setPadding(0, dp(14), 0, 0)  
    }  
    hint.addView(tv("Namaste! 👋", 22f, Color.WHITE, true))  
    hint.addView(tv("Main tumhari boli, rishte (Baby, Bhai, Mummy) aur har vyakti ki alag memory yaad rakhti hoon.", 13f, MUTED))  
    note = tv("", 12f, ACCENT).apply { setPadding(0, dp(6), 0, dp(8)) }  
    hint.addView(note)  

    listOf(  
        "Riya ko Baby bulao",  
        "Mummy ko Mummy bolna",  
        "WhatsApp kholo aur reply do"  
    ).forEach { cmd ->  
        hint.addView(TextView(this).apply {  
            text = "“$cmd”"  
            textSize = 13f  
            setTextColor(Color.WHITE)  
            setPadding(dp(12), dp(8), dp(12), dp(8))  
            background = shape(CARD, 12)  
            layoutParams = LinearLayout.LayoutParams(WC, WC).apply { topMargin = dp(6) }  
            setOnClickListener { send(cmd) }  
        })  
    }  
    chat.addView(hint)  
    scroll = ScrollView(this).apply {  
        addView(chat)  
        isVerticalScrollBarEnabled = false  
    }  
    root.addView(scroll, LinearLayout.LayoutParams(MP, 0, 1f))  

    // Active Task Stop Bar  
    stopBar = tv("⏹  Roko (Agent abhi kaam kar raha hai)", 13f, Color.WHITE, true).apply {  
        gravity = Gravity.CENTER  
        setPadding(dp(12), dp(10), dp(12), dp(10))  
        background = shape(RED, 12)  
        visibility = View.GONE  
        setOnClickListener {  
            Agent.stop()  
            Speaker.stop()  
            addNote("Roka gaya")  
        }  
    }  
    root.addView(stopBar, LinearLayout.LayoutParams(MP, WC).apply { bottomMargin = dp(6) })  

    // Bottom Input Row  
    val row = LinearLayout(this).apply {  
        orientation = LinearLayout.HORIZONTAL  
        gravity = Gravity.CENTER_VERTICAL  
    }  
    input = EditText(this).apply {  
        hint = "Hindi ya Hinglish me likho…"  
        setHintTextColor(MUTED)  
        setTextColor(Color.WHITE)  
        textSize = 14f  
        background = shape(CARD, 24, strokeColor = Color.parseColor("#252B3B"))  
        setPadding(dp(16), dp(11), dp(16), dp(11))  
        inputType = InputType.TYPE_CLASS_TEXT  
        imeOptions = EditorInfo.IME_ACTION_SEND  
        setSingleLine(true)  
        setOnEditorActionListener { _, a, _ ->  
            if (a == EditorInfo.IME_ACTION_SEND) {  
                send(text.toString())  
                true  
            } else false  
        }  
    }  
    row.addView(input, LinearLayout.LayoutParams(0, WC, 1f))  
    val sendB = circle("➤", 44, CARD2) { send(input.text.toString()) }  
    row.addView(sendB, (sendB.layoutParams as LinearLayout.LayoutParams).apply { marginStart = dp(8) })  
    val mic = circle("🎤", 50, ACCENT) { listenOnce() }  
    row.addView(mic, (mic.layoutParams as LinearLayout.LayoutParams).apply { marginStart = dp(8) })  
    root.addView(row)  
    return root  
}  

private fun showContactSelectorDialog() {  
    val box = LinearLayout(this).apply {  
        orientation = LinearLayout.VERTICAL  
        setPadding(dp(18), dp(12), dp(18), dp(8))  
    }  
    val etName = EditText(this).apply {  
        hint = "WhatsApp contact ka exact naam likho"  
    }  
    box.addView(etName)  

    val currentList = Memory.getSelectedContacts()  
    if (currentList.isNotEmpty()) {  
        box.addView(TextView(this).apply {  
            text = "Current Selected (tap to remove):\n" + currentList.joinToString(", ")  
            setPadding(0, dp(10), 0, dp(4))  
        })  
    }  

    AlertDialog.Builder(this)  
        .setTitle("Auto-Reply Contacts Manage")  
        .setView(box)  
        .setPositiveButton("Add / Enable") { _, _ ->  
            val name = etName.text.toString().trim()  
            if (name.isNotEmpty()) {  
                Memory.setContactSelected(name, true)  
                addNote("✅ $name ko Auto-Reply list me add kiya gaya.")  
                refresh()  
            }  
        }  
        .setNeutralButton("Remove") { _, _ ->  
            val name = etName.text.toString().trim()  
            if (name.isNotEmpty()) {  
                Memory.setContactSelected(name, false)  
                addNote("🗑 $name ko Auto-Reply list se hataya gaya.")  
                refresh()  
            }  
        }  
        .setNegativeButton("Cancel", null)  
        .show()  
}  

private fun showRelationDialog() {  
    val box = LinearLayout(this).apply {  
        orientation = LinearLayout.VERTICAL  
        setPadding(dp(18), dp(12), dp(18), dp(8))  
    }  
    val etContact = EditText(this).apply { hint = "Contact ka naam (e.g., Riya, Rohit, Maa)" }  
    val etRelation = EditText(this).apply { hint = "Sambodhan / Rishta (e.g., Baby, Bhai, Mummy)" }  
    box.addView(etContact)  
    box.addView(etRelation)  

    AlertDialog.Builder(this)  
        .setTitle("Sambodhan aur Rishta Save Karein")  
        .setView(box)  
        .setPositiveButton("Save") { _, _ ->  
            val c = etContact.text.toString().trim()  
            val r = etRelation.text.toString().trim()  
            if (c.isNotEmpty() && r.isNotEmpty()) {  
                Memory.setRelation(c, r)  
                addNote("❤️ Saved: $c ko '$r' kehkar baat hogi aur unki alag memory ban gayi.")  
            }  
        }  
        .setNegativeButton("Cancel", null)  
        .show()  
}  

private fun addBubble(msg: String, mine: Boolean) = runOnUiThread {  
    hint.visibility = View.GONE  
    val t = TextView(this).apply {  
        text = msg  
        textSize = 14f  
        setTextColor(Color.WHITE)  
        setPadding(dp(14), dp(10), dp(14), dp(10))  
        background = shape(if (mine) ACCENT else CARD2, 16)  
    }  
    val lp = LinearLayout.LayoutParams(WC, WC).apply {  
        gravity = if (mine) Gravity.END else Gravity.START  
        topMargin = dp(8)  
        if (mine) marginStart = dp(48) else marginEnd = dp(48)  
    }  
    chat.addView(t, lp)  
    scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }  
}  

private fun addNote(msg: String) = runOnUiThread {  
    hint.visibility = View.GONE  
    val t = tv(msg, 12f, MUTED).apply { gravity = Gravity.CENTER }  
    chat.addView(t, LinearLayout.LayoutParams(MP, WC).apply { topMargin = dp(6) })  
    scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }  
}  

private fun onLog(line: String) {  
    when {  
        line.startsWith("Suna:") -> addBubble(line.removePrefix("Suna:").trim(), true)  
        line.startsWith("🔊") -> addBubble(line.removePrefix("🔊").trim(), false)  
        line.startsWith("Phool Kumari:") -> {}  
        else -> addNote(line)  
    }  
}  

private fun say(t: String) {  
    Agent.log("🔊 $t")  
    Speaker.speak(t)  
}  

private fun send(t0: String) {  
    val t = t0.trim()  
    if (t.isEmpty()) return  
    input.setText("")  
    addBubble(t, true)  
    Agent.handle(t) { say(it) }  
}  

private fun listenOnce() {  
    val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {  
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)  
        putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")  
    }  
    try {  
        startActivityForResult(i, VOICE)  
    } catch (_: Exception) {  
        addNote("Voice input nahi mila. Google app update karo.")  
    }  
}  

private fun toggleListen() {  
    if (VoiceService.running) {  
        stopService(Intent(this, VoiceService::class.java))  
        addNote("Sunna band kiya")  
        return  
    }  
    val need = mutableListOf(Manifest.permission.RECORD_AUDIO)  
    if (Build.VERSION.SDK_INT >= 33) need.add(Manifest.permission.POST_NOTIFICATIONS)  
    if (need.all { checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }) startListening()  
    else requestPermissions(need.toTypedArray(), PERM)  
}  

private fun startListening() {  
    try {  
        val pm = getSystemService(PowerManager::class.java)  
        if (!pm.isIgnoringBatteryOptimizations(packageName)) {  
            startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))  
            addNote("Battery screen me 'Allow' dabao, phir 'Sunna' dobara dabao")  
            return  
        }  
    } catch (_: Exception) {}  
    startForegroundService(Intent(this, VoiceService::class.java))  
    addNote("Sun raha hoon.")  
}  

override fun onRequestPermissionsResult(c: Int, p: Array<out String>, r: IntArray) {  
    super.onRequestPermissionsResult(c, p, r)  
    if (c == PERM && checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)  
        startListening()  
    else addNote("Mic permission chahiye")  
}  

private fun pickDocument() {  
    val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {  
        addCategory(Intent.CATEGORY_OPENABLE)  
        type = "*/*"  
        putExtra(  
            Intent.EXTRA_MIME_TYPES,  
            arrayOf(  
                "application/pdf",  
                "application/vnd.openxmlformats-officedocument.wordprocessingml.document",  
                "text/plain",  
                "text/markdown",  
                "text/csv",  
                "application/json"  
            )  
        )  
    }  
    startActivityForResult(intent, DOC_PICK)  
}  

private fun pickModel() {  
    startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {  
        addCategory(Intent.CATEGORY_OPENABLE)  
        type = "*/*"  
    }, PICK)  
}  

override fun onActivityResult(req: Int, res: Int, data: Intent?) {  
    super.onActivityResult(req, res, data)  
    if (req == VOICE) {  
        val said = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()  
        if (res == RESULT_OK && said != null) send(said)  
        return  
    }  
    if (req == DOC_PICK && res == RESULT_OK && data?.data != null) {  
        importStudyFile(data.data!!)  
        return  
    }  
    if (req == BACKUP_PICK && res == RESULT_OK && data?.data != null) {  
        Thread {  
            try {  
                contentResolver.openOutputStream(data.data!!)?.bufferedWriter(Charsets.UTF_8)?.use {  
                    it.write(Memory.exportAllText())  
                }  
                runOnUiThread { addNote("Memory backup export ho gaya.") }  
            } catch (e: Throwable) {  
                runOnUiThread { addNote("Backup export nahi hua: ${e.message}") }  
            }  
        }.start()  
        return  
    }  
    if (req != PICK || res != RESULT_OK || data?.data == null) return  
    Thread {  
        try {  
            modelStatus = "Model copy ho raha hai… (1-2 minute, wait karo)"  
            Agent.stop()  
            Agent.unloadModel()  
            val tmp = File(filesDir, "model.tmp")  
            val out = File(filesDir, "model.task")  
            contentResolver.openInputStream(data.data!!)!!.use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }  
            out.delete()  
            tmp.renameTo(out)  
            loadModel(out)  
        } catch (e: Throwable) {  
            modelStatus = "Copy error: ${e.message}"  
        }  
    }.start()  
}  

private fun exportMemory() {  
    val i = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {  
        addCategory(Intent.CATEGORY_OPENABLE)  
        type = "text/plain"  
        putExtra(Intent.EXTRA_TITLE, "phool_kumari_memory_backup.txt")  
    }  
    startActivityForResult(i, BACKUP_PICK)  
}  

private fun importStudyFile(uri: Uri) {  
    addNote("File padh rahi hoon…")  
    Thread {  
        try {  
            val name = contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)  
                ?.use { c -> if (c.moveToFirst()) c.getString(0) else null } ?: "study_file"  
            val lower = name.lowercase()  
            val extracted: String = contentResolver.openInputStream(uri)?.use { input ->  
                when {  
                    lower.endsWith(".pdf") -> {  
                        PDFBoxResourceLoader.init(applicationContext)  
                        PDDocument.load(input).use { doc ->  
                            PDFTextStripper().getText(doc).take(1_500_000)  
                        }  
                    }  
                    lower.endsWith(".docx") -> {  
                        ZipInputStream(input).use { zip ->  
                            var entry = zip.nextEntry  
                            var xml = ""  
                            while (entry != null) {  
                                if (entry.name == "word/document.xml") {  
                                    xml = zip.readBytes().toString(Charsets.UTF_8)  
                                    break  
                                }  
                                entry = zip.nextEntry  
                            }  
                            Regex("<w:t[^>]*>(.*?)</w:t>").findAll(xml)  
                                .joinToString(" ") { m ->  
                                    Html.fromHtml(m.groupValues[1], Html.FROM_HTML_MODE_LEGACY).toString()  
                                }  
                                .take(1_500_000)  
                        }  
                    }  
                    else -> input.bufferedReader(Charsets.UTF_8).use { it.readText().take(1_500_000) }  
                }  
            }.orEmpty()  
            if (extracted.isBlank()) throw IllegalArgumentException("Is file se text nahi mila.")  
            val count = Memory.importText(name, extracted)  
            runOnUiThread { addNote("$name save ho gayi ($count characters).") }  
        } catch (e: Throwable) {  
            runOnUiThread { addNote("File import nahi hui: ${e.message ?: "unknown error"}") }  
        }  
    }.start()  
}  

private fun loadModel(f: File) {  
    Thread {  
        try {  
            if (Agent.llmReady) {  
                modelStatus = ""  
                return@Thread  
            }  
            modelStatus = "Model load ho raha hai…"  
            Agent.loadModel(this, f)  
            modelStatus = ""  
        } catch (e: Throwable) {  
            modelStatus = "Model error: ${e.message}"  
        }  
    }.start()  
}

}
