package com.example.phoneagent

import android.content.Context
import android.content.SharedPreferences
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Memory {
private var root: File? = null
private var factsFile: File? = null
private var historyFile: File? = null
private var docsDir: File? = null
private var contactsDir: File? = null
private var prefs: SharedPreferences? = null
private val lines = mutableListOf<String>()
private val history = mutableListOf<String>()
private val lock = Any()

fun init(ctx: Context) = synchronized(lock) {  
    if (root != null) return  
    val appCtx = ctx.applicationContext  
    prefs = appCtx.getSharedPreferences("phool_kumari_prefs", Context.MODE_PRIVATE)  
    root = File(appCtx.filesDir, "baby_memory").apply { mkdirs() }  
    factsFile = File(root, "memory.txt")  
    historyFile = File(root, "conversation.txt")  
    docsDir = File(root, "documents").apply { mkdirs() }  
    contactsDir = File(root, "contacts").apply { mkdirs() }  
    factsFile?.takeIf { it.exists() }?.readLines()?.let { lines.addAll(it) }  
    historyFile?.takeIf { it.exists() }?.readLines()?.let { history.addAll(it) }  
}  

@Synchronized fun add(kind: String, text: String) {  
    val clean = text.replace(Regex("\\s+"), " ").trim().take(2000)  
    if (clean.isBlank()) return  
    val entry = "$kind|$clean"  
    lines.add(entry)  
    factsFile?.appendText(entry + "\n")  
}  

@Synchronized fun notes(): List<String> = lines.filter { it.startsWith("N|") }.map { it.drop(2) }  
@Synchronized fun lessons(): List<String> = lines.filter { it.startsWith("L|") }.map { it.drop(2) }.takeLast(30)  

@Synchronized fun addTurn(s: String) {  
    val stamp = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date())  
    val entry = "$stamp | " + s.replace(Regex("\\s+"), " ").trim().take(1500)  
    history.add(entry)  
    historyFile?.appendText(entry + "\n")  
}  

@Synchronized fun historyText(): String = history.takeLast(24).joinToString("\n").takeLast(10000)  

@Synchronized fun notesText(): String =  
    (notes().takeLast(80).joinToString("; ") + " | Seekh: " +  
        lessons().takeLast(20).joinToString("; ")).take(5000)  

// ---------- Auto-Reply Controls (Master, ALL, Selected Contacts & Emergency Stop) ----------  
fun isAutoReplyMasterOn(): Boolean = prefs?.getBoolean("auto_reply_master", false) ?: false  
fun setAutoReplyMasterOn(on: Boolean) {  
    prefs?.edit()?.putBoolean("auto_reply_master", on)?.apply()  
}  

fun isAutoReplyAllOn(): Boolean = prefs?.getBoolean("auto_reply_all", false) ?: false  
fun setAutoReplyAllOn(on: Boolean) {  
    prefs?.edit()?.putBoolean("auto_reply_all", on)?.apply()  
}  

fun isEmergencyStop(): Boolean = prefs?.getBoolean("emergency_stop", false) ?: false  
fun setEmergencyStop(stop: Boolean) {  
    prefs?.edit()?.putBoolean("emergency_stop", stop)?.apply()  
}  

private fun contactKey(name: String): String =  
    name.trim().lowercase(Locale.ROOT).replace(Regex("[^a-z0-9_\\u0900-\\u097F]"), "_")  

fun isContactSelected(name: String): Boolean {  
    val k = contactKey(name)  
    if (k.isBlank()) return false  
    return prefs?.getBoolean("selected_contact_$k", false) ?: false  
}  

fun setContactSelected(name: String, selected: Boolean) {  
    val clean = name.trim()  
    val k = contactKey(clean)  
    if (k.isBlank()) return  
    val existing = getSelectedContacts().toMutableSet()  
    if (selected) existing.add(clean) else existing.removeAll { contactKey(it) == k }  
    prefs?.edit()  
        ?.putBoolean("selected_contact_$k", selected)  
        ?.putStringSet("selected_contacts_list", existing)  
        ?.apply()  
}  

fun getSelectedContacts(): List<String> {  
    return prefs?.getStringSet("selected_contacts_list", emptySet())  
        ?.sortedBy { it.lowercase(Locale.ROOT) } ?: emptyList()  
}  

fun canAutoReplyTo(contact: String): Boolean {  
    if (isEmergencyStop()) return false  
    if (!isAutoReplyMasterOn()) return false  
    if (isAutoReplyAllOn()) return true  
    return isContactSelected(contact)  
}  

// ---------- Per-Person Memory & Relationship (Baby, Bhai, Mummy, etc.) ----------  
fun setRelation(contact: String, relation: String) {  
    val cleanName = contact.trim()  
    val cleanRel = relation.trim()  
    if (cleanName.isBlank() || cleanRel.isBlank()) return  
    val k = contactKey(cleanName)  
    prefs?.edit()?.putString("rel_$k", cleanRel)?.apply()  
    add("N", "$cleanName ko '$cleanRel' kehte hain / rishta: $cleanRel")  
    appendContactMemory(cleanName, "Sambodhan / Rishta: $cleanRel")  
}  

fun getRelation(contact: String): String {  
    val k = contactKey(contact)  
    if (k.isBlank()) return ""  
    val saved = prefs?.getString("rel_$k", "") ?: ""  
    if (saved.isNotBlank()) return saved  
    val low = contact.lowercase(Locale.ROOT)  
    return when {  
        low.contains("mummy") || low.contains("maa") || low.contains("mom") || low.contains("mother") -> "Mummy"  
        low.contains("papa") || low.contains("dad") || low.contains("father") -> "Papa"  
        low.contains("bhai") || low.contains("bro") || low.contains("bhaiya") -> "Bhai"  
        low.contains("didi") || low.contains("sis") || low.contains("behen") -> "Didi"  
        low.contains("baby") || low.contains("jaan") || low.contains("babu") || low.contains("shona") -> "Baby"  
        else -> ""  
    }  
}  

fun getAllRelations(): Map<String, String> {  
    val map = mutableMapOf<String, String>()  
    prefs?.all?.forEach { (k, v) ->  
        if (k.startsWith("rel_") && v is String && v.isNotBlank()) {  
            map[k.removePrefix("rel_")] = v  
        }  
    }  
    return map  
}  

@Synchronized fun appendContactMemory(contact: String, entry: String) {  
    val dir = contactsDir ?: return  
    val k = contactKey(contact).ifBlank { return }  
    val clean = entry.replace(Regex("\\s+"), " ").trim().take(1200)  
    if (clean.isBlank()) return  
    val stamp = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date())  
    File(dir, "$k.txt").appendText("$stamp | $clean\n")  
}  

@Synchronized fun getContactMemory(contact: String, maxChars: Int = 2500): String {  
    val dir = contactsDir ?: return ""  
    val k = contactKey(contact).ifBlank { return "" }  
    val f = File(dir, "$k.txt")  
    if (!f.exists()) return ""  
    return try {  
        f.readLines().takeLast(30).joinToString("\n").takeLast(maxChars)  
    } catch (_: Exception) {  
        ""  
    }  
}  

@Synchronized fun learnUserStyleSample(sample: String) {  
    val clean = sample.replace(Regex("\\s+"), " ").trim()  
    if (clean.length < 2) return  
    add("S", clean.take(300))  
}  

@Synchronized fun getStyleSamples(maxSamples: Int = 20): String {  
    val samples = lines.filter { it.startsWith("S|") }.map { it.drop(2) }.takeLast(maxSamples)  
    return if (samples.isEmpty()) "" else samples.joinToString(" | ")  
}  

fun importText(name: String, content: String): Int = synchronized(lock) {  
    val dir = docsDir ?: return 0  
    val safe = name.substringAfterLast('/').replace(Regex("[^A-Za-z0-9._-]"), "_").take(80)  
        .ifBlank { "imported.txt" }  
    val body = content.replace("\u0000", "").trim()  
    if (body.isBlank()) return 0  
    val file = File(dir, "${System.currentTimeMillis()}_$safe")  
    file.writeText(body)  
    add("D", "Document imported: $safe (${body.length} characters)")  
    return body.length  
}  

@Synchronized fun documentNames(): List<String> =  
    docsDir?.listFiles()?.filter { it.isFile }?.sortedByDescending { it.lastModified() }  
        ?.map { it.name.substringAfter('_', it.name) } ?: emptyList()  

@Synchronized fun relevantDocuments(query: String, maxChars: Int = 5000): String {  
    val dir = docsDir ?: return ""  
    val terms = query.lowercase(Locale.ROOT)  
        .split(Regex("[^\\p{L}\\p{N}]+")).filter { it.length >= 3 }.toSet()  
    if (terms.isEmpty()) return ""  
    val out = StringBuilder()  
    val files = dir.listFiles()?.filter { it.isFile }?.sortedByDescending { it.lastModified() } ?: return ""  
    for (f in files) {  
        val text = try { f.readText() } catch (_: Exception) { continue }  
        val chunks = text.chunked(900)  
        val ranked = chunks.map { chunk ->  
            val low = chunk.lowercase(Locale.ROOT)  
            terms.count { low.contains(it) }  
        }.withIndex().filter { it.value > 0 }.sortedByDescending { it.value }.take(3)  
        for ((idx, _) in ranked) {  
            val excerpt = chunks[idx]  
            if (out.length + excerpt.length > maxChars) break  
            out.append("\n[${f.name.substringAfter('_', f.name)}]\n")  
                .append(excerpt).append("\n")  
        }  
        if (out.length >= maxChars) break  
    }  
    return out.toString().take(maxChars)  
}  

@Synchronized fun relevantHistory(query: String, maxChars: Int = 5000): String {  
    val terms = query.lowercase(Locale.ROOT)  
        .split(Regex("[^\\p{L}\\p{N}]+")).filter { it.length >= 3 }.toSet()  
    if (terms.isEmpty()) return history.takeLast(16).joinToString("\n").take(maxChars)  
    val ranked = history.mapIndexed { index, line ->  
        val low = line.lowercase(Locale.ROOT)  
        val score = terms.count { low.contains(it) }  
        Triple(index, score, line)  
    }.filter { it.second > 0 }.sortedWith(compareByDescending<Triple<Int, Int, String>> { it.second }.thenByDescending { it.first })  
        .take(18).sortedBy { it.first }  
    return ranked.joinToString("\n") { it.third }.takeLast(maxChars)  
}  

@Synchronized fun exportAllText(): String {  
    val out = StringBuilder("PHOOL KUMARI MEMORY BACKUP\n\n[FACTS, STYLE & LEARNED PREFERENCES]\n")  
    lines.forEach { out.append(it).append('\n') }  
    out.append("\n[PER-CONTACT MEMORIES]\n")  
    contactsDir?.listFiles()?.filter { it.isFile }?.sortedBy { it.name }?.forEach { cf ->  
        out.append("\n=== Contact: ").append(cf.nameWithoutExtension).append(" ===\n")  
        try { out.append(cf.readText()).append('\n') } catch (_: Exception) {}  
    }  
    out.append("\n[CONVERSATION HISTORY]\n")  
    history.forEach { out.append(it).append('\n') }  
    out.append("\n[IMPORTED DOCUMENTS]\n")  
    val files = docsDir?.listFiles()?.filter { it.isFile }?.sortedBy { it.name } ?: emptyList()  
    for (file in files) {  
        out.append("\n--- ").append(file.name.substringAfter('_', file.name)).append(" ---\n")  
        try { out.append(file.readText()).append('\n') } catch (_: Exception) { }  
    }  
    return out.toString()  
}  

@Synchronized fun clear() {  
    lines.clear(); history.clear()  
    factsFile?.writeText(""); historyFile?.writeText("")  
    docsDir?.listFiles()?.forEach { it.delete() }  
    contactsDir?.listFiles()?.forEach { it.delete() }  
}

}
