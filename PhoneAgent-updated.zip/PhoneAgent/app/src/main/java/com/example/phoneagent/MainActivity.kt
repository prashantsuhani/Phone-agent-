package com.example.phoneagent

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.speech.RecognizerIntent
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.io.File

class MainActivity : Activity() {
    private val BG = Color.parseColor("#0F1115")
    private val CARD = Color.parseColor("#1A1D24")
    private val CARD2 = Color.parseColor("#252A35")
    private val ACCENT = Color.parseColor("#7C5CFF")
    private val MUTED = Color.parseColor("#9CA3AF")
    private val GREEN = Color.parseColor("#4ADE80")
    private val MP = ViewGroup.LayoutParams.MATCH_PARENT
    private val WC = ViewGroup.LayoutParams.WRAP_CONTENT
    private val PICK = 1
    private val VOICE = 2
    private val PERM = 3
    private val DOC_PICK = 4
    private val BACKUP_PICK = 5
    private val h = Handler(Looper.getMainLooper())

    private lateinit var chat: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var hint: LinearLayout
    private lateinit var note: TextView
    private lateinit var input: EditText
    private lateinit var chipModel: TextView
    private lateinit var chipCtl: TextView
    private lateinit var chipListen: TextView
    private lateinit var stopBar: TextView
    private lateinit var settings: LinearLayout
    private var modelStatus = ""

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun shape(color: Int, radius: Int, oval: Boolean = false) = GradientDrawable().apply {
        setColor(color)
        if (oval) shape = GradientDrawable.OVAL else cornerRadius = dp(radius).toFloat()
    }

    private fun tv(msg: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = msg; textSize = size; setTextColor(color)
        if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
    }

    private fun circle(label: String, sizeDp: Int, color: Int, onClick: () -> Unit) = TextView(this).apply {
        text = label; textSize = 20f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
        background = shape(color, 0, true)
        layoutParams = LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp))
        setOnClickListener { onClick() }
    }

    private fun btn(label: String, onClick: () -> Unit) = TextView(this).apply {
        text = label; textSize = 14f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
        setPadding(dp(12), dp(12), dp(12), dp(12))
        background = shape(CARD2, 12)
        layoutParams = LinearLayout.LayoutParams(MP, WC).apply { topMargin = dp(8) }
        setOnClickListener { onClick() }
    }

    private fun chip(onClick: () -> Unit) = TextView(this).apply {
        textSize = 12f
        setPadding(dp(12), dp(7), dp(12), dp(7))
        layoutParams = LinearLayout.LayoutParams(WC, WC).apply { marginEnd = dp(8) }
        setOnClickListener { onClick() }
    }

    private fun styleChip(c: TextView, ok: Boolean, label: String) {
        c.text = label + if (ok) "  ✓" else "  ✗"
        c.setTextColor(if (ok) GREEN else MUTED)
        c.background = shape(if (ok) Color.parseColor("#14301F") else Color.parseColor("#1F232B"), 20)
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = BG
        window.navigationBarColor = BG
        Agent.init(this)
        Speaker.init(this)
        Agent.logger = { onLog(it) }
        setContentView(build())
        val f = File(filesDir, "model.task")
        if (f.exists() && !Agent.llmReady) loadModel(f)
        tick.run()
    }

    override fun onDestroy() {
        h.removeCallbacks(tick)
        Agent.logger = null
        super.onDestroy()
    }

    override fun onResume() { super.onResume(); refresh() }

    private val tick = object : Runnable {
        override fun run() { refresh(); h.postDelayed(this, 700) }
    }

    private fun refresh() {
        styleChip(chipModel, Agent.llmReady, "🧠 Model")
        styleChip(chipCtl, AgentService.instance != null, "🖐 Control")
        styleChip(chipListen, VoiceService.running, "👂 Sunna")
        stopBar.visibility = if (Agent.running) View.VISIBLE else View.GONE
        note.text = when {
            AgentService.instance == null -> "① 'Control' dabao aur Phone Agent ko ON karo (app kholne/click karne ke liye)"
            !VoiceService.running -> "② 'Sunna' dabao taaki app band hone par bhi \"hey baby\" sune"
            !Agent.llmReady -> if (modelStatus.isNotEmpty()) modelStatus else "Basic commands ready ✅ (Model optional hai: baat-cheet/mushkil kaam ke liye)"
            else -> "Sab ready ✅  Bolo: \"hey Phool Kumari, open Instagram\""
        }
    }

    private fun build(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(BG)
            setPadding(dp(16), dp(16), dp(16), dp(12))
        }
        // header
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val titles = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        titles.addView(tv("Phool Kumari", 26f, Color.WHITE, true))
        titles.addView(tv("Personal AI • Tumhari boli, tumhara andaaz", 12f, MUTED))
        head.addView(titles, LinearLayout.LayoutParams(0, WC, 1f))
        head.addView(circle("⚙", 40, CARD) {
            settings.visibility = if (settings.visibility == View.VISIBLE) View.GONE else View.VISIBLE
        })
        root.addView(head)

        // status chips
        val chips = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        chipModel = chip { pickModel() }
        chipCtl = chip { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        chipListen = chip { toggleListen() }
        chips.addView(chipModel); chips.addView(chipCtl); chips.addView(chipListen)
        root.addView(chips, LinearLayout.LayoutParams(MP, WC).apply { topMargin = dp(14) })

        // settings panel
        settings = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
            background = shape(CARD, 16)
            setPadding(dp(14), dp(10), dp(14), dp(14))
        }
        val approve = CheckBox(this).apply {
            text = "Message bhejne se pehle mujhse poochho"
            setTextColor(Color.WHITE)
            isChecked = getSharedPreferences("cfg", 0).getBoolean("approve", true)
            setOnCheckedChangeListener { _, c ->
                getSharedPreferences("cfg", 0).edit().putBoolean("approve", c).apply(); Agent.approveFirst = c
            }
        }
        settings.addView(approve)
        val waRead = CheckBox(this).apply {
            text = "WhatsApp chat padhkar style ke hisaab se reply draft karo"
            setTextColor(Color.WHITE)
            isChecked = getSharedPreferences("cfg", 0).getBoolean("wa_read", true)
            setOnCheckedChangeListener { _, enabled ->
                getSharedPreferences("cfg", 0).edit().putBoolean("wa_read", enabled).apply()
                Agent.whatsappStyleLearning = enabled
            }
        }
        settings.addView(waRead)
        val delayInfo = tv("📖 Read delay: 1.5 second (1–2 sec)", 13f, MUTED).apply {
            setPadding(dp(4), dp(8), dp(4), dp(4))
        }
        settings.addView(delayInfo)
        settings.addView(btn("📚 Padhai ki file ya book import karo (PDF / DOCX / TXT)") { pickDocument() })
        settings.addView(btn("📄 Saved files dekho") { addNote("Saved study files: ${Memory.documentNames().joinToString()}") })
        settings.addView(btn("💾 Memory ka TXT backup export karo") { exportMemory() })
        settings.addView(btn("📂 AI model badlo (.task file)") { pickModel() })
        settings.addView(btn("🔊 Awaaz test") { say("Namaste, main Phool Kumari hoon. Meri awaaz aa rahi hai?") })
        settings.addView(btn("🧠 Memory dekho") {
            addNote("Yaad: ${Memory.notes()}"); addNote("Seekh: ${Memory.lessons()}")
        })
        settings.addView(btn("🗑 Memory saaf karo") { Memory.clear(); addNote("Memory saaf ho gayi") })
        root.addView(settings, LinearLayout.LayoutParams(MP, WC).apply { topMargin = dp(10) })

        // chat
        chat = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(8), 0, dp(8)) }
        hint = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(24), 0, 0) }
        hint.addView(tv("Namaste! 👋", 26f, Color.WHITE, true))\n        hint.addView(tv("Main tumhari baat samajhne aur tumhare style mein help karne ke liye hoon.", 13f, MUTED))
        note = tv("", 13f, ACCENT).apply { setPadding(0, dp(6), 0, dp(10)) }
        hint.addView(note)
        hint.addView(tv("Mic dabao ya likh ke bolo. Ye try karo:", 14f, MUTED))
        listOf(
            "open Instagram and scroll reels 15 second",
            "open WhatsApp",
            "main udaas hoon"
        ).forEach { cmd ->
            hint.addView(TextView(this).apply {
                text = "“$cmd”"; textSize = 14f; setTextColor(Color.WHITE)
                setPadding(dp(14), dp(10), dp(14), dp(10))
                background = shape(CARD, 14)
                layoutParams = LinearLayout.LayoutParams(WC, WC).apply { topMargin = dp(8) }
                setOnClickListener { send(cmd) }
            })
        }
        chat.addView(hint)
        scroll = ScrollView(this).apply { addView(chat); isVerticalScrollBarEnabled = false }
        root.addView(scroll, LinearLayout.LayoutParams(MP, 0, 1f))

        // stop bar
        stopBar = tv("⏹  Roko  (agent chal raha hai)", 14f, Color.WHITE, true).apply {
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(12), dp(12), dp(12))
            background = shape(Color.parseColor("#B91C1C"), 14)
            visibility = View.GONE
            setOnClickListener { Agent.stop(); Speaker.stop(); addNote("Roka gaya") }
        }
        root.addView(stopBar, LinearLayout.LayoutParams(MP, WC).apply { bottomMargin = dp(8) })

        // input row
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        input = EditText(this).apply {
            hint = "Message likho ya mic se bolo…"
            setHintTextColor(MUTED); setTextColor(Color.WHITE); textSize = 15f
            background = shape(CARD, 26)
            setPadding(dp(18), dp(12), dp(18), dp(12))
            inputType = InputType.TYPE_CLASS_TEXT
            imeOptions = EditorInfo.IME_ACTION_SEND
            setSingleLine(true)
            setOnEditorActionListener { _, a, _ ->
                if (a == EditorInfo.IME_ACTION_SEND) { send(text.toString()); true } else false
            }
        }
        row.addView(input, LinearLayout.LayoutParams(0, WC, 1f))
        val sendB = circle("➤", 46, CARD2) { send(input.text.toString()) }
        row.addView(sendB, (sendB.layoutParams as LinearLayout.LayoutParams).apply { marginStart = dp(8) })
        val mic = circle("🎤", 54, ACCENT) { listenOnce() }
        row.addView(mic, (mic.layoutParams as LinearLayout.LayoutParams).apply { marginStart = dp(8) })
        root.addView(row)
        return root
    }

    // ---------- chat ----------
    private fun addBubble(msg: String, mine: Boolean) = runOnUiThread {
        hint.visibility = View.GONE
        val t = TextView(this).apply {
            text = msg; textSize = 15f; setTextColor(Color.WHITE)
            setPadding(dp(14), dp(10), dp(14), dp(10))
            background = shape(if (mine) ACCENT else CARD2, 16)
        }
        val lp = LinearLayout.LayoutParams(WC, WC).apply {
            gravity = if (mine) Gravity.END else Gravity.START
            topMargin = dp(8)
            if (mine) marginStart = dp(56) else marginEnd = dp(56)
        }
        chat.addView(t, lp)
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun addNote(msg: String) = runOnUiThread {
        hint.visibility = View.GONE
        val t = tv(msg, 12f, MUTED).apply { gravity = Gravity.CENTER }
        chat.addView(t, LinearLayout.LayoutParams(MP, WC).apply { topMargin = dp(6) })
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun onLog(line: String) {
        when {
            line.startsWith("Suna:") -> addBubble(line.removePrefix("Suna:").trim(), true)
            line.startsWith("🔊") -> addBubble(line.removePrefix("🔊").trim(), false)
            line.startsWith("Phool Kumari:") -> {}
            else -> addNote(line)
        }
    }

    private fun say(t: String) { Agent.log("🔊 $t"); Speaker.speak(t) }

    private fun send(t0: String) {
        val t = t0.trim()
        if (t.isEmpty()) return
        input.setText("")
        addBubble(t, true)
        Agent.handle(t) { say(it) }
    }

    // ---------- voice ----------
    private fun listenOnce() {
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
        }
        try { startActivityForResult(i, VOICE) } catch (e: Exception) { addNote("Voice input nahi mila. Google app update karo.") }
    }

    private fun toggleListen() {
        if (VoiceService.running) {
            stopService(Intent(this, VoiceService::class.java))
            addNote("Sunna band kiya"); return
        }
        val need = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) need.add(Manifest.permission.POST_NOTIFICATIONS)
        if (need.all { checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }) startListening()
        else requestPermissions(need.toTypedArray(), PERM)
    }

    private fun startListening() {
        try {
            val pm = getSystemService(PowerManager::class.java)
            if (!pm.isIgnoringBatteryOptimizations(packageName)) {
                startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
                addNote("Battery screen me 'Allow' dabao, phir 'Sunna' dobara dabao")
                return
            }
        } catch (e: Exception) {}
        startForegroundService(Intent(this, VoiceService::class.java))
        addNote("Sun raha hoon. Ab app band karke bhi bolo: hey Phool Kumari, open Instagram")
    }

    override fun onRequestPermissionsResult(c: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(c, p, r)
        if (c == PERM && checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)
            startListening()
        else addNote("Mic permission chahiye")
    }

    // ---------- model ----------
    private fun pickDocument() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf(
                "application/pdf",
                "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                "text/plain", "text/markdown", "text/csv", "application/json"
            ))
        }
        startActivityForResult(intent, DOC_PICK)
    }

    private fun pickModel() {
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"
        }, PICK)
    }

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req == VOICE) {
            val said = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (res == RESULT_OK && said != null) send(said)
            return
        }
        if (req == DOC_PICK && res == RESULT_OK && data?.data != null) {
            importStudyFile(data.data!!)
            return
        }
        if (req == BACKUP_PICK && res == RESULT_OK && data?.data != null) {
            Thread {
                try {
                    contentResolver.openOutputStream(data.data!!)?.bufferedWriter(Charsets.UTF_8)?.use { it.write(Memory.exportAllText()) }
                    runOnUiThread { addNote("Memory backup export ho gaya. Is TXT file ko safe jagah rakhna.") }
                } catch (e: Throwable) { runOnUiThread { addNote("Backup export nahi hua: ${e.message}") } }
            }.start()
            return
        }
        if (req != PICK || res != RESULT_OK || data?.data == null) return
        Thread {
            try {
                modelStatus = "Model copy ho raha hai… (1-2 minute, wait karo)"
                Agent.stop(); Agent.unloadModel()
                val tmp = File(filesDir, "model.tmp")
                val out = File(filesDir, "model.task")
                contentResolver.openInputStream(data.data!!)!!.use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
                out.delete(); tmp.renameTo(out)
                loadModel(out)
            } catch (e: Throwable) { modelStatus = "Copy error: ${e.message}" }
        }.start()
    }

    private fun exportMemory() {
        val i = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "text/plain"
            putExtra(Intent.EXTRA_TITLE, "phool_kumari_memory_backup.txt")
        }
        startActivityForResult(i, BACKUP_PICK)
    }

    private fun importStudyFile(uri: Uri) {
        addNote("File padh rahi hoon…")
        Thread {
            try {
                val name = contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)
                    ?.use { c -> if (c.moveToFirst()) c.getString(0) else null } ?: "study_file"
                val lower = name.lowercase()
                val extracted = contentResolver.openInputStream(uri)?.use { input ->
                    when {
                        lower.endsWith(".pdf") -> {
                            com.tom_roush.pdfbox.android.PDFBoxResourceLoader.init(applicationContext)
                            org.apache.pdfbox.pdmodel.PDDocument.load(input).use { doc ->
                                org.apache.pdfbox.text.PDFTextStripper().getText(doc).take(1_500_000)
                            }
                        }
                        lower.endsWith(".docx") -> {
                            java.util.zip.ZipInputStream(input).use { zip ->
                                var entry = zip.nextEntry
                                var xml = ""
                                while (entry != null) {
                                    if (entry.name == "word/document.xml") {
                                        xml = zip.readBytes().toString(Charsets.UTF_8)
                                        break
                                    }
                                    entry = zip.nextEntry
                                }
                                Regex("<w:t[^>]*>(.*?)</w:t>").findAll(xml)
                                    .joinToString(" ") { android.text.Html.fromHtml(it.groupValues[1], android.text.Html.FROM_HTML_MODE_LEGACY).toString() }
                                    .take(1_500_000)
                            }
                        }
                        else -> input.bufferedReader(Charsets.UTF_8).use { it.readText().take(1_500_000) }
                    }
                }.orEmpty()
                if (extracted.isBlank()) throw IllegalArgumentException("Is file se text nahi mila. Scanned PDF ho to OCR wali file chahiye.")
                val count = Memory.importText(name, extracted)
                runOnUiThread { addNote("${name} save ho gayi. ${count} characters Phool Kumari ki study memory mein add hue. Ab is file se questions pooch sakte ho.") }
            } catch (e: Throwable) {
                runOnUiThread { addNote("File import nahi hui: ${e.message ?: "unknown error"}") }
            }
        }.start()
    }

    private fun loadModel(f: File) {
        Thread {
            try {
                if (Agent.llmReady) { modelStatus = ""; return@Thread }
                modelStatus = "Model load ho raha hai…"
                Agent.loadModel(this, f)
                modelStatus = ""
            } catch (e: Throwable) { modelStatus = "Model error: ${e.message}" }
        }.start()
    }
}
