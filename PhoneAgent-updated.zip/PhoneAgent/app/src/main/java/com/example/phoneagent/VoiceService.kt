package com.example.phoneagent

import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.*
import android.speech.*
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

class VoiceService : Service() {
    companion object { @Volatile var running = false }

    private var rec: SpeechRecognizer? = null
    private val h = Handler(Looper.getMainLooper())
    private var armedUntil = 0L
    private var ignoreUntil = 0L
    private var armAfter = false
    private var alive = true
    private var wl: PowerManager.WakeLock? = null

    private val wake = Regex("(hey|hay|hi|he|हे|हाय)\\s*(baby|bebi|beby|बेबी|phool\\s*kumari|फूल\\s*कुमारी)")
    private val stopSet = setOf("stop", "ruko", "रुको", "बंद", "रोको", "roko")
    private val yesSet = setOf("haan", "han", "ha", "yes", "bhej do", "bhejo", "send", "haan bhej do", "हाँ", "हां", "भेज दो")
    private val noSet = setOf("nahi", "no", "mat bhejo", "ruk jao", "नहीं", "मत भेजो")

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        Agent.init(this)
        Agent.armCallback = { h.post { armAfter = true } }
        startFg()
        try { wl = getSystemService(PowerManager::class.java).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "phoneagent:listen"); wl?.acquire() } catch (e: Exception) {}
        running = true
        Speaker.init(this)
        Speaker.onDone = {
            val now = System.currentTimeMillis()
            ignoreUntil = now + 1200
            if (armAfter) { armedUntil = now + 15000; armAfter = false }
        }
        h.postDelayed({ speak("Phool Kumari chalu hai. Bolo, main sun rahi hoon.") }, 1500)
        Thread { Agent.ensureModel(this) }.start()
        h.post { startListening() }
        h.postDelayed(watchdog, 8000)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            "STOP_AGENT" -> Agent.stop()
            "STOP_LISTEN" -> { Agent.stop(); stopSelf() }
        }
        return START_STICKY
    }

    private fun speak(t: String) {
        ignoreUntil = if (Speaker.usable) System.currentTimeMillis() + 60000 else 0L   // apni hi awaaz na sunne ke liye
        Agent.log("🔊 $t")
        Speaker.speak(t)
        // agar TTS 'done' bhejna chuk jaye to bhi sunna wapas chalu ho jaye
        h.postDelayed({ if (!Speaker.speaking) ignoreUntil = 0L }, 4000L + t.length * 90L)
    }

    private fun startFg() {
        val ch = "voice"
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(ch, "Phool Kumari", NotificationManager.IMPORTANCE_LOW))
        fun pi(a: String) = PendingIntent.getService(this, a.hashCode(),
            Intent(this, VoiceService::class.java).setAction(a), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, ch)
            .setContentTitle("Phool Kumari sun rahi hai")
            .setContentText("Bolo: hey Phool Kumari, ...")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .addAction(Notification.Action.Builder(android.R.drawable.ic_media_pause, "Agent roko", pi("STOP_AGENT")).build())
            .addAction(Notification.Action.Builder(android.R.drawable.ic_delete, "Sunna band", pi("STOP_LISTEN")).build())
            .build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        else startForeground(1, n)
    }

    private var lastBeat = SystemClock.elapsedRealtime()
    private val restartTask = Runnable { startListening() }

    // Sirf ek hi restart pending rahe (results + error dono se double start na ho)
    private fun restart(delay: Long) {
        h.removeCallbacks(restartTask)
        if (alive) h.postDelayed(restartTask, delay)
    }

    // Recognizer atak/mar jaye to naya bana do
    private fun recreate() {
        try { rec?.cancel() } catch (e: Exception) {}
        try { rec?.destroy() } catch (e: Exception) {}
        rec = null
    }

    // Har 8 sec check: 20 sec se koi awaaz/callback nahi aaya to sunna dobara shuru
    private val watchdog = object : Runnable {
        override fun run() {
            if (!alive) return
            if (SystemClock.elapsedRealtime() - lastBeat > 20000) {
                recreate(); restart(200)
                lastBeat = SystemClock.elapsedRealtime()
            }
            h.postDelayed(this, 8000)
        }
    }

    private fun startListening() {
        if (!alive) return
        try {
            if (rec == null) {
                rec = if (Build.VERSION.SDK_INT >= 33 && SpeechRecognizer.isOnDeviceRecognitionAvailable(this))
                    SpeechRecognizer.createOnDeviceSpeechRecognizer(this)
                else SpeechRecognizer.createSpeechRecognizer(this)
                rec!!.setRecognitionListener(listener)
            }
            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
                putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
            }
            lastBeat = SystemClock.elapsedRealtime()
            rec!!.startListening(i)
        } catch (e: Exception) { recreate(); restart(2000) }
    }

    private val listener = object : RecognitionListener {
        override fun onResults(r: Bundle?) {
            lastBeat = SystemClock.elapsedRealtime()
            r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let { onHeard(it) }
            restart(300)
        }
        override fun onError(e: Int) {
            lastBeat = SystemClock.elapsedRealtime()
            when (e) {
                SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> restart(300)
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> restart(5000)
                else -> { recreate(); restart(1000) }   // busy / client / disconnected / network
            }
        }
        override fun onReadyForSpeech(p: Bundle?) { lastBeat = SystemClock.elapsedRealtime() }
        override fun onBeginningOfSpeech() { lastBeat = SystemClock.elapsedRealtime() }
        override fun onRmsChanged(v: Float) { lastBeat = SystemClock.elapsedRealtime() }
        override fun onBufferReceived(b: ByteArray?) {}
        override fun onEndOfSpeech() { lastBeat = SystemClock.elapsedRealtime() }
        override fun onPartialResults(p: Bundle?) { lastBeat = SystemClock.elapsedRealtime() }
        override fun onEvent(t: Int, p: Bundle?) {}
    }

    private fun onHeard(text: String) {
        val now = System.currentTimeMillis()
        if (now < ignoreUntil || Speaker.speaking) return
        val low = text.lowercase().trim()
        Agent.log("Suna: $text")

        // "bhej doon?" ka jawab: sirf chhota, seedha haan/nahi
        if (Agent.pending != null) {
            if (low in yesSet) { Agent.pendingAnswer = 1; return }
            if (low in noSet || low.startsWith("nahi")) { Agent.pendingAnswer = 2; return }
        }

        val m = wake.find(low)
        val cmd: String
        if (m != null) {
            cmd = low.substring(m.range.last + 1).trim(' ', ',', '.')
            if (cmd.isEmpty()) { armedUntil = now + 8000; speak("Haan boliye"); return }
        } else if (now < armedUntil) { cmd = low; armedUntil = now + 15000 }
        else return

        val tokens = cmd.split(Regex("\\s+"))
        if (tokens.size <= 3 && tokens.any { it in stopSet }) { Agent.stop(); speak("Ruk gaya"); return }
        Agent.handle(cmd) { speak(it) }
    }

    override fun onDestroy() {
        alive = false
        h.removeCallbacksAndMessages(null)
        try { wl?.release() } catch (e: Exception) {}
        rec?.destroy(); Speaker.onDone = null; Speaker.stop(); Agent.stop(); running = false
        super.onDestroy()
    }
}
