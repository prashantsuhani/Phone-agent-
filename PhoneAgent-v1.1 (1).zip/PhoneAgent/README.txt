PHOOL KUMARI — Android phone assistant
======================================

WHAT'S INCLUDED
- App branding changed to Phool Kumari.
- Persistent local facts/preferences and a full append-only conversation log.
- Relevant past conversation retrieval is added to the model prompt.
- Import study material from selectable PDF, DOCX and text-like files. Extracted text is stored locally and matching excerpts are supplied to the model when you ask questions.
- Export facts, conversation history and imported documents into one TXT backup from Settings.
- Better app-name aliases for Instagram/Insta, WhatsApp, YouTube, Chrome, Telegram, Snapchat and Gmail.
- App launch can work even when the Accessibility service is not enabled; screen tapping/scrolling still needs Accessibility.
- Hindi/Hinglish prompt guidance: ask a short clarification instead of guessing when intent is unclear.
- Voice wake phrase supports “hey Phool Kumari” (legacy “hey baby” is also accepted).
- WhatsApp message sending asks for approval by default.

IMPORTANT LIMITATIONS / PRIVACY
- This is a local assistant, not a perfect human-level assistant. Natural conversation and document Q&A require a compatible .task language model to be installed. Recognition quality depends on the phone's speech service and downloaded language packs.
- Memory is saved in the app's private storage. It can still be lost if the app is uninstalled or its app data is cleared. Export the TXT backup regularly and keep it somewhere safe. No software can promise “never forget” under every storage/device failure.
- Imported PDFs must contain selectable text. Scanned/image-only PDFs need OCR and are not extracted by this build.
- Accessibility can read only the visible screen content exposed by the other app. It does not provide unrestricted access to every WhatsApp/Instagram conversation, deleted messages, or private data in the background. Open the intended conversation yourself and review messages before acting.
- Keep “Message bhejne se pehle mujhse poochho” enabled. The assistant should not send a message without your review and approval.
- Do not use it to access another person's account or private conversations without permission.
- Banking/payment apps remain blocked by the existing safety guard.

BUILD APK WITH GITHUB ACTIONS
1. Create a GitHub repository.
2. Upload the contents of this PhoneAgent project folder (not the outer zip folder).
3. Open Actions and run “Build APK” (or push a commit to trigger it).
4. Download the “Phool-Kumari-apk” artifact and extract app-debug.apk.
5. Install the APK on your Android phone. Android may ask you to allow installation from the app you used to download it.

FIRST-TIME SETUP
1. Open Phool Kumari and grant microphone permission when requested.
2. Enable its Accessibility service only if you want it to tap, type or scroll on screen.
3. In Settings, import study files as needed.
4. Select a compatible MediaPipe/LiteRT .task language model to enable free-form chat and document question-answering. The model must fit your phone's RAM and storage.
5. Enable the listening service only when you want the wake phrase. Android may stop background microphone services due to battery policies; allow the app to run unrestricted if needed.
6. Test “open Instagram” first. If it cannot find the app, check that Instagram is installed and updated.

VOICE EXAMPLES
- “Hey Phool Kumari, open Instagram.”
- “Hey Phool Kumari, WhatsApp kholo.”
- “Yaad rakho, mera college XYZ hai.”
- “Maine college ke notes bheje the, database normalization samjhao.”
- “Maine pehle exam ke liye kya poochha tha?”

Memory is retrieval from saved local text; it does not retrain the language model. Keep backups because the app cannot guarantee zero errors or uninterrupted operation on every Android device.


WHATSAPP PERSONAL-STYLE REPLY UPDATE
------------------------------------
- WhatsApp reply flows now wait 1.5 seconds (configurable in source between 1-2 seconds) after reading the currently visible chat before drafting a response.
- They collect up to 80 visible accessibility text items (up to 4,200 characters) rather than only the last 12 snippets.
- The local conversation memory is supplied as writing-style context: language choice, spelling, emoji use, warmth, message length and punctuation. Drafts and visible chat context are saved in the app's private local memory.
- Settings includes a switch for WhatsApp style learning. Message approval remains ON by default.
- UI welcome text and settings presentation have been refreshed.

IMPORTANT WHATSAPP LIMITS
-------------------------
Android Accessibility can read only content WhatsApp exposes in the currently open, visible chat UI. It cannot guarantee reading every old message, hidden message, deleted message, or all chats in the background. Open the intended chat and scroll to load older messages if needed. This update does NOT silently monitor all WhatsApp conversations or send unsolicited replies. Replies are created only when you ask the assistant to reply / message, and approval is requested before sending by default. Keep that approval switch enabled.


=====================================================================
VERSION 1.1 - WHATSAPP AUTO REPLY + NEW MENU UI
=====================================================================
NEW
- Home screen is clean: title, Auto Reply buttons, chat, input. Everything else is in the
  right-side menu (the 3-line button).
- WhatsApp message reading: incoming personal-chat messages are read from WhatsApp notifications
  (Notification access). Groups, media-only and your own replies are ignored.
- 1-2 second reading delay before a draft is written (tap the delay button in the menu to switch 1.0 / 1.5 / 2.0 sec).
- Style memory: your approved / edited / typed replies are stored and used as writing-style samples.
  If you edit a draft before sending, the app remembers the change.
- Ask-first (default): a card + notification shows the incoming message and the draft with
  [Bhejo] [Badlo] [Skip].
- "Khud bhejo" button: ON = replies are sent automatically (OFF by default, asks confirmation).
- "Auto Reply" button: one tap switches the whole feature OFF (and clears waiting drafts).
- Sensitive-message guard: OTP / password, money / bank, emergency / health, crisis, legal and
  adult content are never auto-replied; you get a notification to handle them yourself.
  Drafts containing such content are also blocked.
- Loop guard: max 1 auto reply per 15 sec and 4 per hour per contact.
- Mode: exactly one is active - ALL, or Selected People. Turning ALL OFF brings the selected-people list back.

SETUP
1. Menu -> "Messages padhna" -> allow Notification access for Phool Kumari.
   (Android 13+ sideloaded apps: App info -> top-right menu -> "Allow restricted settings" first.)
2. Menu -> pick an AI model (.task) - needed for drafting replies.
3. Add contacts under Selected People (name exactly as saved in your phone) or turn ALL on.
4. Tap "Auto Reply: OFF" on the home screen to turn it ON.

LIMITS
- WhatsApp must show the message as a notification (chat muted / open on screen = no notification).
- Replies are sent through WhatsApp's own notification reply; if that notification was cleared, sending fails.
- Auto replies go out in your name - keep "Khud bhejo" OFF unless you are comfortable with that.
