package com.example.phoneagent

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.RemoteInput
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.core.app.NotificationManagerCompat
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger

/**
 * WhatsApp Auto Reply (notification based).
 *  - Incoming personal-chat messages are read from WhatsApp notifications (WaListener).
 *  - Mode: ALL  or  Selected People (only one is active; ALL ON => selected list is paused).
 *  - After a 1-2 second reading delay a draft is written in the user's style.
 *  - Default: the draft waits for the user's approval (Bhejo / Badlo / Skip).
 *  - "Khud bhejo" button: the draft is sent automatically.
 *  - Sensitive messages are never auto-replied.
 */
object AutoReply {
    class Pending(val id: Int, val sender: String, val incoming: String, val draft: String, val action: Notification.Action)

    val pending = CopyOnWriteArrayList<Pending>()
    @Volatile var version = 0

    private const val CH = "autoreply"
    private val pool = Executors.newSingleThreadExecutor()
    private val nextId = AtomicInteger(1000)
    private val seen = LinkedHashSet<String>()
    private val sentAt = HashMap<String, MutableList<Long>>()

    private fun p(c: Context) = c.getSharedPreferences("cfg", 0)

    // ---------- settings ----------
    fun enabled(c: Context) = p(c).getBoolean("ar_on", false)
    fun setEnabled(c: Context, v: Boolean) = p(c).edit().putBoolean("ar_on", v).apply()
    fun autoSend(c: Context) = p(c).getBoolean("ar_auto", false)
    fun setAutoSend(c: Context, v: Boolean) = p(c).edit().putBoolean("ar_auto", v).apply()
    fun allMode(c: Context) = p(c).getBoolean("ar_all", false)
    fun setAllMode(c: Context, v: Boolean) = p(c).edit().putBoolean("ar_all", v).apply()
    fun delayMs(c: Context) = p(c).getLong("ar_delay", 1500L).coerceIn(1000L, 2000L)
    fun setDelayMs(c: Context, v: Long) = p(c).edit().putLong("ar_delay", v.coerceIn(1000L, 2000L)).apply()
    fun people(c: Context): List<String> =
        (p(c).getString("ar_people", "") ?: "").split("\n").map { it.trim() }.filter { it.isNotEmpty() }
    fun setPeople(c: Context, l: List<String>) = p(c).edit().putString("ar_people", l.joinToString("\n")).apply()

    fun listenerEnabled(c: Context): Boolean =
        try { NotificationManagerCompat.getEnabledListenerPackages(c).contains(c.packageName) } catch (_: Throwable) { false }

    private fun allowed(c: Context, sender: String): Boolean {
        if (allMode(c)) return true
        return people(c).any { sender.equals(it, true) || (it.length >= 3 && sender.contains(it, true)) }
    }

    // ---------- incoming ----------
    fun handleIncoming(ctx: Context, key: String, sender: String, text: String, convo: List<String>, action: Notification.Action) {
        val app = ctx.applicationContext
        if (!enabled(app)) return
        synchronized(seen) {
            if (!seen.add("$key|$text")) return
            if (seen.size > 80) seen.remove(seen.first())
        }
        pool.execute {
            try { process(app, sender, text, convo, action) }
            catch (t: Throwable) { Agent.log("Auto Reply error: ${t.message}") }
        }
    }

    private fun rateOk(sender: String): Boolean = synchronized(sentAt) {
        val now = System.currentTimeMillis()
        val l = sentAt.getOrPut(sender.lowercase()) { mutableListOf() }
        l.removeAll { now - it > 3_600_000L }
        // loop / spam guard: at least 15 s gap, at most 4 auto replies per contact per hour
        !(l.isNotEmpty() && now - l.last() < 15_000L) && l.size < 4
    }

    private fun process(app: Context, sender: String, text: String, convo: List<String>, action: Notification.Action) {
        if (!enabled(app) || !allowed(app, sender)) return
        Agent.init(app)
        if (Agent.whatsappStyleLearning) Memory.addTurn("WhatsApp $sender: $text")

        val why = Sensitive.check(text)
        if (why != null) {
            notifyUser(app, 1, "⚠ $sender: sensitive message", "$why — auto-reply roka gaya. Ise khud dekho.")
            Agent.log("⚠ $sender ka message sensitive ($why). Auto-reply nahi kiya.")
            return
        }
        if (!rateOk(sender)) return

        Thread.sleep(delayMs(app))                       // reading delay (1-2 sec)
        if (!enabled(app)) return
        Agent.ensureModel(app)
        if (!Agent.llmReady) { Agent.log("Auto Reply: AI model load nahi hai, draft nahi ban saka."); return }

        val draft = Agent.draftReply(sender, convo.joinToString(" | ").ifBlank { text })
        if (draft.isBlank() || draft.trim().uppercase().startsWith("SKIP")) {
            notifyUser(app, 2, "$sender ka message", "Isme khud jawab dena behtar hai — auto-reply nahi kiya.")
            return
        }
        if (Sensitive.check(draft) != null) return
        if (!enabled(app)) return

        if (autoSend(app)) {
            deliver(app, sender, action, draft)
        } else {
            val id = nextId.incrementAndGet()
            pending.add(Pending(id, sender, text, draft, action))
            version++
            postApproval(app, id, sender, text, draft)
        }
    }

    // ---------- sending ----------
    private fun deliver(app: Context, sender: String, action: Notification.Action, text: String): Boolean {
        return try {
            val ri = action.remoteInputs
            if (ri == null || ri.isEmpty()) { Agent.log("Reply ka option nahi mila"); return false }
            val intent = Intent()
            val b = Bundle()
            b.putCharSequence(ri[0].resultKey, text)
            RemoteInput.addResultsToIntent(ri, intent, b)
            action.actionIntent.send(app, 0, intent)
            synchronized(sentAt) { sentAt.getOrPut(sender.lowercase()) { mutableListOf() }.add(System.currentTimeMillis()) }
            Memory.addStyle(text)
            if (Agent.whatsappStyleLearning) Memory.addTurn("Phool Kumari -> WhatsApp reply to $sender: $text")
            Agent.log("✅ $sender ko reply bheja: $text")
            true
        } catch (t: Throwable) {
            Agent.log("Reply nahi bhej paayi (chat band/purani ho gayi?): ${t.message}")
            false
        }
    }

    fun approve(ctx: Context, id: Int, edited: String? = null) {
        val app = ctx.applicationContext
        val item = pending.firstOrNull { it.id == id } ?: return
        pending.remove(item); version++
        NotificationManagerCompat.from(app).cancel(id)
        val finalText = (edited ?: item.draft).trim()
        if (finalText.isEmpty() || Sensitive.check(finalText) != null) { Agent.log("Ye reply sensitive lagta hai, nahi bheja."); return }
        pool.execute {
            if (deliver(app, item.sender, item.action, finalText) && finalText != item.draft) {
                Memory.add("L", "User ne draft '${item.draft}' ko '$finalText' me badla. Aage isi andaaz me likho.")
            }
        }
    }

    fun skip(ctx: Context, id: Int) {
        val item = pending.firstOrNull { it.id == id } ?: return
        pending.remove(item); version++
        NotificationManagerCompat.from(ctx.applicationContext).cancel(id)
        Memory.add("L", "User ne ye draft skip kiya: '${item.draft}'")
    }

    fun clearPending(ctx: Context) {
        pending.forEach { NotificationManagerCompat.from(ctx.applicationContext).cancel(it.id) }
        pending.clear(); version++
    }

    // ---------- notifications ----------
    private fun channel(app: Context) {
        val nm = app.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "Auto Reply", NotificationManager.IMPORTANCE_HIGH))
    }

    private fun notifyUser(app: Context, id: Int, title: String, body: String) {
        try {
            channel(app)
            val open = PendingIntent.getActivity(app, 0, Intent(app, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
            val n = Notification.Builder(app, CH).setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle(title).setContentText(body).setStyle(Notification.BigTextStyle().bigText(body))
                .setContentIntent(open).setAutoCancel(true).build()
            app.getSystemService(NotificationManager::class.java).notify(id, n)
        } catch (_: Throwable) {}
    }

    private fun postApproval(app: Context, id: Int, sender: String, incoming: String, draft: String) {
        try {
            channel(app)
            fun pi(a: String, code: Int) = PendingIntent.getBroadcast(
                app, code, Intent(app, AutoReplyReceiver::class.java).setAction(a).putExtra("id", id),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            val open = PendingIntent.getActivity(app, 0, Intent(app, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
            val body = "$sender: $incoming\n\nDraft reply: $draft"
            val n = Notification.Builder(app, CH).setSmallIcon(android.R.drawable.ic_dialog_email)
                .setContentTitle("$sender ko reply bhejun?").setContentText(draft)
                .setStyle(Notification.BigTextStyle().bigText(body))
                .setContentIntent(open)
                .addAction(android.R.drawable.ic_menu_send, "Bhejo", pi("AR_SEND", id * 2))
                .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Skip", pi("AR_SKIP", id * 2 + 1))
                .build()
            app.getSystemService(NotificationManager::class.java).notify(id, n)
        } catch (_: Throwable) {}
    }
}

class AutoReplyReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val id = i.getIntExtra("id", -1)
        when (i.action) {
            "AR_SEND" -> AutoReply.approve(c, id)
            "AR_SKIP" -> AutoReply.skip(c, id)
        }
    }
}
