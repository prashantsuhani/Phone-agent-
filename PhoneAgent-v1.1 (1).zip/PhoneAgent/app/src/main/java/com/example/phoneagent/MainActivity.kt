package com.example.phoneagent

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.speech.RecognizerIntent
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import java.io.File

class MainActivity : Activity() {
    private val BG = Color.parseColor("#0F1115")
    private val CARD = Color.parseColor("#1A1D24")
    private val CARD2 = Color.parseColor("#252A35")
    private val ACCENT = Color.parseColor("#7C5CFF")
    private val MUTED = Color.parseColor("#9CA3AF")
    private val GREEN = Color.parseColor("#4ADE80")
    private val RED = Color.parseColor("#B91C1C")
    private val MP = ViewGroup.LayoutParams.MATCH_PARENT
    private val WC = ViewGroup.LayoutParams.WRAP_CONTENT
    private val PICK = 1
    private val VOICE = 2
    private val PERM = 3
    private val DOC_PICK = 4
    private val BACKUP_PICK = 5
    private val h = Handler(Looper.getMainLooper())

    private lateinit var chat: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var hint: TextView
    private lateinit var note: TextView
    private lateinit var input: EditText
    private lateinit var stopBar: TextView
    private lateinit var pillAuto: TextView
    private lateinit var pillSend: TextView
    private lateinit var pendingBox: LinearLayout
    private lateinit var drawer: ScrollView
    private lateinit var scrim: View
    private lateinit var chipModel: TextView
    private lateinit var chipCtl: TextView
    private lateinit var chipListen: TextView
    private lateinit var chipNotif: TextView
    private lateinit var swAll: Switch
    private lateinit var swSend: Switch
    private lateinit var modeText: TextView
    private lateinit var peopleBox: LinearLayout
    private lateinit var peopleInput: EditText
    private lateinit var addPerson: TextView
    private lateinit var delayBtn: TextView
    private var drawerOpen = false
    private var syncing = false
    private var shownVersion = -1
    private var modelStatus = ""

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun shape(color: Int, radius: Int, oval: Boolean = false) = GradientDrawable().apply {
        setColor(color)
        if (oval) shape = GradientDrawable.OVAL else cornerRadius = dp(radius).toFloat()
    }

    private fun tv(msg: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = msg; textSize = size; setTextColor(color)
        if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
    }

    private fun circle(label: String, sizeDp: Int, color: Int, onClick: () -> Unit) = TextView(this).apply {
        text = label; textSize = 20f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
        background = shape(color, 0, true)
        layoutParams = LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp))
        setOnClickListener { onClick() }
    }

    private fun btn(label: String, onClick: () -> Unit) = TextView(this).apply {
        text = label; textSize = 14f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
        setPadding(dp(12), dp(12), dp(12), dp(12))
        background = shape(CARD2, 12)
        layoutParams = LinearLayout.LayoutParams(MP, WC).apply { topMargin = dp(8) }
        setOnClickListener { onClick() }
    }

    private fun chip(onClick: () -> Unit) = TextView(this).apply {
        textSize = 12f
        setPadding(dp(12), dp(7), dp(12), dp(7))
        layoutParams = LinearLayout.LayoutParams(WC, WC).apply { marginEnd = dp(8); topMargin = dp(8) }
        setOnClickListener { onClick() }
    }

    private fun styleChip(c: TextView, ok: Boolean, label: String) {
        c.text = label + if (ok) "  ✓" else "  ✗"
        c.setTextColor(if (ok) GREEN else MUTED)
        c.background = shape(if (ok) Color.parseColor("#14301F") else Color.parseColor("#1F232B"), 20)
    }

    private fun section(title: String) = tv(title, 12f, ACCENT, true).apply {
        setPadding(0, dp(22), 0, dp(4))
    }

    private fun switchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) = Switch(this).apply {
        text = label; setTextColor(Color.WHITE); textSize = 14f; isChecked = checked
        setPadding(0, dp(8), 0, dp(8))
        setOnCheckedChangeListener { _, c -> if (!syncing) onChange(c) }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = BG
        window.navigationBarColor = BG
        Agent.init(this)
        Speaker.init(this)
        Agent.logger = { onLog(it) }
        setContentView(build())
        renderPeople()
        val f = File(filesDir, "model.task")
        if (f.exists() && !Agent.llmReady) loadModel(f)
        tick.run()
    }

    override fun onDestroy() {
        h.removeCallbacks(tick)
        Agent.logger = null
        super.onDestroy()
    }

    override fun onResume() { super.onResume(); refresh() }

    override fun onBackPressed() { if (drawerOpen) closeDrawer() else super.onBackPressed() }

    private val tick = object : Runnable {
        override fun run() { refresh(); h.postDelayed(this, 700) }
    }

    // ---------- state -> UI ----------
    private fun refresh() {
        val on = AutoReply.enabled(this)
        val auto = AutoReply.autoSend(this)
        val all = AutoReply.allMode(this)

        pillAuto.text = if (on) "🤖 Auto Reply: ON" else "🤖 Auto Reply: OFF"
        pillAuto.setTextColor(if (on) GREEN else MUTED)
        pillAuto.background = shape(if (on) Color.parseColor("#14301F") else CARD, 20)
        pillSend.text = if (auto) "⚡ Khud bhejo: ON" else "⚡ Khud bhejo: OFF"
        pillSend.setTextColor(if (auto) Color.parseColor("#FBBF24") else MUTED)
        pillSend.background = shape(if (auto) Color.parseColor("#33280A") else CARD, 20)

        styleChip(chipModel, Agent.llmReady, "🧠 Model")
        styleChip(chipCtl, AgentService.instance != null, "🖐 Control")
        styleChip(chipListen, VoiceService.running, "👂 Sunna")
        styleChip(chipNotif, AutoReply.listenerEnabled(this), "🔔 Messages padhna")

        syncing = true
        if (swAll.isChecked != all) swAll.isChecked = all
        if (swSend.isChecked != auto) swSend.isChecked = auto
        syncing = false
        modeText.text = if (all) "Active mode: ALL (sabhi personal chats)" else "Active mode: Selected People (${AutoReply.people(this).size} log)"
        peopleBox.alpha = if (all) 0.35f else 1f
        peopleInput.isEnabled = !all
        delayBtn.text = "📖 Padhne ke baad ruko: ${AutoReply.delayMs(this) / 1000.0} sec  (tap = badlo)"

        stopBar.visibility = if (Agent.running) View.VISIBLE else View.GONE
        if (shownVersion != AutoReply.version) renderPending()

        note.text = when {
            on && !AutoReply.listenerEnabled(this) -> "Messages padhne ke liye ☰ menu me 'Messages padhna' ON karo"
            on && !Agent.llmReady -> if (modelStatus.isNotEmpty()) modelStatus else "Auto Reply ke liye ☰ menu se AI model chuno"
            AgentService.instance == null -> "Phone control ke liye ☰ menu me 'Control' ON karo"
            !Agent.llmReady -> if (modelStatus.isNotEmpty()) modelStatus else "Basic commands ready ✅"
            else -> ""
        }
        note.visibility = if (note.text.isEmpty()) View.GONE else View.VISIBLE
    }

    private fun renderPending() {
        shownVersion = AutoReply.version
        pendingBox.removeAllViews()
        val list = AutoReply.pending.toList()
        list.forEach { pendingBox.addView(card(it)) }
        pendingBox.visibility = if (list.isEmpty()) View.GONE else View.VISIBLE
    }

    private fun card(p: AutoReply.Pending): View {
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = shape(CARD, 16)
            setPadding(dp(14), dp(12), dp(14), dp(12))
            layoutParams = LinearLayout.LayoutParams(MP, WC).apply { topMargin = dp(8) }
        }
        c.addView(tv("💬 ${p.sender}", 14f, Color.WHITE, true))
        c.addView(tv(p.incoming.take(160), 13f, MUTED).apply { setPadding(0, dp(2), 0, dp(6)) })
        c.addView(tv("↪ ${p.draft}", 15f, Color.WHITE))
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fun small(label: String, color: Int, act: () -> Unit) = TextView(this).apply {
            text = label; textSize = 13f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
            setPadding(dp(8), dp(10), dp(8), dp(10)); background = shape(color, 12)
            layoutParams = LinearLayout.LayoutParams(0, WC, 1f).apply { marginEnd = dp(6); topMargin = dp(10) }
            setOnClickListener { act() }
        }
        row.addView(small("✅ Bhejo", Color.parseColor("#166534")) { AutoReply.approve(this, p.id) })
        row.addView(small("✏ Badlo", CARD2) { editDraft(p) })
        row.addView(small("✖ Skip", RED) { AutoReply.skip(this, p.id) })
        c.addView(row)
        return c
    }

    private fun editDraft(p: AutoReply.Pending) {
        val et = EditText(this).apply { setText(p.draft); setPadding(dp(20), dp(16), dp(20), dp(16)) }
        AlertDialog.Builder(this).setTitle("${p.sender} ko reply")
            .setView(et)
            .setPositiveButton("Bhejo") { _, _ -> AutoReply.approve(this, p.id, et.text.toString()) }
            .setNegativeButton("Cancel", null).show()
    }

    // ---------- auto reply controls ----------
    private fun toggleAutoReply() {
        val on = !AutoReply.enabled(this)
        if (on && !AutoReply.listenerEnabled(this)) {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            addNote("Phool Kumari ko Notification access do, phir wapas aakar Auto Reply dobara dabao.")
            return
        }
        if (on && Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 9)
        AutoReply.setEnabled(this, on)
        if (!on) AutoReply.clearPending(this)
        addNote(if (on) "Auto Reply chalu. Naye WhatsApp messages par draft banega." else "Auto Reply band.")
        refresh()
    }

    private fun setAutoSend(on: Boolean) {
        if (!on) { AutoReply.setAutoSend(this, false); refresh(); return }
        AlertDialog.Builder(this).setTitle("Khud bhejo ON karein?")
            .setMessage("Phool Kumari bina poochhe tumhari taraf se reply bhej degi (sensitive messages chhodkar). Kabhi bhi band kar sakte ho.")
            .setPositiveButton("Haan, ON karo") { _, _ -> AutoReply.setAutoSend(this, true); refresh() }
            .setNegativeButton("Nahi") { _, _ -> refresh() }
            .setOnCancelListener { refresh() }
            .show()
    }

    private fun toggleAutoSend() = setAutoSend(!AutoReply.autoSend(this))

    private fun renderPeople() {
        peopleBox.removeAllViews()
        val all = AutoReply.allMode(this)
        peopleBox.addView(peopleInputRow())
        AutoReply.people(this).forEach { name ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(6), 0, dp(6)) }
            row.addView(tv("👤 $name", 14f, Color.WHITE), LinearLayout.LayoutParams(0, WC, 1f))
            row.addView(tv("✕", 18f, MUTED).apply {
                setPadding(dp(12), dp(4), dp(4), dp(4))
                setOnClickListener {
                    if (!AutoReply.allMode(this@MainActivity)) {
                        AutoReply.setPeople(this@MainActivity, AutoReply.people(this@MainActivity).filter { it != name })
                        renderPeople(); refresh()
                    }
                }
            })
            peopleBox.addView(row)
        }
        peopleBox.alpha = if (all) 0.35f else 1f
    }

    private fun peopleInputRow(): View {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        peopleInput = EditText(this).apply {
            hint = "Contact ka naam (jaise phone me saved)"
            setHintTextColor(MUTED); setTextColor(Color.WHITE); textSize = 14f
            background = shape(CARD2, 12); setPadding(dp(12), dp(10), dp(12), dp(10))
            inputType = InputType.TYPE_CLASS_TEXT; setSingleLine(true)
        }
        addPerson = tv("＋", 20f, Color.WHITE, true).apply {
            gravity = Gravity.CENTER; background = shape(ACCENT, 12)
            layoutParams = LinearLayout.LayoutParams(dp(44), dp(44)).apply { marginStart = dp(8) }
            setOnClickListener {
                val n = peopleInput.text.toString().trim()
                if (n.isNotEmpty() && !AutoReply.allMode(this@MainActivity)) {
                    val cur = AutoReply.people(this@MainActivity)
                    if (cur.none { it.equals(n, true) }) AutoReply.setPeople(this@MainActivity, cur + n)
                    renderPeople(); refresh()
                }
            }
        }
        row.addView(peopleInput, LinearLayout.LayoutParams(0, WC, 1f))
        row.addView(addPerson)
        return row
    }

    // ---------- drawer ----------
    private fun openDrawer() {
        drawerOpen = true
        scrim.visibility = View.VISIBLE; scrim.alpha = 0f
        scrim.animate().alpha(1f).setDuration(180).start()
        drawer.visibility = View.VISIBLE
        drawer.translationX = (resources.displayMetrics.widthPixels * 0.84f)
        drawer.animate().translationX(0f).setDuration(200).start()
    }

    private fun closeDrawer() {
        drawerOpen = false
        scrim.animate().alpha(0f).setDuration(160).withEndAction { scrim.visibility = View.GONE }.start()
        drawer.animate().translationX(drawer.width.toFloat()).setDuration(180).withEndAction { drawer.visibility = View.GONE }.start()
    }

    private fun toggleDrawer() { if (drawerOpen) closeDrawer() else openDrawer() }

    private fun build(): View {
        val frame = FrameLayout(this).apply { setBackgroundColor(BG) }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(12))
        }
        // header: title + hamburger (right)
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        head.addView(tv("Phool Kumari", 22f, Color.WHITE, true), LinearLayout.LayoutParams(0, WC, 1f))
        head.addView(circle("☰", 42, CARD) { toggleDrawer() })
        root.addView(head)

        // Auto Reply quick buttons
        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fun pill(onClick: () -> Unit) = TextView(this).apply {
            textSize = 13f; setPadding(dp(14), dp(9), dp(14), dp(9))
            layoutParams = LinearLayout.LayoutParams(WC, WC).apply { marginEnd = dp(8) }
            setOnClickListener { onClick() }
        }
        pillAuto = pill { toggleAutoReply() }
        pillSend = pill { toggleAutoSend() }
        bar.addView(pillAuto); bar.addView(pillSend)
        root.addView(bar, LinearLayout.LayoutParams(MP, WC).apply { topMargin = dp(12) })

        pendingBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE }
        root.addView(pendingBox)

        note = tv("", 12f, ACCENT).apply { setPadding(0, dp(8), 0, 0); visibility = View.GONE }
        root.addView(note)

        // chat
        chat = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(8), 0, dp(8)) }
        hint = tv("Namaste 👋  Bolo ya likho.", 16f, MUTED).apply { setPadding(0, dp(28), 0, 0) }
        chat.addView(hint)
        scroll = ScrollView(this).apply { addView(chat); isVerticalScrollBarEnabled = false }
        root.addView(scroll, LinearLayout.LayoutParams(MP, 0, 1f))

        stopBar = tv("⏹  Roko  (agent chal raha hai)", 14f, Color.WHITE, true).apply {
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(12), dp(12), dp(12))
            background = shape(RED, 14)
            visibility = View.GONE
            setOnClickListener { Agent.stop(); Speaker.stop(); addNote("Roka gaya") }
        }
        root.addView(stopBar, LinearLayout.LayoutParams(MP, WC).apply { bottomMargin = dp(8) })

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        input = EditText(this).apply {
            hint = "Message likho ya mic se bolo…"
            setHintTextColor(MUTED); setTextColor(Color.WHITE); textSize = 15f
            background = shape(CARD, 26)
            setPadding(dp(18), dp(12), dp(18), dp(12))
            inputType = InputType.TYPE_CLASS_TEXT
            imeOptions = EditorInfo.IME_ACTION_SEND
            setSingleLine(true)
            setOnEditorActionListener { _, a, _ ->
                if (a == EditorInfo.IME_ACTION_SEND) { send(text.toString()); true } else false
            }
        }
        row.addView(input, LinearLayout.LayoutParams(0, WC, 1f))
        val sendB = circle("➤", 46, CARD2) { send(input.text.toString()) }
        row.addView(sendB, (sendB.layoutParams as LinearLayout.LayoutParams).apply { marginStart = dp(8) })
        val mic = circle("🎤", 54, ACCENT) { listenOnce() }
        row.addView(mic, (mic.layoutParams as LinearLayout.LayoutParams).apply { marginStart = dp(8) })
        root.addView(row)

        // ----- right-side menu (hamburger) -----
        val d = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(22), dp(16), dp(28)) }
        d.addView(tv("Menu", 20f, Color.WHITE, true))

        d.addView(section("STATUS"))
        val chips = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val chips2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        chipModel = chip { pickModel() }
        chipCtl = chip { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        chipListen = chip { toggleListen() }
        chipNotif = chip { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
        chips.addView(chipModel); chips.addView(chipCtl)
        chips2.addView(chipListen); chips2.addView(chipNotif)
        d.addView(chips); d.addView(chips2)

        d.addView(section("WHATSAPP AUTO REPLY"))
        swAll = switchRow("ALL — sabhi personal chats ko", AutoReply.allMode(this)) { v ->
            AutoReply.setAllMode(this, v); renderPeople(); refresh()
        }
        d.addView(swAll)
        modeText = tv("", 12f, ACCENT)
        d.addView(modeText)
        d.addView(tv("Selected People (ALL band hone par ye list active hogi)", 12f, MUTED).apply { setPadding(0, dp(12), 0, dp(6)) })
        peopleBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        d.addView(peopleBox)
        swSend = switchRow("Khud bhejo (bina poochhe)", AutoReply.autoSend(this)) { v -> setAutoSend(v) }
        d.addView(swSend.apply { setPadding(0, dp(14), 0, dp(8)) })
        d.addView(tv("Sensitive messages (OTP, paisa, emergency, legal…) par auto-reply hamesha ruk jaati hai.", 12f, MUTED))
        delayBtn = btn("") {
            val next = when (AutoReply.delayMs(this)) { 1000L -> 1500L; 1500L -> 2000L; else -> 1000L }
            AutoReply.setDelayMs(this, next); Agent.whatsappReadDelayMs = next; refresh()
        }
        d.addView(delayBtn)
        d.addView(switchRow("WhatsApp style seekhna", getSharedPreferences("cfg", 0).getBoolean("wa_read", true)) { v ->
            getSharedPreferences("cfg", 0).edit().putBoolean("wa_read", v).apply(); Agent.whatsappStyleLearning = v
        })
        d.addView(switchRow("Voice se bheje message se pehle poochho", getSharedPreferences("cfg", 0).getBoolean("approve", true)) { v ->
            getSharedPreferences("cfg", 0).edit().putBoolean("approve", v).apply(); Agent.approveFirst = v
        })

        d.addView(section("MEMORY & FILES"))
        d.addView(btn("📚 Padhai ki file import karo (PDF / DOCX / TXT)") { pickDocument() })
        d.addView(btn("📄 Saved files dekho") { closeDrawer(); addNote("Saved study files: ${Memory.documentNames().joinToString()}") })
        d.addView(btn("🧠 Memory dekho") { closeDrawer(); addNote("Yaad: ${Memory.notes()}"); addNote("Seekh: ${Memory.lessons()}") })
        d.addView(btn("💾 Memory ka TXT backup") { exportMemory() })
        d.addView(btn("🗑 Memory saaf karo") {
            AlertDialog.Builder(this).setTitle("Memory saaf karein?").setMessage("Saari yaad, seekh aur files hat jaayengi.")
                .setPositiveButton("Haan") { _, _ -> Memory.clear(); closeDrawer(); addNote("Memory saaf ho gayi") }
                .setNegativeButton("Nahi", null).show()
        })

        d.addView(section("AI & AWAAZ"))
        d.addView(btn("📂 AI model badlo (.task file)") { pickModel() })
        d.addView(btn("🔊 Awaaz test") { closeDrawer(); say("Namaste, main Phool Kumari hoon. Meri awaaz aa rahi hai?") })

        drawer = ScrollView(this).apply {
            setBackgroundColor(Color.parseColor("#14171D")); addView(d); visibility = View.GONE
            isVerticalScrollBarEnabled = false
        }
        scrim = View(this).apply {
            setBackgroundColor(Color.parseColor("#99000000")); visibility = View.GONE
            setOnClickListener { closeDrawer() }
        }
        frame.addView(root, FrameLayout.LayoutParams(MP, MP))
        frame.addView(scrim, FrameLayout.LayoutParams(MP, MP))
        frame.addView(drawer, FrameLayout.LayoutParams((resources.displayMetrics.widthPixels * 0.84f).toInt(), MP, Gravity.END))
        return frame
    }

    // ---------- chat ----------
    private fun addBubble(msg: String, mine: Boolean) = runOnUiThread {
        hint.visibility = View.GONE
        val t = TextView(this).apply {
            text = msg; textSize = 15f; setTextColor(Color.WHITE)
            setPadding(dp(14), dp(10), dp(14), dp(10))
            background = shape(if (mine) ACCENT else CARD2, 16)
        }
        val lp = LinearLayout.LayoutParams(WC, WC).apply {
            gravity = if (mine) Gravity.END else Gravity.START
            topMargin = dp(8)
            if (mine) marginStart = dp(56) else marginEnd = dp(56)
        }
        chat.addView(t, lp)
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun addNote(msg: String) = runOnUiThread {
        hint.visibility = View.GONE
        val t = tv(msg, 12f, MUTED).apply { gravity = Gravity.CENTER }
        chat.addView(t, LinearLayout.LayoutParams(MP, WC).apply { topMargin = dp(6) })
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun onLog(line: String) {
        when {
            line.startsWith("Suna:") -> addBubble(line.removePrefix("Suna:").trim(), true)
            line.startsWith("🔊") -> addBubble(line.removePrefix("🔊").trim(), false)
            line.startsWith("Phool Kumari:") -> {}
            else -> addNote(line)
        }
    }

    private fun say(t: String) { Agent.log("🔊 $t"); Speaker.speak(t) }

    private fun send(t0: String) {
        val t = t0.trim()
        if (t.isEmpty()) return
        input.setText("")
        addBubble(t, true)
        Agent.handle(t) { say(it) }
    }

    // ---------- voice ----------
    private fun listenOnce() {
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
        }
        try { startActivityForResult(i, VOICE) } catch (e: Exception) { addNote("Voice input nahi mila. Google app update karo.") }
    }

    private fun toggleListen() {
        if (VoiceService.running) {
            stopService(Intent(this, VoiceService::class.java))
            addNote("Sunna band kiya"); return
        }
        val need = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) need.add(Manifest.permission.POST_NOTIFICATIONS)
        if (need.all { checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }) startListening()
        else requestPermissions(need.toTypedArray(), PERM)
    }

    private fun startListening() {
        try {
            val pm = getSystemService(PowerManager::class.java)
            if (!pm.isIgnoringBatteryOptimizations(packageName)) {
                startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
                addNote("Battery screen me 'Allow' dabao, phir 'Sunna' dobara dabao")
                return
            }
        } catch (e: Exception) {}
        startForegroundService(Intent(this, VoiceService::class.java))
        addNote("Sun raha hoon. Ab app band karke bhi bolo: hey Phool Kumari, open Instagram")
    }

    override fun onRequestPermissionsResult(c: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(c, p, r)
        if (c == PERM && checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)
            startListening()
        else addNote("Mic permission chahiye")
    }

    // ---------- model ----------
    private fun pickDocument() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf(
                "application/pdf",
                "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                "text/plain", "text/markdown", "text/csv", "application/json"
            ))
        }
        startActivityForResult(intent, DOC_PICK)
    }

    private fun pickModel() {
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"
        }, PICK)
    }

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req == VOICE) {
            val said = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (res == RESULT_OK && said != null) send(said)
            return
        }
        if (req == DOC_PICK && res == RESULT_OK && data?.data != null) {
            importStudyFile(data.data!!)
            return
        }
        if (req == BACKUP_PICK && res == RESULT_OK && data?.data != null) {
            Thread {
                try {
                    contentResolver.openOutputStream(data.data!!)?.bufferedWriter(Charsets.UTF_8)?.use { it.write(Memory.exportAllText()) }
                    runOnUiThread { addNote("Memory backup export ho gaya. Is TXT file ko safe jagah rakhna.") }
                } catch (e: Throwable) { runOnUiThread { addNote("Backup export nahi hua: ${e.message}") } }
            }.start()
            return
        }
        if (req != PICK || res != RESULT_OK || data?.data == null) return
        Thread {
            try {
                modelStatus = "Model copy ho raha hai… (1-2 minute, wait karo)"
                Agent.stop(); Agent.unloadModel()
                val tmp = File(filesDir, "model.tmp")
                val out = File(filesDir, "model.task")
                contentResolver.openInputStream(data.data!!)!!.use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
                out.delete(); tmp.renameTo(out)
                loadModel(out)
            } catch (e: Throwable) { modelStatus = "Copy error: ${e.message}" }
        }.start()
    }

    private fun exportMemory() {
        val i = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "text/plain"
            putExtra(Intent.EXTRA_TITLE, "phool_kumari_memory_backup.txt")
        }
        startActivityForResult(i, BACKUP_PICK)
    }

    private fun importStudyFile(uri: Uri) {
        addNote("File padh rahi hoon…")
        Thread {
            try {
                val name = contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)
                    ?.use { c -> if (c.moveToFirst()) c.getString(0) else null } ?: "study_file"
                val lower = name.lowercase()
                val extracted = contentResolver.openInputStream(uri)?.use { input ->
                    when {
                        lower.endsWith(".pdf") -> {
                            com.tom_roush.pdfbox.android.PDFBoxResourceLoader.init(applicationContext)
                            com.tom_roush.pdfbox.pdmodel.PDDocument.load(input).use { doc ->
                                com.tom_roush.pdfbox.text.PDFTextStripper().getText(doc).take(1_500_000)
                            }
                        }
                        lower.endsWith(".docx") -> {
                            java.util.zip.ZipInputStream(input).use { zip ->
                                var entry = zip.nextEntry
                                var xml = ""
                                while (entry != null) {
                                    if (entry.name == "word/document.xml") {
                                        xml = zip.readBytes().toString(Charsets.UTF_8)
                                        break
                                    }
                                    entry = zip.nextEntry
                                }
                                Regex("<w:t[^>]*>(.*?)</w:t>").findAll(xml)
                                    .joinToString(" ") { android.text.Html.fromHtml(it.groupValues[1], android.text.Html.FROM_HTML_MODE_LEGACY).toString() }
                                    .take(1_500_000)
                            }
                        }
                        else -> input.bufferedReader(Charsets.UTF_8).use { it.readText().take(1_500_000) }
                    }
                }.orEmpty()
                if (extracted.isBlank()) throw IllegalArgumentException("Is file se text nahi mila. Scanned PDF ho to OCR wali file chahiye.")
                val count = Memory.importText(name, extracted)
                runOnUiThread { addNote("${name} save ho gayi. ${count} characters Phool Kumari ki study memory mein add hue. Ab is file se questions pooch sakte ho.") }
            } catch (e: Throwable) {
                runOnUiThread { addNote("File import nahi hui: ${e.message ?: "unknown error"}") }
            }
        }.start()
    }

    private fun loadModel(f: File) {
        Thread {
            try {
                if (Agent.llmReady) { modelStatus = ""; return@Thread }
                modelStatus = "Model load ho raha hai…"
                Agent.loadModel(this, f)
                modelStatus = ""
            } catch (e: Throwable) { modelStatus = "Model error: ${e.message}" }
        }.start()
    }
}
