package com.example.phoneagent

import java.util.Locale

/**
 * Sensitive-message guard. If an incoming WhatsApp message (or a drafted reply) looks
 * sensitive, Auto Reply is stopped for that message and the user is told to look at it himself/herself.
 * Returns a short reason, or null when the text looks safe.
 */
object Sensitive {
    private val wordGroups: List<Pair<String, Regex>> = listOf(
        "OTP / password / code" to Regex("\\b(otp|password|passcode|pin|cvv|cvc|verification code|login code|security code|code bhej|code batao)\\b"),
        "paisa / bank" to Regex("\\b(upi|paise|paisa|rupay|rupaye|rupees|money|transfer|payment|pay me|loan|udhaar|udhar|emi|bank|account number|ifsc|card number|debit card|credit card|atm|gpay|phonepe|paytm)\\b"),
        "emergency / health" to Regex("\\b(emergency|accident|hospital|ambulance|icu|heart attack|surgery|serious|critical|urgent|police|died|death|passed away|mar gaya|mar gayi|nahi rahe)\\b"),
        "crisis" to Regex("\\b(suicide|sucide|marna chahta|marna chahti|mar jaun|mar jana|khatam kar lu|khud ko hurt|self harm)\\b"),
        "legal" to Regex("\\b(court|lawyer|advocate|fir|legal notice|arrest|warrant|case file|summons)\\b"),
        "private / adult" to Regex("\\b(nude|nudes|sex|sexy|intimate|naked|nangi|nanga)\\b")
    )
    private val substrings: List<Pair<String, String>> = listOf(
        "OTP / password / code" to "ओटीपी", "OTP / password / code" to "पासवर्ड",
        "paisa / bank" to "पैसे", "paisa / bank" to "उधार", "paisa / bank" to "लोन", "paisa / bank" to "बैंक", "paisa / bank" to "₹",
        "emergency / health" to "अस्पताल", "emergency / health" to "एम्बुलेंस", "emergency / health" to "दुर्घटना", "emergency / health" to "पुलिस",
        "crisis" to "सुसाइड", "crisis" to "मर जाऊं", "crisis" to "जान दे",
        "legal" to "वकील", "legal" to "कोर्ट"
    )
    private val longNumber = Regex("\\d[\\d\\s-]{8,}\\d")

    fun check(text: String): String? {
        val low = text.lowercase(Locale.ROOT)
        for ((reason, rx) in wordGroups) if (rx.containsMatchIn(low)) return reason
        for ((reason, s) in substrings) if (low.contains(s)) return reason
        if (longNumber.containsMatchIn(low)) return "lambi number (account / card / phone)"
        return null
    }
}
