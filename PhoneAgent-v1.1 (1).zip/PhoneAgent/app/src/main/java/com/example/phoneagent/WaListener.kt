package com.example.phoneagent

import android.app.Notification
import android.os.Bundle
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/** Reads incoming WhatsApp personal-chat notifications (sender + message) for Auto Reply. */
class WaListener : NotificationListenerService() {

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        try { read(sbn) } catch (_: Throwable) {}
    }

    private fun read(sbn: StatusBarNotification) {
        if (sbn.packageName != "com.whatsapp" && sbn.packageName != "com.whatsapp.w4b") return
        if (!AutoReply.enabled(this)) return
        val n = sbn.notification
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
        val ex = n.extras
        if (ex.getBoolean("android.isGroupConversation", false)) return

        val title = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim().orEmpty()
        if (title.isEmpty() || title.equals("WhatsApp", true)) return

        // MessagingStyle history (oldest -> newest)
        @Suppress("DEPRECATION")
        val raw = ex.getParcelableArray(Notification.EXTRA_MESSAGES)
        val msgs = raw?.mapNotNull { it as? Bundle } ?: emptyList()
        val own = setOf("you", "aap", "me", "आप")
        val senders = msgs.mapNotNull { it.getCharSequence("sender")?.toString()?.trim() }
            .filter { it.isNotEmpty() && it.lowercase() !in own }
        if (senders.any { !it.equals(title, true) }) return          // looks like a group chat
        val last = msgs.lastOrNull()
        val lastSender = last?.getCharSequence("sender")?.toString()?.trim()?.lowercase()
        if (lastSender != null && lastSender in own) return           // our own reply, ignore

        val text = (last?.getCharSequence("text") ?: ex.getCharSequence(Notification.EXTRA_TEXT))?.toString()?.trim().orEmpty()
        if (text.isEmpty()) return
        if (Regex("^\\d+ (new )?messages?").containsMatchIn(text.lowercase())) return
        if (listOf("📷", "🎤", "🎥", "📄", "🎵", "📍").any { text.startsWith(it) } ||
            text.lowercase() in setOf("photo", "video", "voice message", "audio", "sticker", "document")) return

        val convo = msgs.takeLast(6).mapNotNull { it.getCharSequence("text")?.toString() }.ifEmpty { listOf(text) }

        val actions = mutableListOf<Notification.Action>()
        n.actions?.let { actions.addAll(it) }
        try { actions.addAll(Notification.WearableExtender(n).actions) } catch (_: Throwable) {}
        val reply = actions.firstOrNull { !it.remoteInputs.isNullOrEmpty() } ?: return

        AutoReply.handleIncoming(this, sbn.key, title, text, convo, reply)
    }
}
