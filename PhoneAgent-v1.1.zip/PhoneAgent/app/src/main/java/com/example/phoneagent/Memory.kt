package com.example.phoneagent

import android.content.Context
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Persistent local memory.
 * Facts/lessons, conversation history and imported text documents are stored
 * in app-private files. This is retrieval memory, not model retraining.
 */
object Memory {
    private var root: File? = null
    private var factsFile: File? = null
    private var historyFile: File? = null
    private var docsDir: File? = null
    private val lines = mutableListOf<String>()
    private val history = mutableListOf<String>()
    private val lock = Any()

    fun init(ctx: Context) = synchronized(lock) {
        if (root != null) return
        root = File(ctx.applicationContext.filesDir, "baby_memory").apply { mkdirs() }
        factsFile = File(root, "memory.txt")
        historyFile = File(root, "conversation.txt")
        docsDir = File(root, "documents").apply { mkdirs() }
        factsFile?.takeIf { it.exists() }?.readLines()?.let { lines.addAll(it) }
        historyFile?.takeIf { it.exists() }?.readLines()?.let { history.addAll(it) }
    }

    @Synchronized fun add(kind: String, text: String) {
        val clean = text.replace(Regex("\\s+"), " ").trim().take(2000)
        if (clean.isBlank()) return
        val entry = "$kind|$clean"
        lines.add(entry)
        factsFile?.appendText(entry + "\n")
    }

    /** Messages written / approved by the user: used as writing-style samples. */
    @Synchronized fun addStyle(text: String) = add("S", text)
    @Synchronized fun styleText(n: Int = 25): String =
        lines.filter { it.startsWith("S|") }.map { it.drop(2) }.takeLast(n).joinToString("\n").take(2500)

    @Synchronized fun notes() = lines.filter { it.startsWith("N|") }.map { it.drop(2) }
    @Synchronized fun lessons() = lines.filter { it.startsWith("L|") }.map { it.drop(2) }.takeLast(30)

    @Synchronized fun addTurn(s: String) {
        val stamp = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date())
        val entry = "$stamp | " + s.replace(Regex("\\s+"), " ").trim().take(1500)
        history.add(entry)
        historyFile?.appendText(entry + "\n")
    }

    @Synchronized fun historyText() = history.takeLast(24).joinToString("\n").takeLast(10000)

    @Synchronized fun notesText() =
        (notes().takeLast(80).joinToString("; ") + " | Seekh: " +
            lessons().takeLast(20).joinToString("; ")).take(5000)

    /** Imports plain-text study material into app-private storage. */
    fun importText(name: String, content: String): Int = synchronized(lock) {
        val dir = docsDir ?: return 0
        val safe = name.substringAfterLast('/').replace(Regex("[^A-Za-z0-9._-]"), "_").take(80)
            .ifBlank { "imported.txt" }
        val body = content.replace("\u0000", "").trim()
        if (body.isBlank()) return 0
        val file = File(dir, "${System.currentTimeMillis()}_$safe")
        file.writeText(body)
        add("D", "Document imported: $safe (${body.length} characters)")
        return body.length
    }

    @Synchronized fun documentNames(): List<String> =
        docsDir?.listFiles()?.filter { it.isFile }?.sortedByDescending { it.lastModified() }
            ?.map { it.name.substringAfter('_', it.name) } ?: emptyList()

    /** Lightweight keyword retrieval: supplies only matching excerpts to the local model. */
    @Synchronized fun relevantDocuments(query: String, maxChars: Int = 5000): String {
        val dir = docsDir ?: return ""
        val terms = query.lowercase(Locale.ROOT)
            .split(Regex("[^\\p{L}\\p{N}]+")).filter { it.length >= 3 }.toSet()
        if (terms.isEmpty()) return ""
        val out = StringBuilder()
        val files = dir.listFiles()?.filter { it.isFile }?.sortedByDescending { it.lastModified() } ?: return ""
        for (f in files) {
            val text = try { f.readText() } catch (_: Exception) { continue }
            val chunks = text.chunked(900)
            val ranked = chunks.map { chunk ->
                val low = chunk.lowercase(Locale.ROOT)
                terms.count { low.contains(it) }
            }.withIndex().filter { it.value > 0 }.sortedByDescending { it.value }.take(3)
            for ((idx, _) in ranked) {
                val excerpt = chunks[idx]
                if (out.length + excerpt.length > maxChars) break
                out.append("\n[${f.name.substringAfter('_', f.name)}]\n")
                    .append(excerpt).append("\n")
            }
            if (out.length >= maxChars) break
        }
        return out.toString().take(maxChars)
    }


    /** Retrieve matching earlier user/assistant turns from the complete local log. */
    @Synchronized fun relevantHistory(query: String, maxChars: Int = 5000): String {
        val terms = query.lowercase(Locale.ROOT)
            .split(Regex("[^\\p{L}\\p{N}]+" )).filter { it.length >= 3 }.toSet()
        if (terms.isEmpty()) return history.takeLast(16).joinToString("\n").take(maxChars)
        val ranked = history.mapIndexed { index, line ->
            val low = line.lowercase(Locale.ROOT)
            val score = terms.count { low.contains(it) }
            Triple(index, score, line)
        }.filter { it.second > 0 }.sortedWith(compareByDescending<Triple<Int, Int, String>> { it.second }.thenByDescending { it.first })
            .take(18).sortedBy { it.first }
        return ranked.joinToString("\n") { it.third }.takeLast(maxChars)
    }

    /** Plain-text backup: facts, complete conversation log, and imported documents. */
    @Synchronized fun exportAllText(): String {
        val out = StringBuilder("PHOOL KUMARI MEMORY BACKUP\n\n[FACTS AND LEARNED PREFERENCES]\n")
        lines.forEach { out.append(it).append('\n') }
        out.append("\n[CONVERSATION HISTORY]\n")
        history.forEach { out.append(it).append('\n') }
        out.append("\n[IMPORTED DOCUMENTS]\n")
        val files = docsDir?.listFiles()?.filter { it.isFile }?.sortedBy { it.name } ?: emptyList()
        for (file in files) {
            out.append("\n--- ").append(file.name.substringAfter('_', file.name)).append(" ---\n")
            try { out.append(file.readText()).append('\n') } catch (_: Exception) { }
        }
        return out.toString()
    }

    @Synchronized fun clear() {
        lines.clear(); history.clear()
        factsFile?.writeText(""); historyFile?.writeText("")
        docsDir?.listFiles()?.forEach { it.delete() }
    }
}
