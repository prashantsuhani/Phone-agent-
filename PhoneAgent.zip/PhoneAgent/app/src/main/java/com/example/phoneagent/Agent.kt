package com.example.phoneagent

import android.content.Context
import java.io.File

object Agent {
    @Volatile var running = false
    var logger: ((String) -> Unit)? = null
    private var engine: LlmEngine? = null
    val llmReady get() = engine?.ready == true

    fun log(s: String) { logger?.invoke(s) }
    fun init(ctx: Context) { if (engine == null) engine = LlmEngine(ctx.applicationContext) }

    fun loadModel(ctx: Context, f: File) { init(ctx); engine!!.load(f.absolutePath) }

    fun ensureModel(ctx: Context) {
        init(ctx)
        val f = File(ctx.filesDir, "model.task")
        if (!llmReady && f.exists()) try { loadModel(ctx, f) } catch (e: Throwable) { log("Model error: ${e.message}") }
    }

    fun stop() { running = false }

    private fun waitMs(ms: Long) { var t = 0L; while (running && t < ms) { Thread.sleep(250); t += 250 } }

    fun handle(cmd: String, speak: (String) -> Unit) {
        if (running) { speak("Pehle wala kaam chal raha hai. Pehle stop bolo."); return }
        val svc = AgentService.instance
        if (svc == null) { speak("Accessibility chalu nahi hai."); return }
        running = true
        Thread {
            try {
                val low = cmd.lowercase()
                val reel = (low.contains("reel") || low.contains("रील")) &&
                    (low.contains("insta") || low.contains("इंस्टा"))
                if (reel) {
                    val sec = Regex("(\\d+)\\s*(sec|second|सेकंड)").find(low)?.groupValues?.get(1)?.toIntOrNull() ?: 15
                    runReels(svc, sec.coerceIn(3, 120), speak)
                } else if (!llmReady) speak("Model load nahi hua.")
                else runLlm(svc, cmd, speak)
            } catch (e: Throwable) { log("Error: ${e.message}") }
            finally { running = false; log("Agent ruk gaya.") }
        }.start()
    }

    // Instagram reels: har N second me agli reel par scroll
    private fun runReels(svc: AgentService, sec: Int, speak: (String) -> Unit) {
        speak("Instagram khol raha hoon")
        log("Instagram reels mode, har $sec sec me scroll")
        svc.openApp("Instagram"); waitMs(3500)
        if (!svc.clickByLabel("Reels")) log("Reels tab nahi mila, jo screen hai usi par scroll karunga")
        waitMs(2500)
        while (running) {
            waitMs(sec * 1000L)
            if (!running) break
            if (svc.currentPackage() != "com.instagram.android") {
                speak("Instagram band ho gaya, ruk raha hoon"); break
            }
            log("scroll → ${svc.scroll()}")
        }
    }

    private fun runLlm(svc: AgentService, goal: String, speak: (String) -> Unit) {
        val history = mutableListOf<String>()
        speak("Theek hai")
        svc.home(); waitMs(1200)
        for (step in 1..15) {
            if (!running) break
            val screen = svc.readScreen()
            val prompt = """<start_of_turn>user
You control an Android phone. Goal: $goal
Recent actions: ${history.takeLast(5)}
Current screen:
$screen
Reply with ONE JSON line only. Options:
{"action":"open_app","app":"name"}
{"action":"click","id":N}
{"action":"type","text":"..."}
{"action":"scroll"}
{"action":"back"}
{"action":"home"}
{"action":"done"}
<end_of_turn>
<start_of_turn>model
"""
            val reply = try { engine!!.ask(prompt) } catch (e: Throwable) { log("LLM error: ${e.message}"); break }
            log("Step $step: ${reply.trim().take(120)}")
            val action = Regex("\"action\"\\s*:\\s*\"(\\w+)\"").find(reply)?.groupValues?.get(1)
            val result = when (action) {
                "open_app" -> svc.openApp(Regex("\"app\"\\s*:\\s*\"([^\"]*)\"").find(reply)?.groupValues?.get(1) ?: "")
                "click" -> svc.click(Regex("\"id\"\\s*:\\s*(\\d+)").find(reply)?.groupValues?.get(1)?.toInt() ?: -1)
                "type" -> svc.typeText(Regex("\"text\"\\s*:\\s*\"([^\"]*)\"").find(reply)?.groupValues?.get(1) ?: "")
                "scroll" -> svc.scroll()
                "back" -> svc.back()
                "home" -> svc.home()
                "done" -> { speak("Ho gaya"); running = false; "done" }
                else -> "samajh nahi aaya"
            }
            history.add("$action -> $result")
            log("   $result")
            waitMs(1500)
        }
    }
}
