package com.example.phoneagent

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.graphics.Rect
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class AgentService : AccessibilityService() {
    companion object { @Volatile var instance: AgentService? = null }

    private var nodes: List<AccessibilityNodeInfo> = emptyList()

    override fun onServiceConnected() { instance = this }
    override fun onUnbind(intent: Intent?): Boolean { instance = null; return super.onUnbind(intent) }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    private fun collect(n: AccessibilityNodeInfo?, out: MutableList<AccessibilityNodeInfo>) {
        if (n == null || out.size >= 40) return
        if (n.isVisibleToUser) {
            val label = (n.text ?: n.contentDescription)?.toString()
            if (!label.isNullOrBlank() || n.isClickable || n.isEditable) out.add(n)
        }
        for (i in 0 until n.childCount) collect(n.getChild(i), out)
    }

    fun readScreen(): String {
        val root = rootInActiveWindow ?: return "(screen not readable)"
        val list = mutableListOf<AccessibilityNodeInfo>()
        collect(root, list)
        nodes = list
        val sb = StringBuilder()
        list.forEachIndexed { i, n ->
            val label = (n.text ?: n.contentDescription)?.toString()?.replace("\n", " ")?.take(40) ?: ""
            val kind = when {
                n.isEditable -> "input"
                n.isClickable -> "button"
                else -> "text"
            }
            sb.append("[$i] $kind \"$label\"\n")
        }
        return sb.toString().take(1800)
    }

    private fun tap(x: Float, y: Float) {
        val p = Path().apply { moveTo(x, y) }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(p, 0, 60)).build()
        dispatchGesture(g, null, null)
    }

    fun click(id: Int): String {
        val node = nodes.getOrNull(id) ?: return "invalid id $id"
        var n: AccessibilityNodeInfo? = node
        while (n != null && !n.isClickable) n = n.parent
        if (n != null && n.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return "clicked $id"
        val r = Rect(); node.getBoundsInScreen(r)
        tap(r.exactCenterX(), r.exactCenterY())
        return "tapped $id"
    }

    fun typeText(text: String): String {
        val target = nodes.firstOrNull { it.isEditable && it.isFocused }
            ?: nodes.firstOrNull { it.isEditable }
            ?: return "no input field"
        target.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        val b = Bundle()
        b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        target.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)
        return "typed"
    }

    fun scroll(): String {
        val m = resources.displayMetrics
        val p = Path().apply {
            moveTo(m.widthPixels / 2f, m.heightPixels * 0.7f)
            lineTo(m.widthPixels / 2f, m.heightPixels * 0.3f)
        }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(p, 0, 300)).build()
        dispatchGesture(g, null, null)
        return "scrolled"
    }

    fun back(): String { performGlobalAction(GLOBAL_ACTION_BACK); return "back" }
    fun home(): String { performGlobalAction(GLOBAL_ACTION_HOME); return "home" }

    private val blocked = listOf("paytm", "phonepe", "gpay", "google pay", "bank", "upi", "bhim", "wallet")

    fun openApp(name: String): String {
        if (blocked.any { name.contains(it, ignoreCase = true) })
            return "BLOCKED: payment/bank apps allowed nahi"
        val pm = packageManager
        val app = pm.getInstalledApplications(0).firstOrNull {
            pm.getApplicationLabel(it).toString().contains(name, ignoreCase = true) &&
                pm.getLaunchIntentForPackage(it.packageName) != null
        } ?: return "app not found: $name"
        val i = pm.getLaunchIntentForPackage(app.packageName)!!
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(i)
        return "opened $name"
    }

    fun currentPackage(): String? = rootInActiveWindow?.packageName?.toString()

    fun clickByLabel(label: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val found = root.findAccessibilityNodeInfosByText(label).firstOrNull { it.isVisibleToUser } ?: return false
        var n: AccessibilityNodeInfo? = found
        while (n != null && !n.isClickable) n = n.parent
        if (n != null && n.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
        val r = Rect(); found.getBoundsInScreen(r)
        tap(r.exactCenterX(), r.exactCenterY())
        return true
    }
}
