package com.example.phoneagent

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.*
import android.speech.*
import android.speech.tts.TextToSpeech
import java.util.Locale

class VoiceService : Service(), TextToSpeech.OnInitListener {
    private var rec: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private val h = Handler(Looper.getMainLooper())
    private var armedUntil = 0L
    private var alive = true

    // Wake word: "hey baby". Badalna ho to yahan badlo.
    private val wake = Regex("(hey|hay|hi|he|हे|हाय)\\s*(baby|bebi|beby|बेबी)")
    private val stopWords = listOf("stop", "ruko", "रुको", "बंद", "band", "रोको", "roko")

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        startFg()
        tts = TextToSpeech(this, this)
        Thread { Agent.ensureModel(this) }.start()
        h.post { startListening() }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            "STOP_AGENT" -> Agent.stop()
            "STOP_LISTEN" -> { Agent.stop(); stopSelf() }
        }
        return START_STICKY
    }

    override fun onInit(status: Int) { tts?.language = Locale("hi", "IN") }

    private fun speak(t: String) { tts?.speak(t, TextToSpeech.QUEUE_FLUSH, null, "u") }

    private fun startFg() {
        val ch = "voice"
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(ch, "Hey Baby", NotificationManager.IMPORTANCE_LOW))
        fun pi(a: String) = PendingIntent.getService(this, a.hashCode(),
            Intent(this, VoiceService::class.java).setAction(a), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, ch)
            .setContentTitle("Hey Baby sun raha hai")
            .setContentText("Bolo: hey baby, open Instagram and scroll reels")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .addAction(Notification.Action.Builder(android.R.drawable.ic_media_pause, "Agent roko", pi("STOP_AGENT")).build())
            .addAction(Notification.Action.Builder(android.R.drawable.ic_delete, "Sunna band", pi("STOP_LISTEN")).build())
            .build()
        if (Build.VERSION.SDK_INT >= 29)
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        else startForeground(1, n)
    }

    private fun startListening() {
        if (!alive) return
        try {
            if (rec == null) {
                rec = if (Build.VERSION.SDK_INT >= 33 && SpeechRecognizer.isOnDeviceRecognitionAvailable(this))
                    SpeechRecognizer.createOnDeviceSpeechRecognizer(this)
                else SpeechRecognizer.createSpeechRecognizer(this)
                rec!!.setRecognitionListener(listener)
            }
            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
                putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
            }
            rec!!.startListening(i)
        } catch (e: Exception) { h.postDelayed({ startListening() }, 2000) }
    }

    private val listener = object : RecognitionListener {
        override fun onResults(r: Bundle?) {
            r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.forEach { onHeard(it) }
            h.postDelayed({ startListening() }, 300)
        }
        override fun onError(e: Int) { h.postDelayed({ startListening() }, 700) }
        override fun onReadyForSpeech(p: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(v: Float) {}
        override fun onBufferReceived(b: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onPartialResults(p: Bundle?) {}
        override fun onEvent(t: Int, p: Bundle?) {}
    }

    private fun onHeard(text: String) {
        val low = text.lowercase()
        val now = System.currentTimeMillis()
        Agent.log("Suna: $text")
        val m = wake.find(low)
        val cmd: String
        if (m != null) {
            cmd = low.substring(m.range.last + 1).trim(' ', ',', '.')
            if (cmd.isEmpty()) { armedUntil = now + 8000; speak("Haan boliye"); return }
        } else if (now < armedUntil) { cmd = low; armedUntil = 0 }
        else return

        if (stopWords.any { cmd.contains(it) }) { Agent.stop(); speak("Ruk gaya"); return }
        Agent.handle(cmd) { speak(it) }
    }

    override fun onDestroy() {
        alive = false
        rec?.destroy(); tts?.shutdown(); Agent.stop()
        super.onDestroy()
    }
}
